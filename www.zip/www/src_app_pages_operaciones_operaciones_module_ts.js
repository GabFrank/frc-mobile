"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_operaciones_operaciones_module_ts"],{

/***/ 70081:
/*!********************************************************************!*\
  !*** ./src/app/pages/operaciones/caja-info/caja-info.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaInfoComponent": () => (/* binding */ CajaInfoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _caja_info_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./caja-info.component.html?ngResource */ 29122);
/* harmony import */ var _caja_info_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./caja-info.component.scss?ngResource */ 65573);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/modal.service */ 71609);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_app_services_pop_over_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/pop-over.service */ 21690);
/* harmony import */ var _caja_caja_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../caja/caja.model */ 41743);
/* harmony import */ var _caja_caja_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../caja/caja.service */ 52404);
/* harmony import */ var _conteo_adicionar_conteo_dialog_adicionar_conteo_dialog_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../conteo/adicionar-conteo-dialog/adicionar-conteo-dialog.component */ 53049);
/* harmony import */ var _conteo_conteo_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../conteo/conteo.service */ 40137);
/* harmony import */ var _maletin_maletin_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../maletin/maletin.service */ 87416);


















let CajaInfoComponent = class CajaInfoComponent {
    constructor(route, cajaService, mainService, _location, modalService, dialogoService, maletinService, notificacionService, popoverService, conteoService) {
        this.route = route;
        this.cajaService = cajaService;
        this.mainService = mainService;
        this._location = _location;
        this.modalService = modalService;
        this.dialogoService = dialogoService;
        this.maletinService = maletinService;
        this.notificacionService = notificacionService;
        this.popoverService = popoverService;
        this.conteoService = conteoService;
        this.tentativas = 0;
        this.isApertura = false;
        this.descripcionMaletinControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required]);
    }
    ngOnInit() {
        if (this.cajaService.selectedCaja != null) {
            this.onSelectCaja(this.cajaService.selectedCaja);
            console.log(this.selectedCaja);
        }
        else {
            this.onBack();
        }
    }
    onSelectCaja(caja) {
        var _a, _b;
        this.selectedCaja = caja;
        this.selectedUsuario = (_a = this.selectedCaja) === null || _a === void 0 ? void 0 : _a.usuario;
        this.selectedMaletin = (_b = this.selectedCaja) === null || _b === void 0 ? void 0 : _b.maletin;
    }
    onBack() {
        this._location.back();
    }
    adicionarConteoCierre() {
        this.modalService.openModal(_conteo_adicionar_conteo_dialog_adicionar_conteo_dialog_component__WEBPACK_IMPORTED_MODULE_9__.AdicionarConteoDialogComponent).then(res => {
            var _a, _b, _c;
            console.log(res);
            if (res['data'] != null) {
                this.selectedCaja.conteoCierre = res['data'];
                this.conteoService.onSave(res['data'], (_a = this.selectedCaja) === null || _a === void 0 ? void 0 : _a.id, false, (_c = (_b = this.selectedCaja) === null || _b === void 0 ? void 0 : _b.sucursal) === null || _c === void 0 ? void 0 : _c.id).subscribe(res2 => {
                    if (res2 != null) {
                        this.selectedCaja.conteoCierre = res2;
                    }
                });
            }
        });
    }
    adicionarConteoApertura() {
        this.modalService.openModal(_conteo_adicionar_conteo_dialog_adicionar_conteo_dialog_component__WEBPACK_IMPORTED_MODULE_9__.AdicionarConteoDialogComponent, true).then(res => {
            if (res['data'] != null) {
                this.cajaService.selectedCaja.conteoCierre = res['data'];
                this.selectedCaja.conteoCierre = res['data'];
            }
        });
    }
    verificarMaletin() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.maletinService
                .onGetPorDescripcion(this.descripcionMaletinControl.value)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.untilDestroyed)(this))
                .subscribe((res) => {
                if (res != null) {
                    let maletinEncontrado = res;
                    if (maletinEncontrado.abierto == true) {
                        this.notificacionService.warn('Este maletín está siendo utilizado');
                        this.seleccionarMaletin(null);
                    }
                    else {
                        this.notificacionService.success('Verificado con éxito');
                        this.seleccionarMaletin(maletinEncontrado);
                    }
                }
                else {
                    this.notificacionService.danger('Maletín no encontrado');
                    this.seleccionarMaletin(null);
                }
            });
        });
    }
    seleccionarMaletin(maletin) {
        if (maletin != null) {
            this.descripcionMaletinControl.setValue(maletin.descripcion);
            this.selectedMaletin = maletin;
            this.crearNuevaCaja();
        }
        else {
            this.descripcionMaletinControl.setValue(null);
        }
    }
    crearNuevaCaja() {
        setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            var _a;
            let input = new _caja_caja_model__WEBPACK_IMPORTED_MODULE_7__.PdvCajaInput;
            input.maletinId = this.selectedMaletin.id;
            input.activo = true;
            (yield this.cajaService.onSavePorSucursal(input, (_a = this.cajaService.selectedCaja.sucursal) === null || _a === void 0 ? void 0 : _a.id))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.selectedCaja = res;
                    this.selectedCaja.sucursal = this.cajaService.selectedCaja.sucursal;
                    this.cajaService.selectedCaja = this.selectedCaja;
                    this.notificacionService.success('Caja creada con éxito!!');
                    this.adicionarConteoApertura();
                }
            });
        }), 1000);
    }
};
CajaInfoComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute },
    { type: _caja_caja_service__WEBPACK_IMPORTED_MODULE_8__.CajaService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__.MainService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_16__.Location },
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_4__.ModalService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService },
    { type: _maletin_maletin_service__WEBPACK_IMPORTED_MODULE_11__.MaletinService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__.NotificacionService },
    { type: src_app_services_pop_over_service__WEBPACK_IMPORTED_MODULE_6__.PopOverService },
    { type: _conteo_conteo_service__WEBPACK_IMPORTED_MODULE_10__.ConteoService }
];
CajaInfoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
        selector: 'app-caja-info',
        template: _caja_info_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_caja_info_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CajaInfoComponent);



/***/ }),

/***/ 3929:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/buscar-maletin-dialog/buscar-maletin-dialog.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BuscarMaletinData": () => (/* binding */ BuscarMaletinData),
/* harmony export */   "BuscarMaletinDialogComponent": () => (/* binding */ BuscarMaletinDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _buscar_maletin_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./buscar-maletin-dialog.component.html?ngResource */ 76491);
/* harmony import */ var _buscar_maletin_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./buscar-maletin-dialog.component.scss?ngResource */ 13404);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _maletin_maletin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../maletin/maletin.service */ 87416);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/modal.service */ 71609);
/* harmony import */ var _caja_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../caja.service */ 52404);











class BuscarMaletinData {
}
let BuscarMaletinDialogComponent = class BuscarMaletinDialogComponent {
    constructor(modalService, maletinService, notificacionService, _location, cajaService) {
        this.modalService = modalService;
        this.maletinService = maletinService;
        this.notificacionService = notificacionService;
        this._location = _location;
        this.cajaService = cajaService;
        this.codigoControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required);
    }
    onBack() {
        this._location.back();
    }
    ngAfterViewInit() {
        setTimeout(() => {
            this.buscarInput.setFocus();
        }, 500);
    }
    ngOnInit() {
    }
    onBuscarClick() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.maletinService.onGetPorDescripcion(this.codigoControl.value)).subscribe(res => {
                if (res != null) {
                    this.selectedMaletin = res;
                    if (this.selectedMaletin.abierto == true) {
                        this.notificacionService.warn('Este maletin esta siendo utilizado en este momento');
                        setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                            let input = yield this.buscarInput.getInputElement();
                            input.select();
                        }), 1000);
                    }
                    else {
                        this.notificacionService.success('Maletin seleccionado con éxito');
                        this.modalService.closeModal(this.selectedMaletin);
                    }
                }
                else {
                    this.notificacionService.warn('Maletin no encontrado');
                    setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                        let input = yield this.buscarInput.getInputElement();
                        input.select();
                    }), 1000);
                }
            });
        });
    }
    onCameraClick() {
    }
    onCancel() {
        this.modalService.closeModal(null);
    }
};
BuscarMaletinDialogComponent.ctorParameters = () => [
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_4__.ModalService },
    { type: _maletin_maletin_service__WEBPACK_IMPORTED_MODULE_2__.MaletinService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.NotificacionService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.Location },
    { type: _caja_service__WEBPACK_IMPORTED_MODULE_5__.CajaService }
];
BuscarMaletinDialogComponent.propDecorators = {
    buscarInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild, args: ['buscarInput', { read: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonInput },] }],
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input }]
};
BuscarMaletinDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-buscar-maletin-dialog',
        template: _buscar_maletin_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_buscar_maletin_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BuscarMaletinDialogComponent);



/***/ }),

/***/ 55760:
/*!**********************************************************!*\
  !*** ./src/app/pages/operaciones/caja/caja.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaComponent": () => (/* binding */ CajaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _caja_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./caja.component.html?ngResource */ 75949);
/* harmony import */ var _caja_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./caja.component.scss?ngResource */ 13767);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);






let CajaComponent = class CajaComponent {
    // tentativas = 0;
    // dialog: any;
    constructor() { }
    ngOnInit() { }
};
CajaComponent.ctorParameters = () => [];
CajaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_4__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-caja',
        template: _caja_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner],
        styles: [_caja_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CajaComponent);



/***/ }),

/***/ 41743:
/*!******************************************************!*\
  !*** ./src/app/pages/operaciones/caja/caja.model.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaBalance": () => (/* binding */ CajaBalance),
/* harmony export */   "PdvCaja": () => (/* binding */ PdvCaja),
/* harmony export */   "PdvCajaEstado": () => (/* binding */ PdvCajaEstado),
/* harmony export */   "PdvCajaInput": () => (/* binding */ PdvCajaInput)
/* harmony export */ });
class PdvCaja {
    toInput() {
        var _a, _b, _c, _d;
        let input = new PdvCajaInput;
        input.id = this.id;
        input.descripcion = this.descripcion;
        input.activo = this.activo;
        input.estado = this.estado;
        input.tuvoProblema = this.tuvoProblema;
        input.fechaApertura = this.fechaApertura;
        input.fechaCierre = this.fechaCierre;
        input.observacion = this.observacion;
        input.maletinId = (_a = this.maletin) === null || _a === void 0 ? void 0 : _a.id;
        input.creadoEn = this.creadoEn;
        input.usuarioId = (_b = this.usuario) === null || _b === void 0 ? void 0 : _b.id;
        input.conteoAperturaId = (_c = this.conteoApertura) === null || _c === void 0 ? void 0 : _c.id;
        input.conteoCierreId = (_d = this.conteoCierre) === null || _d === void 0 ? void 0 : _d.id;
        return input;
    }
}
class PdvCajaInput {
}
var PdvCajaEstado;
(function (PdvCajaEstado) {
    PdvCajaEstado["En proceso"] = "EN_PROCESO";
    PdvCajaEstado["Concluido"] = "CONCLUIDO";
    PdvCajaEstado["Necesita verificacion"] = "NECESITA_VERIFICACION";
    PdvCajaEstado["En verificacion"] = "EN_VERIFICACION";
    PdvCajaEstado["Verificado y concluido sin problema"] = "VERIFICADO_CONCLUIDO_SIN_PROBLEMA";
    PdvCajaEstado["Verificado y concluido con problema"] = "VERIFICADO_CONCLUIDO_CON_PROBLEMA";
})(PdvCajaEstado || (PdvCajaEstado = {}));
class CajaBalance {
}


/***/ }),

/***/ 52404:
/*!********************************************************!*\
  !*** ./src/app/pages/operaciones/caja/caja.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaService": () => (/* binding */ CajaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/cargando.service */ 68030);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _graphql_balancePorFecha__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/balancePorFecha */ 59866);
/* harmony import */ var _graphql_cajaPorId__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql/cajaPorId */ 47520);
/* harmony import */ var _graphql_cajaPorUsuarioIdAndAbierto__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./graphql/cajaPorUsuarioIdAndAbierto */ 7892);
/* harmony import */ var _graphql_cajaPorUsuarioIdAndAbiertoPorSucursal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./graphql/cajaPorUsuarioIdAndAbiertoPorSucursal */ 73001);
/* harmony import */ var _graphql_cajasPorFecha__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./graphql/cajasPorFecha */ 52836);
/* harmony import */ var _graphql_cajasPorUsuario__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./graphql/cajasPorUsuario */ 78310);
/* harmony import */ var _graphql_deleleCaja__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./graphql/deleleCaja */ 55429);
/* harmony import */ var _graphql_imprimirBalance__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./graphql/imprimirBalance */ 62862);
/* harmony import */ var _graphql_saveCaja__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./graphql/saveCaja */ 49883);
/* harmony import */ var _graphql_saveCajaPorSucursal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./graphql/saveCajaPorSucursal */ 66967);



















// import { AbrirCajaGQL } from "./graphql/abrirCaja";
let CajaService = class CajaService {
    constructor(genericService, cajasPorFecha, onSaveCaja, cajaPorId, deleteCaja, cajaPorUsuarioIdAndAbierto, cajaPorUsuarioIdAndAbiertoPorSucursal, imprimirBalance, mainService, balancePorFecha, cargandoService, notificacionService, onSaveCajaPorSucursal, cajasPorUsuario) {
        this.genericService = genericService;
        this.cajasPorFecha = cajasPorFecha;
        this.onSaveCaja = onSaveCaja;
        this.cajaPorId = cajaPorId;
        this.deleteCaja = deleteCaja;
        this.cajaPorUsuarioIdAndAbierto = cajaPorUsuarioIdAndAbierto;
        this.cajaPorUsuarioIdAndAbiertoPorSucursal = cajaPorUsuarioIdAndAbiertoPorSucursal;
        this.imprimirBalance = imprimirBalance;
        this.mainService = mainService;
        this.balancePorFecha = balancePorFecha;
        this.cargandoService = cargandoService;
        this.notificacionService = notificacionService;
        this.onSaveCajaPorSucursal = onSaveCajaPorSucursal;
        this.cajasPorUsuario = cajasPorUsuario;
    }
    // onGetAll(): Observable<any> {
    //   return this.genericService.onGetAll(this.getAllCajas);
    // }
    // onGetByDate(inicio?: Date, fin?: Date): Observable<PdvCaja[]> {
    //   let hoy = new Date();
    //   if (inicio == null) {
    //     inicio = new Date()
    //     inicio.setDate(hoy.getDate() - 2);
    //   }
    //   if (fin == null) {
    //     fin = new Date()
    //     fin = hoy;
    //   }
    //   return this.genericService.onGetByFecha(this.cajasPorFecha, inicio, fin);
    // }
    onGetBalanceByDate(inicio, fin) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            let hoy = new Date();
            if (inicio == null) {
                inicio = new Date();
                inicio.setDate(hoy.getDate() - 2);
            }
            if (fin == null) {
                fin = new Date();
                fin = hoy;
            }
            return yield this.genericService.onGetByFecha(this.balancePorFecha, inicio, fin);
        });
    }
    onSave(input, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onSave(this.onSaveCaja, input, sucId);
        });
    }
    onSavePorSucursal(input, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onSave(this.onSaveCajaPorSucursal, input, sucId);
        });
    }
    onGetById(id, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.cajaPorId, id, null, null, sucId);
        });
    }
    onGetByUsuarioId(id, offset = 0) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            let page = 0;
            let size = 20;
            page = Math.floor(offset / size);
            return yield this.genericService.onGetById(this.cajasPorUsuario, id, page, size);
        });
    }
    onGetByUsuarioIdAndAbierto(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.cajaPorUsuarioIdAndAbierto, id);
        });
    }
    onGetByUsuarioIdAndAbiertoPorSucursal(id, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_16__.Observable((obs) => {
                this.cajaPorUsuarioIdAndAbiertoPorSucursal
                    .fetch({ id, sucId }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    console.log(res);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        if (res.data["data"] != null) {
                            this.notificacionService.success("Item encontrada");
                        }
                    }
                    else {
                        this.notificacionService.open('Ups!! Algo salió mal', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onDelete(id, showDialog) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onDelete(this.deleteCaja, id, showDialog);
        });
    }
    onImprimirBalance(id) {
        return this.imprimirBalance
            .fetch({
            id,
            printerName: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.printers.ticket,
            cajaName: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.local
        }, {
            fetchPolicy: "no-cache",
            errorPolicy: "all",
        }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__.untilDestroyed)(this))
            .subscribe((res) => {
        });
    }
};
CajaService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__.GenericCrudService },
    { type: _graphql_cajasPorFecha__WEBPACK_IMPORTED_MODULE_9__.CajasPorFechaGQL },
    { type: _graphql_saveCaja__WEBPACK_IMPORTED_MODULE_13__.SaveCajaGQL },
    { type: _graphql_cajaPorId__WEBPACK_IMPORTED_MODULE_6__.CajaPorIdGQL },
    { type: _graphql_deleleCaja__WEBPACK_IMPORTED_MODULE_11__.DeleteCajaGQL },
    { type: _graphql_cajaPorUsuarioIdAndAbierto__WEBPACK_IMPORTED_MODULE_7__.CajaPorUsuarioIdAndAbiertoGQL },
    { type: _graphql_cajaPorUsuarioIdAndAbiertoPorSucursal__WEBPACK_IMPORTED_MODULE_8__.CajaPorUsuarioIdAndAbiertoPorSucursalGQL },
    { type: _graphql_imprimirBalance__WEBPACK_IMPORTED_MODULE_12__.ImprimirBalanceGQL },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_2__.MainService },
    { type: _graphql_balancePorFecha__WEBPACK_IMPORTED_MODULE_5__.BalancePorFechaGQL },
    { type: src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_1__.CargandoService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.NotificacionService },
    { type: _graphql_saveCajaPorSucursal__WEBPACK_IMPORTED_MODULE_14__.SaveCajaPorSucursalGQL },
    { type: _graphql_cajasPorUsuario__WEBPACK_IMPORTED_MODULE_10__.CajasPorUsuarioIdGQL }
];
CajaService = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Injectable)({
        providedIn: "root",
    })
], CajaService);



/***/ }),

/***/ 59866:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/balancePorFecha.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BalancePorFechaGQL": () => (/* binding */ BalancePorFechaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let BalancePorFechaGQL = class BalancePorFechaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.balancePorFecha;
    }
};
BalancePorFechaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], BalancePorFechaGQL);



/***/ }),

/***/ 47520:
/*!*************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/cajaPorId.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaPorIdGQL": () => (/* binding */ CajaPorIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let CajaPorIdGQL = class CajaPorIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cajaQuery;
    }
};
CajaPorIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CajaPorIdGQL);



/***/ }),

/***/ 7892:
/*!******************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/cajaPorUsuarioIdAndAbierto.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaPorUsuarioIdAndAbiertoGQL": () => (/* binding */ CajaPorUsuarioIdAndAbiertoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let CajaPorUsuarioIdAndAbiertoGQL = class CajaPorUsuarioIdAndAbiertoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cajaPorUsuarioIdAndAbiertoQuery;
    }
};
CajaPorUsuarioIdAndAbiertoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CajaPorUsuarioIdAndAbiertoGQL);



/***/ }),

/***/ 73001:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/cajaPorUsuarioIdAndAbiertoPorSucursal.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajaPorUsuarioIdAndAbiertoPorSucursalGQL": () => (/* binding */ CajaPorUsuarioIdAndAbiertoPorSucursalGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let CajaPorUsuarioIdAndAbiertoPorSucursalGQL = class CajaPorUsuarioIdAndAbiertoPorSucursalGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cajaAbiertoPorUsuarioIdPorSucursalQuery;
    }
};
CajaPorUsuarioIdAndAbiertoPorSucursalGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CajaPorUsuarioIdAndAbiertoPorSucursalGQL);



/***/ }),

/***/ 52836:
/*!*****************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/cajasPorFecha.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajasPorFechaGQL": () => (/* binding */ CajasPorFechaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let CajasPorFechaGQL = class CajasPorFechaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cajasPorFecha;
    }
};
CajasPorFechaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CajasPorFechaGQL);



/***/ }),

/***/ 78310:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/cajasPorUsuario.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CajasPorUsuarioIdGQL": () => (/* binding */ CajasPorUsuarioIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let CajasPorUsuarioIdGQL = class CajasPorUsuarioIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cajasPorUsuarioIdQuery;
    }
};
CajasPorUsuarioIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CajasPorUsuarioIdGQL);



/***/ }),

/***/ 55429:
/*!**************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/deleleCaja.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteCajaGQL": () => (/* binding */ DeleteCajaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let DeleteCajaGQL = class DeleteCajaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteCajaQuery;
    }
};
DeleteCajaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteCajaGQL);



/***/ }),

/***/ 53574:
/*!*****************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/graphql-query.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "abrirCajaDesdeServidorQuery": () => (/* binding */ abrirCajaDesdeServidorQuery),
/* harmony export */   "balancePorFecha": () => (/* binding */ balancePorFecha),
/* harmony export */   "cajaAbiertoPorUsuarioIdPorSucursalQuery": () => (/* binding */ cajaAbiertoPorUsuarioIdPorSucursalQuery),
/* harmony export */   "cajaPorUsuarioIdAndAbiertoQuery": () => (/* binding */ cajaPorUsuarioIdAndAbiertoQuery),
/* harmony export */   "cajaQuery": () => (/* binding */ cajaQuery),
/* harmony export */   "cajasPorFecha": () => (/* binding */ cajasPorFecha),
/* harmony export */   "cajasPorUsuarioIdQuery": () => (/* binding */ cajasPorUsuarioIdQuery),
/* harmony export */   "cajasQuery": () => (/* binding */ cajasQuery),
/* harmony export */   "deleteCajaQuery": () => (/* binding */ deleteCajaQuery),
/* harmony export */   "imprimirBalanceQuery": () => (/* binding */ imprimirBalanceQuery),
/* harmony export */   "savePdvCaja": () => (/* binding */ savePdvCaja),
/* harmony export */   "savePdvCajaPorSucursal": () => (/* binding */ savePdvCajaPorSucursal)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const cajasQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query($page:Int, $size:Int, $sucId:ID){
    data: cajas(page:$page, size:$size, sucId:$sucId) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const cajasPorUsuarioIdQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query($id:ID!, $page:Int, $size:Int){
    data: cajasPorUsuarioId(id: $id, page:$page, size:$size) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
      sucursal {
        id
        nombre
      }
    }
  }
`;
const cajasPorFecha = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($inicio: String, $fin: String, $sucId:ID) {
    data: cajasPorFecha(inicio: $inicio, fin: $fin, sucId:$susId) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const balancePorFecha = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($inicio: String, $fin: String,$sucId:ID) {
    data: balancePorFecha(inicio: $inicio, fin: $fin, sucId:$sucId) {
      totalVentaGs
      totalVentaRs
      totalVentaDs
      totalTarjeta
    }
  }
`;
// export const cajasSearch = gql`
//   query ($texto: String) {
//     cajas: cajasSearch(texto: $texto) {
//       id
//       responsable {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       tipoCaja {
//         id
//         descripcion
//         autorizacion
//       }
//       autorizadoPor {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       observacion
//       creadoEn
//       usuario {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       cajaDetalleList {
//         id
//         moneda {
//           id
//           denominacion
//         }
//         cambio {
//           id
//           valorEnGs
//         }
//         cantidad
//       }
//     }
//   }
// `;
const cajaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $sucId:ID) {
    data: pdvCaja(id: $id, sucId:$sucId) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
      conteoApertura {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      conteoCierre {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      balance {
        totalGeneral
        diferenciaGs
        diferenciaRs
        diferenciaDs
      }
    }
  }
`;
const cajaPorUsuarioIdAndAbiertoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: cajaAbiertoPorUsuarioId(id: $id) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
      conteoApertura {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      conteoCierre {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      sucursal {
        id
        nombre
      }
    }
  }
`;
const cajaAbiertoPorUsuarioIdPorSucursalQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $sucId: ID) {
    data: cajaAbiertoPorUsuarioIdPorSucursal(id: $id, sucId: $sucId) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
      conteoApertura {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      conteoCierre {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
    }
  }
`;
const savePdvCaja = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation savePdvCaja($entity: PdvCajaInput!) {
    data: savePdvCaja(pdvCaja: $entity) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
      conteoApertura {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      conteoCierre {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
    }
  }
`;
const savePdvCajaPorSucursal = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation savePdvCajaPorSucursal($entity: PdvCajaInput!) {
    data: savePdvCajaPorSucursal(pdvCaja: $entity) {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
      conteoApertura {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
      conteoCierre {
        id
        observacion
        creadoEn
        conteoMonedaList {
          id
          monedaBilletes {
            id
            moneda {
              id
              denominacion
            }
            valor
          }
          cantidad
        }
      }
    }
  }
`;
const abrirCajaDesdeServidorQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation abrirCajaDesdeServidor($input:PdvCajaInput!, $conteoInput: ConteoInput!, $conteoMonedaInputList: [ConteoMonedaInput]) {
    abrirCajaDesdeServidor($input:input, $conteoInput: conteoInput, $conteoMonedaInputList: conteoMonedaInputList)
  }
`;
const deleteCajaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deletePdvCaja($id: ID!, $sucId: ID) {
    deletePdvCaja(id: $id, sucId:$sucId)
  }
`;
const imprimirBalanceQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query imprimirBalance(
    $id: ID!
    $printerName: String
    $local: String
    $sucId: ID
    ) {
    imprimirBalance(
      id: $id
      printerName: $printerName
      local: $local,
      sucId: $sucId
      ) {
      id
    }
  }
`;


/***/ }),

/***/ 62862:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/imprimirBalance.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImprimirBalanceGQL": () => (/* binding */ ImprimirBalanceGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let ImprimirBalanceGQL = class ImprimirBalanceGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.imprimirBalanceQuery;
    }
};
ImprimirBalanceGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ImprimirBalanceGQL);



/***/ }),

/***/ 49883:
/*!************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/saveCaja.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveCajaGQL": () => (/* binding */ SaveCajaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let SaveCajaGQL = class SaveCajaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.savePdvCaja;
    }
};
SaveCajaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveCajaGQL);



/***/ }),

/***/ 66967:
/*!***********************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/graphql/saveCajaPorSucursal.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveCajaPorSucursalGQL": () => (/* binding */ SaveCajaPorSucursalGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 53574);




let SaveCajaPorSucursalGQL = class SaveCajaPorSucursalGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.savePdvCajaPorSucursal;
    }
};
SaveCajaPorSucursalGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveCajaPorSucursalGQL);



/***/ }),

/***/ 53049:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/adicionar-conteo-dialog/adicionar-conteo-dialog.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdicionarConteoDialogComponent": () => (/* binding */ AdicionarConteoDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _adicionar_conteo_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adicionar-conteo-dialog.component.html?ngResource */ 82752);
/* harmony import */ var _adicionar_conteo_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./adicionar-conteo-dialog.component.scss?ngResource */ 34815);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/modal.service */ 71609);
/* harmony import */ var _caja_caja_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../caja/caja.service */ 52404);
/* harmony import */ var _moneda_moneda_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../moneda/moneda.service */ 29864);
/* harmony import */ var _conteo_moneda_conteo_moneda_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../conteo-moneda/conteo-moneda.model */ 25816);
/* harmony import */ var _conteo_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../conteo.model */ 29570);
/* harmony import */ var _conteo_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../conteo.service */ 40137);














let AdicionarConteoDialogComponent = class AdicionarConteoDialogComponent {
    constructor(modalService, dialogoService, monedaService, conteoService, cajaService, mainService) {
        this.modalService = modalService;
        this.dialogoService = dialogoService;
        this.monedaService = monedaService;
        this.conteoService = conteoService;
        this.cajaService = cajaService;
        this.mainService = mainService;
        this.moneda = 'gs';
        this.totalGs = 0;
        this.totalRs = 0;
        this.totalDs = 0;
        this.isApertura = false;
        if (cajaService.selectedCaja != null) {
            this.selectedCaja = cajaService.selectedCaja;
        }
        else {
            modalService.closeModal(null);
        }
        this.gsFormGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
            '500': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '1000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '2000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '5000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '10000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '20000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '50000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '100000': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
        });
        this.rsFormGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
            '0.05': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '0.1': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '0.25': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '0.5': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '1': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '2': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '5': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '10': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '20': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '50': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '100': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '200': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
        });
        this.dsFormGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
            '1': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '5': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '10': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '20': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '50': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
            '100': new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(0)]),
        });
        this.cargarMonedas();
    }
    ngOnInit() {
        this.isApertura = this.data == true;
        this.gsFormGroup.valueChanges.pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe(res => {
            this.sumarGs();
        });
        this.rsFormGroup.valueChanges.pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe(res => {
            this.sumarRs();
        });
        this.dsFormGroup.valueChanges.pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe(res => {
            this.sumarDs();
        });
    }
    cargarMonedas() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.monedaService.onGetAll()).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe((res) => {
                if (res != null) {
                    let monedaList = res;
                    monedaList.forEach((m) => {
                        switch (m.denominacion) {
                            case "GUARANI":
                                this.guarani = m;
                                this.guaraniList = m.monedaBilleteList;
                                break;
                            case "REAL":
                                this.real = m;
                                this.realList = m.monedaBilleteList;
                                break;
                            case "DOLAR":
                                this.dolar = m;
                                this.dolarList = m.monedaBilleteList;
                                break;
                            default:
                                break;
                        }
                    });
                }
            });
        });
    }
    onBack() {
        this.modalService.closeModal(null);
    }
    tabClick(e) {
        this.moneda = e;
    }
    sumarGs() {
        this.totalGs = 0;
        Object.keys(this.gsFormGroup.controls).forEach(key => {
            this.totalGs += this.gsFormGroup.controls[key].value * +key;
        });
    }
    sumarRs() {
        this.totalRs = 0;
        Object.keys(this.rsFormGroup.controls).forEach(key => {
            this.totalRs += this.rsFormGroup.controls[key].value * +key;
        });
    }
    sumarDs() {
        this.totalDs = 0;
        Object.keys(this.dsFormGroup.controls).forEach(key => {
            this.totalDs += this.dsFormGroup.controls[key].value * +key;
        });
    }
    onGuardar() {
        let conteo = new _conteo_model__WEBPACK_IMPORTED_MODULE_8__.Conteo();
        conteo.totalGs = this.totalGs;
        conteo.totalRs = this.totalRs;
        conteo.totalDs = this.totalDs;
        conteo.conteoMonedaList = this.createMonedaBilletes();
        this.dialogoService.open('Atención', 'Estas seguro que deseas guardar este conteo?').then(res => {
            var _a;
            if (res.role == 'aceptar') {
                if (this.cajaService.selectedCaja != null) {
                    this.conteoService
                        .onSave(conteo, (_a = this.cajaService.selectedCaja) === null || _a === void 0 ? void 0 : _a.id, this.isApertura, this.cajaService.selectedCaja.sucursal.id)
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this))
                        .subscribe((res) => {
                        if (res != null) {
                            this.modalService.closeModal(res);
                        }
                    });
                }
                else {
                    this.modalService.closeModal({ conteo: conteo });
                }
            }
        });
    }
    onCancel() {
        this.modalService.closeModal(null);
    }
    createMonedaBilletes() {
        var _a, _b, _c;
        this.conteoMonedaList = [];
        (_a = this.guaraniList) === null || _a === void 0 ? void 0 : _a.forEach((e) => {
            var _a;
            let conteoMoneda = new _conteo_moneda_conteo_moneda_model__WEBPACK_IMPORTED_MODULE_7__.ConteoMoneda();
            let cantidad = (_a = this.gsFormGroup.get(`${e.valor}`)) === null || _a === void 0 ? void 0 : _a.value;
            if (cantidad != null) {
                conteoMoneda.cantidad = cantidad;
                conteoMoneda.monedaBilletes = e;
                this.conteoMonedaList.push(conteoMoneda);
            }
        });
        (_b = this.realList) === null || _b === void 0 ? void 0 : _b.forEach((e) => {
            var _a;
            let conteoMoneda = new _conteo_moneda_conteo_moneda_model__WEBPACK_IMPORTED_MODULE_7__.ConteoMoneda();
            let cantidad = (_a = this.rsFormGroup.get(`${e.valor}`.replace(".", ""))) === null || _a === void 0 ? void 0 : _a.value;
            if (cantidad != null) {
                conteoMoneda.cantidad = cantidad;
                conteoMoneda.monedaBilletes = e;
                this.conteoMonedaList.push(conteoMoneda);
            }
        });
        (_c = this.dolarList) === null || _c === void 0 ? void 0 : _c.forEach((e) => {
            var _a;
            let conteoMoneda = new _conteo_moneda_conteo_moneda_model__WEBPACK_IMPORTED_MODULE_7__.ConteoMoneda();
            let cantidad = (_a = this.dsFormGroup.get(`${e.valor}`.replace(".", ""))) === null || _a === void 0 ? void 0 : _a.value;
            if (cantidad != null) {
                conteoMoneda.cantidad = cantidad;
                conteoMoneda.monedaBilletes = e;
                this.conteoMonedaList.push(conteoMoneda);
            }
        });
        return this.conteoMonedaList;
    }
};
AdicionarConteoDialogComponent.ctorParameters = () => [
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_4__.ModalService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService },
    { type: _moneda_moneda_service__WEBPACK_IMPORTED_MODULE_6__.MonedaService },
    { type: _conteo_service__WEBPACK_IMPORTED_MODULE_9__.ConteoService },
    { type: _caja_caja_service__WEBPACK_IMPORTED_MODULE_5__.CajaService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__.MainService }
];
AdicionarConteoDialogComponent.propDecorators = {
    rsInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild, args: ['rs',] }],
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.Input }]
};
AdicionarConteoDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-adicionar-conteo-dialog',
        template: _adicionar_conteo_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_adicionar_conteo_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AdicionarConteoDialogComponent);



/***/ }),

/***/ 25816:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo-moneda/conteo-moneda.model.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConteoMoneda": () => (/* binding */ ConteoMoneda),
/* harmony export */   "ConteoMonedaInput": () => (/* binding */ ConteoMonedaInput)
/* harmony export */ });
class ConteoMoneda {
    toInput() {
        var _a, _b, _c;
        let input = new ConteoMonedaInput();
        input.id = this.id;
        input.observacion = this.observacion;
        input.usuarioId = (_a = this.usuario) === null || _a === void 0 ? void 0 : _a.id;
        input.cantidad = this.cantidad;
        input.creadoEn = this.creadoEn;
        input.conteoId = (_b = this.conteo) === null || _b === void 0 ? void 0 : _b.id;
        input.monedaBilletesId = (_c = this.monedaBilletes) === null || _c === void 0 ? void 0 : _c.id;
        return input;
    }
}
class ConteoMonedaInput {
}


/***/ }),

/***/ 28068:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo-moneda/conteo-moneda.service.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConteoMonedaService": () => (/* binding */ ConteoMonedaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var _graphql_deleleConteoMoneda__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./graphql/deleleConteoMoneda */ 86911);
/* harmony import */ var _graphql_saveConteoMoneda__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./graphql/saveConteoMoneda */ 91387);





let ConteoMonedaService = class ConteoMonedaService {
    constructor(genericService, onSaveConteoMoneda, deleteConteoMoneda) {
        this.genericService = genericService;
        this.onSaveConteoMoneda = onSaveConteoMoneda;
        this.deleteConteoMoneda = deleteConteoMoneda;
    }
    onSave(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onSave(this.onSaveConteoMoneda, input);
        });
    }
    onDelete(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onDelete(this.deleteConteoMoneda, id);
        });
    }
};
ConteoMonedaService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__.GenericCrudService },
    { type: _graphql_saveConteoMoneda__WEBPACK_IMPORTED_MODULE_2__.SaveConteoMonedaGQL },
    { type: _graphql_deleleConteoMoneda__WEBPACK_IMPORTED_MODULE_1__.DeleteConteoMonedaGQL }
];
ConteoMonedaService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], ConteoMonedaService);



/***/ }),

/***/ 86911:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo-moneda/graphql/deleleConteoMoneda.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteConteoMonedaGQL": () => (/* binding */ DeleteConteoMonedaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63100);




let DeleteConteoMonedaGQL = class DeleteConteoMonedaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteConteoMonedaQuery;
    }
};
DeleteConteoMonedaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteConteoMonedaGQL);



/***/ }),

/***/ 63100:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo-moneda/graphql/graphql-query.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteConteoMonedaQuery": () => (/* binding */ deleteConteoMonedaQuery),
/* harmony export */   "saveConteoMoneda": () => (/* binding */ saveConteoMoneda)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

// export const conteosQuery = gql`
//   {
//     data: conteos {
//       id
//       descripcion
//       activo
//       estado
//       tuvoProblema
//       fechaApertura
//       fechaCierre
//       observacion
//       maletin {
//         id
//         descripcion
//       }
//       creadoEn
//       usuario {
//         id
//         persona {
//           nombre
//         }
//       }
//     }
//   }
// `;
// export const conteoMonedasPorCajaId = gql`
//   query ($id: ID!) {
//     data: conteoMonedasPorCajaId(id: $id) {
//       id
//       descripcion
//       activo
//       estado
//       tuvoProblema
//       fechaApertura
//       fechaCierre
//       observacion
//       maletin {
//         id
//         descripcion
//       }
//       creadoEn
//       usuario {
//         id
//         persona {
//           nombre
//         }
//       }
//     }
//   }
// `;
// export const conteoMonedasSearch = gql`
//   query ($texto: String) {
//     conteoMonedas: conteoMonedasSearch(texto: $texto) {
//       id
//       responsable {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       tipoConteoMoneda {
//         id
//         descripcion
//         autorizacion
//       }
//       autorizadoPor {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       observacion
//       creadoEn
//       usuario {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       conteoMonedaDetalleList {
//         id
//         moneda {
//           id
//           denominacion
//         }
//         cambio {
//           id
//           valorEnGs
//         }
//         cantidad
//       }
//     }
//   }
// `;
// export const conteoMonedaQuery = gql`
//   query ($id: ID!) {
//     data: conteoMoneda(id: $id) {
//       id
//       descripcion
//       activo
//       estado
//       tuvoProblema
//       fechaApertura
//       fechaCierre
//       observacion
//       maletin {
//         id
//         descripcion
//       }
//       creadoEn
//       usuario {
//         id
//         persona {
//           nombre
//         }
//       }
//     }
//   }
// `;
const saveConteoMoneda = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveConteoMoneda($entity: ConteoMonedaInput!) {
    data: saveConteoMoneda(conteoMoneda: $entity) {
      id
      monedaBilletes {
        id
        moneda {
          id
          denominacion
        }
        flotante
        papel
        activo
        valor
      }
      cantidad
      observacion
    }
  }
`;
const deleteConteoMonedaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteConteoMoneda($id: ID!) {
    deleteConteoMoneda(id: $id)
  }
`;


/***/ }),

/***/ 91387:
/*!************************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo-moneda/graphql/saveConteoMoneda.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveConteoMonedaGQL": () => (/* binding */ SaveConteoMonedaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63100);




let SaveConteoMonedaGQL = class SaveConteoMonedaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveConteoMoneda;
    }
};
SaveConteoMonedaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveConteoMonedaGQL);



/***/ }),

/***/ 29570:
/*!**********************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo.model.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Conteo": () => (/* binding */ Conteo),
/* harmony export */   "ConteoInput": () => (/* binding */ ConteoInput)
/* harmony export */ });
class Conteo {
    toInput() {
        var _a;
        let conteoInput = new ConteoInput();
        conteoInput.id = this.id;
        conteoInput.observacion = this.observacion;
        conteoInput.usuarioId = (_a = this.usuario) === null || _a === void 0 ? void 0 : _a.id;
        conteoInput.creadoEn = this.creadoEn;
        conteoInput.totalGs = this.totalGs;
        conteoInput.totalRs = this.totalRs;
        conteoInput.totalDs = this.totalDs;
        return conteoInput;
    }
    toInpuList() {
        let aux = [];
        this.conteoMonedaList.forEach(cm => {
            aux.push(cm.toInput());
        });
        return aux;
    }
}
class ConteoInput {
}


/***/ }),

/***/ 40137:
/*!************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/conteo.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConteoService": () => (/* binding */ ConteoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _conteo_moneda_conteo_moneda_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./conteo-moneda/conteo-moneda.service */ 28068);
/* harmony import */ var _graphql_deleleConteo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./graphql/deleleConteo */ 69319);
/* harmony import */ var _graphql_saveConteo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/saveConteo */ 17696);










let ConteoService = class ConteoService {
    constructor(genericService, onSaveConteo, deleteConteo, conteoMonedaService, notificacionService, mainService) {
        this.genericService = genericService;
        this.onSaveConteo = onSaveConteo;
        this.deleteConteo = deleteConteo;
        this.conteoMonedaService = conteoMonedaService;
        this.notificacionService = notificacionService;
        this.mainService = mainService;
    }
    onSave(conteo, cajaId, apertura, sucId) {
        if (conteo.usuario == null) {
            conteo.usuario = this.mainService.usuarioActual;
        }
        let conteoMonedaInputList = [];
        conteo.conteoMonedaList.forEach(c => conteoMonedaInputList.push(c.toInput()));
        return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((obs) => {
            this.onSaveConteo.mutate({
                conteo: conteo.toInput(),
                conteoMonedaInputList,
                cajaId,
                apertura,
                sucId
            }, { fetchPolicy: 'no-cache', errorPolicy: 'all' })
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.untilDestroyed)(this))
                .subscribe(res => {
                if (res.errors == null) {
                    obs.next(res.data['data']);
                    this.notificacionService.openGuardadoConExito();
                }
                else {
                    this.notificacionService.openAlgoSalioMal();
                    obs.next(null);
                }
            });
        });
    }
};
ConteoService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__.GenericCrudService },
    { type: _graphql_saveConteo__WEBPACK_IMPORTED_MODULE_5__.SaveConteoGQL },
    { type: _graphql_deleleConteo__WEBPACK_IMPORTED_MODULE_4__.DeleteConteoGQL },
    { type: _conteo_moneda_conteo_moneda_service__WEBPACK_IMPORTED_MODULE_3__.ConteoMonedaService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_2__.NotificacionService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_1__.MainService }
];
ConteoService = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Injectable)({
        providedIn: "root",
    })
], ConteoService);



/***/ }),

/***/ 69319:
/*!******************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/graphql/deleleConteo.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteConteoGQL": () => (/* binding */ DeleteConteoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 44841);




let DeleteConteoGQL = class DeleteConteoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteConteoQuery;
    }
};
DeleteConteoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteConteoGQL);



/***/ }),

/***/ 44841:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/graphql/graphql-query.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "conteosQuery": () => (/* binding */ conteosQuery),
/* harmony export */   "deleteConteoQuery": () => (/* binding */ deleteConteoQuery),
/* harmony export */   "saveConteo": () => (/* binding */ saveConteo)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const conteosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: conteos {
      id
      descripcion
      activo
      estado
      tuvoProblema
      fechaApertura
      fechaCierre
      observacion
      maletin {
        id
        descripcion
      }
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
// export const conteosPorCajaId = gql`
//   query ($id: ID!) {
//     data: conteosPorCajaId(id: $id) {
//       id
//       descripcion
//       activo
//       estado
//       tuvoProblema
//       fechaApertura
//       fechaCierre
//       observacion
//       maletin {
//         id
//         descripcion
//       }
//       creadoEn
//       usuario {
//         id
//         persona {
//           nombre
//         }
//       }
//     }
//   }
// `;
// export const conteosSearch = gql`
//   query ($texto: String) {
//     conteos: conteosSearch(texto: $texto) {
//       id
//       responsable {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       tipoConteo {
//         id
//         descripcion
//         autorizacion
//       }
//       autorizadoPor {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       observacion
//       creadoEn
//       usuario {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       conteoDetalleList {
//         id
//         moneda {
//           id
//           denominacion
//         }
//         cambio {
//           id
//           valorEnGs
//         }
//         cantidad
//       }
//     }
//   }
// `;
// export const conteoQuery = gql`
//   query ($id: ID!) {
//     data: conteo(id: $id) {
//       id
//       descripcion
//       activo
//       estado
//       tuvoProblema
//       fechaApertura
//       fechaCierre
//       observacion
//       maletin {
//         id
//         descripcion
//       }
//       creadoEn
//       usuario {
//         id
//         persona {
//           nombre
//         }
//       }
//     }
//   }
// `;
const saveConteo = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveConteo(
    $conteo: ConteoInput!
    $conteoMonedaInputList: [ConteoMonedaInput]
    $cajaId: Int!
    $apertura: Boolean
    $sucId: Int!
  ) {
    data: saveConteo(
      conteo: $conteo
      conteoMonedaInputList: $conteoMonedaInputList
      cajaId: $cajaId
      apertura: $apertura
      sucId: $sucId
    ) {
      id
      observacion
      creadoEn
      conteoMonedaList {
        id
        monedaBilletes {
          id
          moneda {
            id
            denominacion
          }
          flotante
          papel
          activo
          valor
        }
        cantidad
        observacion
      }
    }
  }
`;
const deleteConteoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteConteo($id: ID!) {
    deleteConteo(id: $id)
  }
`;


/***/ }),

/***/ 17696:
/*!****************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/graphql/saveConteo.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveConteoGQL": () => (/* binding */ SaveConteoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 44841);




let SaveConteoGQL = class SaveConteoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveConteo;
    }
};
SaveConteoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveConteoGQL);



/***/ }),

/***/ 66803:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/operaciones/list-operaciones/list-operaciones.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListOperacionesComponent": () => (/* binding */ ListOperacionesComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _list_operaciones_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-operaciones.component.html?ngResource */ 98010);
/* harmony import */ var _list_operaciones_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-operaciones.component.scss?ngResource */ 29792);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let ListOperacionesComponent = class ListOperacionesComponent {
    constructor() { }
    ngOnInit() { }
};
ListOperacionesComponent.ctorParameters = () => [];
ListOperacionesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-list-operaciones',
        template: _list_operaciones_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_list_operaciones_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListOperacionesComponent);



/***/ }),

/***/ 32271:
/*!******************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/graphql/MaletinById.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaletinByIdGQL": () => (/* binding */ MaletinByIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 33583);




let MaletinByIdGQL = class MaletinByIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.maletinQuery;
    }
};
MaletinByIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], MaletinByIdGQL);



/***/ }),

/***/ 88489:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/graphql/allMaletines.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AllMaletinsGQL": () => (/* binding */ AllMaletinsGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 33583);




let AllMaletinsGQL = class AllMaletinsGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.maletinsQuery;
    }
};
AllMaletinsGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], AllMaletinsGQL);



/***/ }),

/***/ 23369:
/*!********************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/graphql/deleteMaletin.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteMaletinGQL": () => (/* binding */ DeleteMaletinGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 33583);




let DeleteMaletinGQL = class DeleteMaletinGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteMaletinQuery;
    }
};
DeleteMaletinGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteMaletinGQL);



/***/ }),

/***/ 33583:
/*!********************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/graphql/graphql-query.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteMaletinQuery": () => (/* binding */ deleteMaletinQuery),
/* harmony export */   "maletinPorDescripcionPorSucursalQuery": () => (/* binding */ maletinPorDescripcionPorSucursalQuery),
/* harmony export */   "maletinPorDescripcionQuery": () => (/* binding */ maletinPorDescripcionQuery),
/* harmony export */   "maletinQuery": () => (/* binding */ maletinQuery),
/* harmony export */   "maletinsQuery": () => (/* binding */ maletinsQuery),
/* harmony export */   "saveMaletin": () => (/* binding */ saveMaletin),
/* harmony export */   "searchMaletinQuery": () => (/* binding */ searchMaletinQuery)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const maletinsQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: maletines {
      id
      descripcion
      activo
      abierto
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
// export const maletinsSearch = gql`
//   query ($texto: String) {
//     data: maletinsSearch(texto: $texto) {
//       id
//       credito
//       diarista
//       sueldo
//       fechaIngreso
//       creadoEn
//       fasePrueba
//       activo
//       nickname
//       persona {
//         id
//         nombre
//         telefono
//       }
//       cargo {
//         id
//         nombre
//       }
//       supervisadoPor {
//         id
//         persona {
//           id
//           nombre
//         }
//       }
//       sucursal {
//         id
//         nombre
//       }
//     }
//   }
// `;
const maletinQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: maletin(id: $id) {
      id
      descripcion
      activo
      abierto
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const maletinPorDescripcionQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: maletinPorDescripcion(texto: $texto) {
      id
      descripcion
      activo
      abierto
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const maletinPorDescripcionPorSucursalQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: maletinPorDescripcion(texto: $texto) {
      id
      descripcion
      activo
      abierto
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const searchMaletinQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: searchMaletin(texto: $texto) {
      id
      descripcion
      activo
      abierto
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const saveMaletin = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveMaletin($entity: MaletinInput!) {
    data: saveMaletin(maletin: $entity) {
      id
      descripcion
      activo
      abierto
      creadoEn
      usuario {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const deleteMaletinQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteMaletin($id: ID!) {
    deleteMaletin(id: $id)
  }
`;


/***/ }),

/***/ 32700:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/graphql/maletinPorDescripcionPorSucursal.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaletinPorDescripcionPorSucursalGQL": () => (/* binding */ MaletinPorDescripcionPorSucursalGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 33583);




let MaletinPorDescripcionPorSucursalGQL = class MaletinPorDescripcionPorSucursalGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.maletinPorDescripcionPorSucursalQuery;
    }
};
MaletinPorDescripcionPorSucursalGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], MaletinPorDescripcionPorSucursalGQL);



/***/ }),

/***/ 11493:
/*!******************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/graphql/saveMaletin.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveMaletinGQL": () => (/* binding */ SaveMaletinGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 33583);




let SaveMaletinGQL = class SaveMaletinGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveMaletin;
    }
};
SaveMaletinGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveMaletinGQL);



/***/ }),

/***/ 87416:
/*!**************************************************************!*\
  !*** ./src/app/pages/operaciones/maletin/maletin.service.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaletinService": () => (/* binding */ MaletinService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var _graphql_allMaletines__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./graphql/allMaletines */ 88489);
/* harmony import */ var _graphql_deleteMaletin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./graphql/deleteMaletin */ 23369);
/* harmony import */ var _graphql_MaletinById__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./graphql/MaletinById */ 32271);
/* harmony import */ var _graphql_maletinPorDescripcionPorSucursal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./graphql/maletinPorDescripcionPorSucursal */ 32700);
/* harmony import */ var _graphql_saveMaletin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/saveMaletin */ 11493);








let MaletinService = class MaletinService {
    constructor(getAllMaletines, getMaletinPorId, genericCrud, saveMaletin, deleteMaletin, getMaletinPorDescripcion) {
        this.getAllMaletines = getAllMaletines;
        this.getMaletinPorId = getMaletinPorId;
        this.genericCrud = genericCrud;
        this.saveMaletin = saveMaletin;
        this.deleteMaletin = deleteMaletin;
        this.getMaletinPorDescripcion = getMaletinPorDescripcion;
    }
    onGetAll() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetAll(this.getAllMaletines);
        });
    }
    onGetPorId(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetById(this.getMaletinPorId, id);
        });
    }
    onGetPorDescripcion(texto) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetByTexto(this.getMaletinPorDescripcion, texto);
        });
    }
    onSave(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onSave(this.saveMaletin, input);
        });
    }
    onDelete(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onDelete(this.deleteMaletin, id, 'Maletin', `Id: ${id}`);
        });
    }
};
MaletinService.ctorParameters = () => [
    { type: _graphql_allMaletines__WEBPACK_IMPORTED_MODULE_1__.AllMaletinsGQL },
    { type: _graphql_MaletinById__WEBPACK_IMPORTED_MODULE_3__.MaletinByIdGQL },
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__.GenericCrudService },
    { type: _graphql_saveMaletin__WEBPACK_IMPORTED_MODULE_5__.SaveMaletinGQL },
    { type: _graphql_deleteMaletin__WEBPACK_IMPORTED_MODULE_2__.DeleteMaletinGQL },
    { type: _graphql_maletinPorDescripcionPorSucursal__WEBPACK_IMPORTED_MODULE_4__.MaletinPorDescripcionPorSucursalGQL }
];
MaletinService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
        providedIn: 'root'
    })
], MaletinService);



/***/ }),

/***/ 36015:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/moneda/graphql/graphql-query.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteMonedaQuery": () => (/* binding */ deleteMonedaQuery),
/* harmony export */   "monedaQuery": () => (/* binding */ monedaQuery),
/* harmony export */   "monedasQuery": () => (/* binding */ monedasQuery),
/* harmony export */   "monedasSearch": () => (/* binding */ monedasSearch),
/* harmony export */   "saveMoneda": () => (/* binding */ saveMoneda)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const monedasQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: monedas {
      id
      denominacion
      simbolo
      pais {
        id
        descripcion
      }
      cambio
      monedaBilleteList {
        id
        flotante
        papel
        activo
        valor
        moneda {
          id
          denominacion
        }
      }
    }
  }
`;
const monedasSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    monedas: monedasSearch(texto: $texto) {
      id
      denominacion
      simbolo
      pais {
        id
        descripcion
      }
      cambio
      monedaBilleteList {
        id
        flotante
        papel
        activo
        valor
        moneda {
          id
          denominacion
        }
      }
    }
  }
`;
const monedaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    moneda(id: $id) {
      id
      denominacion
      simbolo
      pais {
        id
        descripcion
      }
      cambio
      monedaBilleteList {
        id
        flotante
        papel
        activo
        valor
        moneda {
          id
          denominacion
        }
      }
    }
  }
`;
const saveMoneda = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveMoneda($entity: MonedaInput!) {
    data: saveMoneda(moneda: $entity) {
      id
      denominacion
      simbolo
      pais {
        id
        descripcion
      }
      cambio
      monedaBilleteList {
        id
        flotante
        papel
        activo
        valor
      }
    }
  }
`;
const deleteMonedaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteMoneda($id: ID!) {
    deleteMoneda(id: $id)
  }
`;


/***/ }),

/***/ 24347:
/*!*******************************************************************!*\
  !*** ./src/app/pages/operaciones/moneda/graphql/monedasGetAll.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MonedasGetAllGQL": () => (/* binding */ MonedasGetAllGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 36015);




let MonedasGetAllGQL = class MonedasGetAllGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.monedasQuery;
    }
};
MonedasGetAllGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], MonedasGetAllGQL);



/***/ }),

/***/ 29864:
/*!************************************************************!*\
  !*** ./src/app/pages/operaciones/moneda/moneda.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MonedaService": () => (/* binding */ MonedaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _graphql_monedasGetAll__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/monedasGetAll */ 24347);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);





let MonedaService = class MonedaService {
    constructor(getAllMonedas, genericService) {
        this.getAllMonedas = getAllMonedas;
        this.genericService = genericService;
    }
    onGetAll() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetAll(this.getAllMonedas);
        });
    }
};
MonedaService.ctorParameters = () => [
    { type: _graphql_monedasGetAll__WEBPACK_IMPORTED_MODULE_0__.MonedasGetAllGQL },
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_1__.GenericCrudService }
];
MonedaService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_3__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], MonedaService);



/***/ }),

/***/ 4297:
/*!*****************************************************************!*\
  !*** ./src/app/pages/operaciones/operaciones-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OperacionesRoutingModule": () => (/* binding */ OperacionesRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _caja_info_caja_info_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./caja-info/caja-info.component */ 70081);
/* harmony import */ var _caja_caja_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./caja/caja.component */ 55760);
/* harmony import */ var _list_operaciones_list_operaciones_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./list-operaciones/list-operaciones.component */ 66803);






const routes = [
    {
        path: '',
        component: _list_operaciones_list_operaciones_component__WEBPACK_IMPORTED_MODULE_2__.ListOperacionesComponent
    },
    {
        path: 'caja',
        component: _caja_caja_component__WEBPACK_IMPORTED_MODULE_1__.CajaComponent,
    },
    {
        path: 'caja/info',
        component: _caja_info_caja_info_component__WEBPACK_IMPORTED_MODULE_0__.CajaInfoComponent
    }
];
let OperacionesRoutingModule = class OperacionesRoutingModule {
};
OperacionesRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
    })
], OperacionesRoutingModule);



/***/ }),

/***/ 51264:
/*!*********************************************************!*\
  !*** ./src/app/pages/operaciones/operaciones.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OperacionesModule": () => (/* binding */ OperacionesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _list_operaciones_list_operaciones_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-operaciones/list-operaciones.component */ 66803);
/* harmony import */ var _caja_caja_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./caja/caja.component */ 55760);
/* harmony import */ var _operaciones_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./operaciones-routing.module */ 4297);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/components.module */ 45642);
/* harmony import */ var _caja_info_caja_info_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./caja-info/caja-info.component */ 70081);
/* harmony import */ var _conteo_adicionar_conteo_dialog_adicionar_conteo_dialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./conteo/adicionar-conteo-dialog/adicionar-conteo-dialog.component */ 53049);
/* harmony import */ var _caja_buscar_maletin_dialog_buscar_maletin_dialog_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./caja/buscar-maletin-dialog/buscar-maletin-dialog.component */ 3929);












let OperacionesModule = class OperacionesModule {
};
OperacionesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [
            _list_operaciones_list_operaciones_component__WEBPACK_IMPORTED_MODULE_0__.ListOperacionesComponent,
            _caja_caja_component__WEBPACK_IMPORTED_MODULE_1__.CajaComponent,
            _caja_info_caja_info_component__WEBPACK_IMPORTED_MODULE_4__.CajaInfoComponent,
            _conteo_adicionar_conteo_dialog_adicionar_conteo_dialog_component__WEBPACK_IMPORTED_MODULE_5__.AdicionarConteoDialogComponent,
            _caja_buscar_maletin_dialog_buscar_maletin_dialog_component__WEBPACK_IMPORTED_MODULE_6__.BuscarMaletinDialogComponent
        ],
        imports: [
            _operaciones_routing_module__WEBPACK_IMPORTED_MODULE_2__.OperacionesRoutingModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_3__.ComponentsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
        ],
        exports: [
            _conteo_adicionar_conteo_dialog_adicionar_conteo_dialog_component__WEBPACK_IMPORTED_MODULE_5__.AdicionarConteoDialogComponent
        ]
    })
], OperacionesModule);



/***/ }),

/***/ 65573:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja-info/caja-info.component.scss?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "ion-input {\n  text-transform: uppercase;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhamEtaW5mby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0YiLCJmaWxlIjoiY2FqYS1pbmZvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWlucHV0IHtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbn1cbiJdfQ== */";

/***/ }),

/***/ 13404:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/buscar-maletin-dialog/buscar-maletin-dialog.component.scss?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-input {\n  text-transform: uppercase;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJ1c2Nhci1tYWxldGluLWRpYWxvZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0YiLCJmaWxlIjoiYnVzY2FyLW1hbGV0aW4tZGlhbG9nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWlucHV0IHtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbn1cbiJdfQ== */";

/***/ }),

/***/ 13767:
/*!***********************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/caja.component.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYWphLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 34815:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/adicionar-conteo-dialog/adicionar-conteo-dialog.component.scss?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-input {\n  text-align: center;\n}\n\nion-label {\n  text-align: center;\n}\n\n.totales {\n  font-size: 1.3em;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkaWNpb25hci1jb250ZW8tZGlhbG9nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0FBQ0YiLCJmaWxlIjoiYWRpY2lvbmFyLWNvbnRlby1kaWFsb2cuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW5wdXQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbmlvbi1sYWJlbCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnRvdGFsZXMge1xuICBmb250LXNpemU6IDEuM2VtO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 29792:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/operaciones/list-operaciones/list-operaciones.component.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsaXN0LW9wZXJhY2lvbmVzLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 29122:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja-info/caja-info.component.html?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\">Detalles de Caja</ion-col>\n  </ion-row>\n  <ion-card *ngIf=\"selectedCaja !== null\" style=\"margin-top: 10px\">\n    <ion-grid>\n      <ion-row *ngIf=\"selectedCaja?.id !== null\">\n        <ion-col size=\"4\"> Id: {{ selectedCaja?.id }} </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\">\n          Sucursal: {{ selectedCaja?.sucursal?.nombre | titlecase }}\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\">\n          Responsable: {{ selectedUsuario?.persona?.nombre | titlecase }}\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\">\n          Estado:\n          {{\n            selectedCaja?.activo === true\n              ? 'ABIERTO'\n              : selectedCaja?.activo === false\n              ? 'CERRADA'\n              : ('NUEVA CAJA' | titlecase)\n          }}\n        </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"selectedCaja?.fechaApertura !== null\">\n        <ion-col size=\"12\">\n          Fecha apertura: {{ selectedCaja?.fechaApertura | date: 'short' }}\n        </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"selectedCaja?.fechaCierre !== null\">\n        <ion-col size=\"12\">\n          Fecha apertura: {{ selectedCaja?.fechaCierre | date: 'short' }}\n        </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"selectedMaletin!==null\">\n        <ion-col size=\"12\">\n          Maletin: {{ selectedMaletin?.descripcion }}\n        </ion-col>\n      </ion-row>\n      <!-- <ion-row>\n        <ion-col size=\"12\">\n          <ion-item>\n            <ion-label position=\"floating\">Código del maletín</ion-label>\n            <ion-input\n              #buscarInput\n              [formControl]=\"descripcionMaletinControl\"\n              autocapitalize=\"on\"\n              (keyup.enter)=\"onBuscarClick()\"\n            ></ion-input>\n            <ion-icon\n              style=\"font-size: 2em; padding-top: 5px\"\n              name=\"camera-outline\"\n              slot=\"end\"\n              (click)=\"onCameraClick()\"\n            ></ion-icon>\n          </ion-item>\n        </ion-col>\n      </ion-row> -->\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-button\n            class=\"btn-success\"\n            (click)=\"verificarMaletin()\"\n            expand=\"block\"\n            [disabled]=\"\n              selectedCaja?.maletin?.id !== undefined\n            \"\n            *ngIf=\"selectedCaja?.maletin===null && selectedCaja?.sucursal !== null\"\n          >\n            Seleccionar Maletín\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-button\n            class=\"btn-success\"\n            (click)=\"adicionarConteoApertura()\"\n            expand=\"block\"\n            [disabled]=\"\n              selectedCaja?.id === undefined ||\n              selectedCaja?.maletin?.id === undefined ||\n              selectedCaja?.conteoApertura !== undefined\n            \"\n            *ngIf=\"selectedCaja?.conteoApertura === null && selectedCaja?.sucursal !== null\"\n          >\n            Abrir Caja\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-button\n            class=\"btn-success\"\n            (click)=\"adicionarConteoCierre()\"\n            expand=\"block\"\n            *ngIf=\"selectedCaja?.conteoApertura !== null && selectedCaja?.conteoCierre === null\"\n          >\n            Cerrar Caja\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-button\n            class=\"btn-success\"\n            (click)=\"imprimirBalance()\"\n            expand=\"block\"\n            *ngIf=\"selectedCaja?.conteoApertura !== null && selectedCaja?.conteoCierre !== null\"\n          >\n            Imprimir Balance\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n  <ion-card *ngIf=\"selectedCaja?.balance !== null\">\n    <ion-row>\n      <ion-col size=\"12\">Diferencia en G$: {{selectedCaja?.balance?.diferenciaGs | number: '1.0-0'}}</ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\">Diferencia en R$: {{selectedCaja?.balance?.diferenciaRs | number: '1.0-2'}}</ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\">Diferencia en D$: {{selectedCaja?.balance?.diferenciaDs | number: '1.0-2'}}</ion-col>\n    </ion-row>\n  </ion-card>\n</ion-content>\n";

/***/ }),

/***/ 76491:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/buscar-maletin-dialog/buscar-maletin-dialog.component.html?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <br />\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Código del maletín</ion-label>\n        <ion-input\n          #buscarInput\n          [formControl]=\"codigoControl\"\n          (keyup.enter)=\"onBuscarClick()\"\n          autofocus\n        ></ion-input>\n        <ion-icon\n          style=\"font-size: 2em; padding-top: 5px\"\n          name=\"camera-outline\"\n          slot=\"end\"\n          (click)=\"onCameraClick()\"\n        ></ion-icon>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\" class=\"ion-align-items-center\">\n      <ion-button class=\"btn-success\" (click)=\"onBuscarClick()\" expand=\"block\">\n        Aceptar\n      </ion-button>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\" class=\"ion-align-items-center\">\n      <ion-button class=\"btn-danger\" (click)=\"onCancel()\" expand=\"block\">\n        Cancelar\n      </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 75949:
/*!***********************************************************************!*\
  !*** ./src/app/pages/operaciones/caja/caja.component.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-content style=\"top: 40%; bottom: 60%;\">\n  <ion-button expand=\"block\">Scanear QR</ion-button>\n  <ion-button expand=\"block\">Scanear QR</ion-button>\n  <ion-button expand=\"block\">Scanear QR</ion-button>\n</ion-content> -->\n<ion-content>\n  <ion-card class=\"card\" (click)=\"abrirCaja()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Abrir Caja</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Abrir caja de una sucursal. Es necesario estar en la sucursal en donde será abierta la caja.\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"buscarCaja()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Buscar caja abierta</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Buscar cajas abiertas en todas las sucursales\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"buscarHistoricoDeCajas()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Historial de cajas</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Lista de cajas en la cual fuiste responsable\n    </ion-card-content>\n  </ion-card>\n\n</ion-content>\n";

/***/ }),

/***/ 82752:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/operaciones/conteo/adicionar-conteo-dialog/adicionar-conteo-dialog.component.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col *ngIf=\"isApertura===true\" size=\"8\" style=\"text-align: center\">Conteo apertura</ion-col>\n    <ion-col *ngIf=\"isApertura!==true\" size=\"8\" style=\"text-align: center\">Conteo cierre</ion-col>\n  </ion-row>\n  <ion-content>\n    <ion-row>\n      <ion-col size=\"4\">\n        <div class=\"ion-text-center\">\n          <ion-button (click)=\"tabClick('gs')\" expand=\"block\" [fill]=\"moneda === 'gs' ? 'outline' : 'clear'\">\n            Guaraní\n          </ion-button>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-button (click)=\"tabClick('rs')\" expand=\"block\" [fill]=\"moneda === 'rs' ? 'outline' : 'clear'\">\n          Real\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-button (click)=\"tabClick('ds')\" expand=\"block\" [fill]=\"moneda === 'ds' ? 'outline' : 'clear'\">\n          Dolar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n    <ion-grid style=\"height: 60%; overflow-y: auto\">\n      <ion-row>\n        <ion-col size=\"12\" [formGroup]=\"gsFormGroup\" *ngIf=\"moneda === 'gs'\">\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>500:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"500\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>1.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"1000\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>2.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"2000\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>5.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"5000\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>10.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"10000\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>20.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"20000\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>50.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"50000\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>100.000:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"100000\"\n                (keyup.enter)=\"tabClick('rs')\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n        </ion-col>\n        <ion-col size=\"12\" [formGroup]=\"rsFormGroup\" *ngIf=\"moneda === 'rs'\">\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>0.05:</ion-label>\n              <ion-input\n                #rs\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"0.05\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>0.10:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"0.1\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>0.25:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"0.25\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>0.50:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"0.5\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>1:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"1\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>2:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"2\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>5:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"5\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>10:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"10\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>20:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"20\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>50:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"50\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>100:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"100\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>200:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"200\"\n                (keyup.enter)=\"tabClick('ds')\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n        </ion-col>\n        <ion-col size=\"12\" [formGroup]=\"dsFormGroup\" *ngIf=\"moneda === 'ds'\">\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>1:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"1\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>5:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"5\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>10:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"10\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>20:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"20\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>50:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"50\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n          <ion-row>\n            <ion-item style=\"width: 100%\">\n              <ion-label>100:</ion-label>\n              <ion-input\n                type=\"number\"\n                class=\"ion-text-end\"\n                formControlName=\"100\"\n                (keyup.enter)=\"onGuardar()\"\n              ></ion-input>\n            </ion-item>\n          </ion-row>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-card>\n      <ion-row center>\n        <ion-col size=\"12\" class=\"ion-text-center totales\"\n          >{{ totalGs | number: '1.0-0' }} G$</ion-col\n        >\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center totales\"\n          >{{ totalRs | number: '1.0-2' }} R$</ion-col\n        >\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center totales\"\n          >{{ totalDs | number: '1.0-2' }} D$</ion-col\n        >\n      </ion-row>\n    </ion-card>\n    <ion-row style=\"overflow-y: auto;\">\n      <ion-col size=\"12\" class=\"ion-align-items-center\">\n        <ion-button type=\"button\" class=\"btn-success\" (click)=\"onGuardar()\" expand=\"block\">\n          Guardar\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"12\" class=\"ion-align-items-center\">\n        <ion-button type=\"button\" class=\"btn-danger\" (click)=\"onCancel()\" expand=\"block\">\n          Cancelar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-content>\n</ion-content>\n";

/***/ }),

/***/ 98010:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/operaciones/list-operaciones/list-operaciones.component.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "<p>\n  list-operaciones works!\n</p>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_operaciones_operaciones_module_ts.js.map