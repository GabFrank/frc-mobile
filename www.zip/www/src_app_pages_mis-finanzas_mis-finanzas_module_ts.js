"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mis-finanzas_mis-finanzas_module_ts"],{

/***/ 32832:
/*!**************************************************************!*\
  !*** ./src/app/domains/venta-credito/venta-credito.model.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EstadoVentaCredito": () => (/* binding */ EstadoVentaCredito),
/* harmony export */   "TipoConfirmacion": () => (/* binding */ TipoConfirmacion),
/* harmony export */   "VentaCredito": () => (/* binding */ VentaCredito)
/* harmony export */ });
class VentaCredito {
}
var TipoConfirmacion;
(function (TipoConfirmacion) {
    TipoConfirmacion["CONTRASENA"] = "CONTRASENA";
    TipoConfirmacion["PASSWORD"] = "PASSWORD";
    TipoConfirmacion["QR"] = "QR";
    TipoConfirmacion["LECTOR_HUELLAS"] = "LECTOR_HUELLAS";
    TipoConfirmacion["FIRMA"] = "FIRMA";
    TipoConfirmacion["APP"] = "APP";
})(TipoConfirmacion || (TipoConfirmacion = {}));
var EstadoVentaCredito;
(function (EstadoVentaCredito) {
    EstadoVentaCredito["ABIERTO"] = "ABIERTO";
    EstadoVentaCredito["FINALIZADO"] = "FINALIZADO";
    EstadoVentaCredito["EN_MORA"] = "EN_MORA";
    EstadoVentaCredito["INCOBRABLE"] = "INCOBRABLE";
})(EstadoVentaCredito || (EstadoVentaCredito = {}));


/***/ }),

/***/ 63907:
/*!******************************************************************************!*\
  !*** ./src/app/graphql/financiero/venta-credito/count-by-cliente-id copy.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CountVentaCreditoByClienteAndEstadoGQL": () => (/* binding */ CountVentaCreditoByClienteAndEstadoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 38962);




let CountVentaCreditoByClienteAndEstadoGQL = class CountVentaCreditoByClienteAndEstadoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.countByClienteAndEstado;
    }
};
CountVentaCreditoByClienteAndEstadoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CountVentaCreditoByClienteAndEstadoGQL);



/***/ }),

/***/ 38962:
/*!*******************************************************************!*\
  !*** ./src/app/graphql/financiero/venta-credito/graphql-query.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "countByClienteAndEstado": () => (/* binding */ countByClienteAndEstado),
/* harmony export */   "deleteVentaCreditoQuery": () => (/* binding */ deleteVentaCreditoQuery),
/* harmony export */   "saveVentaCredito": () => (/* binding */ saveVentaCredito),
/* harmony export */   "ventaCreditoPorClienteQuery": () => (/* binding */ ventaCreditoPorClienteQuery),
/* harmony export */   "ventaCreditoQrAuthQuery": () => (/* binding */ ventaCreditoQrAuthQuery),
/* harmony export */   "ventaCreditoQuery": () => (/* binding */ ventaCreditoQuery),
/* harmony export */   "ventaCreditosQuery": () => (/* binding */ ventaCreditosQuery)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const ventaCreditosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `{
    ventaCreditos{
      id
      sucursal {
        id
        nombre
      }
      venta {
        id
      }
      cliente {
        id
      }
      tipoConfirmacion
      cantidadCuotas
      valorTotal
      saldoTotal
      plazoEnDias
      interesPorDia
      interesMoraDia
      estado
      creadoEn
      usuario {
        id
      }
    }
  }`;
const ventaCreditoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
    data: ventaCredito(id: $id){
      id
      sucursal {
        id
        nombre
      }
      venta {
        id
      }
      cliente {
        id
      }
      tipoConfirmacion
      cantidadCuotas
      valorTotal
      saldoTotal
      plazoEnDias
      interesPorDia
      interesMoraDia
      estado
      creadoEn
      usuario {
        id
      }
    }
  }`;
const ventaCreditoQrAuthQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!, $timestamp: String, $sucursalId: Int){
    data: ventaCreditoQrAuth(id: $id, timestamp :$timestamp, sucursalId: $sucursalId)
  }`;
const ventaCreditoPorClienteQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!, $estado: EstadoVentaCredito, $page: Int, $size: Int){
    data: ventaCreditoPorCliente(id: $id, estado: $estado, page: $page, size: $size){
      id
      sucursal {
        id
        nombre
      }
      venta {
        id
        usuario {
          persona {
            nombre
          }
        }
        sucursalId
      }
      cliente {
        id
      }
      tipoConfirmacion
      cantidadCuotas
      valorTotal
      saldoTotal
      plazoEnDias
      interesPorDia
      interesMoraDia
      estado
      creadoEn
      usuario {
        id
      }
    }
  }`;
const saveVentaCredito = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `mutation saveVentaCredito($entity:VentaCreditoInput!, $detalleList:[VentaCreditoCuotaInput]!){
      data: saveVentaCredito(entity:$entity, detalleList:$detalleList){
        id
      }
    }`;
const deleteVentaCreditoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] ` mutation deleteVentaCredito($id: ID!){
    deleteVentaCredito(id: $id)
}`;
const countByClienteAndEstado = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!, $estado: EstadoVentaCredito){
  data: countByClienteIdAndEstado(id: $id, estado: $estado)
}`;


/***/ }),

/***/ 84950:
/*!**********************************************************************************!*\
  !*** ./src/app/graphql/financiero/venta-credito/venta-credito-por-cliente-id.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaCreditoPorClienteGQL": () => (/* binding */ VentaCreditoPorClienteGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 38962);




let VentaCreditoPorClienteGQL = class VentaCreditoPorClienteGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.ventaCreditoPorClienteQuery;
    }
};
VentaCreditoPorClienteGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], VentaCreditoPorClienteGQL);



/***/ }),

/***/ 76135:
/*!***************************************************************************!*\
  !*** ./src/app/graphql/financiero/venta-credito/venta-credito-qr-auth.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaCreditoQrAuthGQL": () => (/* binding */ VentaCreditoQrAuthGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 38962);




let VentaCreditoQrAuthGQL = class VentaCreditoQrAuthGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.ventaCreditoQrAuthQuery;
    }
};
VentaCreditoQrAuthGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], VentaCreditoQrAuthGQL);



/***/ }),

/***/ 30202:
/*!***************************************************************************!*\
  !*** ./src/app/graphql/financiero/venta-credito/venta-credito.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaCreditoService": () => (/* binding */ VentaCreditoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var _count_by_cliente_id_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./count-by-cliente-id copy */ 63907);
/* harmony import */ var _venta_credito_por_cliente_id__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./venta-credito-por-cliente-id */ 84950);
/* harmony import */ var _venta_credito_qr_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./venta-credito-qr-auth */ 76135);






let VentaCreditoService = class VentaCreditoService {
    constructor(genericService, ventaCreditoPorCliente, countByClienteAndEstado, ventaCreditoQrAuth) {
        this.genericService = genericService;
        this.ventaCreditoPorCliente = ventaCreditoPorCliente;
        this.countByClienteAndEstado = countByClienteAndEstado;
        this.ventaCreditoQrAuth = ventaCreditoQrAuth;
    }
    onGetPorClienteId(id, estado, page, size) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericService.onCustomGet(this.ventaCreditoPorCliente, { id, estado, page, size });
        });
    }
    countPorClienteIdAndEstado(id, estado) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericService.onCustomGet(this.countByClienteAndEstado, { id, estado });
        });
    }
    onVentaCreditoQrAuth(id, timestamp, sucursalId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericService.onCustomGet(this.ventaCreditoQrAuth, { id, timestamp, sucursalId });
        });
    }
};
VentaCreditoService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__.GenericCrudService },
    { type: _venta_credito_por_cliente_id__WEBPACK_IMPORTED_MODULE_2__.VentaCreditoPorClienteGQL },
    { type: _count_by_cliente_id_copy__WEBPACK_IMPORTED_MODULE_1__.CountVentaCreditoByClienteAndEstadoGQL },
    { type: _venta_credito_qr_auth__WEBPACK_IMPORTED_MODULE_3__.VentaCreditoQrAuthGQL }
];
VentaCreditoService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], VentaCreditoService);



/***/ }),

/***/ 89874:
/*!********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/cancelarVenta.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CancelarVentaGQL": () => (/* binding */ CancelarVentaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let CancelarVentaGQL = class CancelarVentaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cancelarVentaQuery;
    }
};
CancelarVentaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CancelarVentaGQL);



/***/ }),

/***/ 12526:
/*!******************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/count-venta.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CountVentaGQL": () => (/* binding */ CountVentaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




let CountVentaGQL = class CountVentaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.countVentaQuery;
    }
};
CountVentaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CountVentaGQL);



/***/ }),

/***/ 9329:
/*!******************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/deleteVenta.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteVentaGQL": () => (/* binding */ DeleteVentaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let DeleteVentaGQL = class DeleteVentaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteVentaQuery;
    }
};
DeleteVentaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteVentaGQL);



/***/ }),

/***/ 31891:
/*!********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/graphql-query.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cancelarVentaQuery": () => (/* binding */ cancelarVentaQuery),
/* harmony export */   "countVentaQuery": () => (/* binding */ countVentaQuery),
/* harmony export */   "deleteVentaQuery": () => (/* binding */ deleteVentaQuery),
/* harmony export */   "imprimirPagareQuery": () => (/* binding */ imprimirPagareQuery),
/* harmony export */   "reimprimirVentaQuery": () => (/* binding */ reimprimirVentaQuery),
/* harmony export */   "saveCobroDetalleQuery": () => (/* binding */ saveCobroDetalleQuery),
/* harmony export */   "saveVenta": () => (/* binding */ saveVenta),
/* harmony export */   "saveVentaItemQuery": () => (/* binding */ saveVentaItemQuery),
/* harmony export */   "ventaPorPeriodoQuery": () => (/* binding */ ventaPorPeriodoQuery),
/* harmony export */   "ventaQuery": () => (/* binding */ ventaQuery),
/* harmony export */   "ventasPorCajaIdQuery": () => (/* binding */ ventasPorCajaIdQuery),
/* harmony export */   "ventasQuery": () => (/* binding */ ventasQuery)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const ventasQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
    query ($sucId: ID){
    data: ventas (sucId: $sucId) {
      id
      sucursalId
      cliente {
        id
      }
      formaPago {
        id
        descripcion
      }
      estado
      creadoEn
      usuario {
        id
      }
      ventaItemList {
        id
        producto {
          id
        }
        cantidad
        precioCosto
        precioVenta {
          precio
        }
        precio
        valorDescuento
        unidadMedida
        creadoEn
        usuario {
          id
        }
        valorTotal
      }
      valorDescuento
      valorTotal
      totalGs
      totalRs
      totalDs
    }
  }
`;
const ventaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $sucId: ID) {
    data: venta(id: $id, sucId: $sucId) {
      id
      sucursalId
      cliente {
        id
      }
      formaPago {
        id
        descripcion
      }
      caja {
        id
      }
      estado
      creadoEn
      usuario {
        id
      }
      ventaItemList {
        id
        producto {
          id
          descripcion
          isEnvase
        }
        presentacion {
          cantidad
        }
        cantidad
        precioCosto
        precioVenta {
          precio
          tipoPrecio {
            descripcion
          }
        }
        precio
        valorDescuento
        unidadMedida
        creadoEn
        usuario {
          id
        }
        valorTotal
      }
      valorDescuento
      valorTotal
      totalGs
      totalRs
      totalDs
      cobro {
        id
        cobroDetalleList{
          id
          moneda {
            denominacion
          }
          valor
          cambio
          formaPago {
            descripcion
          }
          descuento
          aumento
          vuelto
          pago
          identificadorTransaccion
        }
      }
    }
  }
`;
const saveVenta = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveVenta(
    $ventaInput: VentaInput!
    $ventaItemList: [VentaItemInput]
    $cobro: CobroInput
    $cobroDetalleList: [CobroDetalleInput]
    $ticket: Boolean
    $printerName: String
    $local: String,
    $pdvId: Int
    $ventaCreditoInput: VentaCreditoInput, 
    $ventaCreditoCuotaInputList: [VentaCreditoCuotaInput]
  ) {
    data: saveVenta(
      ventaInput: $ventaInput
      ventaItemList: $ventaItemList
      cobro: $cobro
      cobroDetalleList: $cobroDetalleList
      ticket: $ticket,
      printerName: $printerName,
      local: $local,
      pdvId: $pdvId,
      ventaCreditoInput: $ventaCreditoInput
      ventaCreditoCuotaInputList: $ventaCreditoCuotaInputList
    ){
      id
    }
  }
`;
const deleteVentaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteVenta($id: ID!, $sucId: ID) {
    deleteVenta(id: $id, sucId: $sucId)
  }
`;
const cancelarVentaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation cancelarVenta($id: ID!, $sucId: ID) {
    data: cancelarVenta(id: $id, sucId: $sucId)
  }
`;
const imprimirPagareQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation imprimirPagare(
    $id: ID!,
    $itens: [VentaCreditoCuotaInput]!,
    $printerName: String,
    $local: String,
    $sucId: ID
    ) {
    data: imprimirPagare(
      id: $id
      itens: $itens
      printerName: $printerName,
      local: $local,
      sucId: $sucId
      )
  }
`;
const reimprimirVentaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation reimprimirVenta(
    $id: ID!
    $printerName: String,
    $local: String,
    $sucId: ID
    ) {
    data: reimprimirVenta(
      id: $id
      printerName: $printerName,
      local: $local,
      sucId: $sucId
      )
  }
`;
//ventasPorCajaId
const ventasPorCajaIdQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $page: Int, $size: Int, $asc: Boolean, $sucId: ID, $formaPago: ID, $estado: VentaEstado) {
    data: ventasPorCajaId(id: $id, page: $page,size: $size,asc: $asc, sucId: $sucId, formaPago: $formaPago, estado: $estado) {
      id
      sucursalId
      cliente {
        id
        persona {
          nombre
        }
      }
      formaPago {
        id
        descripcion
      }
      estado
      creadoEn
      usuario {
        id
      }
      valorDescuento
      valorTotal
      totalGs
      totalRs
      totalDs
    }
  }
`;
const ventaPorPeriodoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($inicio: String, $fin: String, $sucId: ID) {
    data: ventaPorPeriodo(inicio: $inicio, fin: $fin, sucId: $sucId) {
      valorGs
      valorRs
      valorDs
      valorTotalGs
      creadoEn
    }
  }
`;
const countVentaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {data: countVenta}
`;
const saveVentaItemQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveVentaItem(
    $entity: VentaItemInput!
  ) {
    data: saveVentaItem(
      entity: $entity
    ){
      id
    }
  }
`;
const saveCobroDetalleQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveCobroDetalle(
    $entity: CobroDetalleInput!
  ) {
    data: saveCobroDetalle(
      entity: $entity
    ){
      id
    }
  }
`;


/***/ }),

/***/ 16217:
/*!*********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/imprimirPagare.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImprimirPagareGQL": () => (/* binding */ ImprimirPagareGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let ImprimirPagareGQL = class ImprimirPagareGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.imprimirPagareQuery;
    }
};
ImprimirPagareGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ImprimirPagareGQL);



/***/ }),

/***/ 75126:
/*!**********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/reimprimirVenta.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReimprimirVentaGQL": () => (/* binding */ ReimprimirVentaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let ReimprimirVentaGQL = class ReimprimirVentaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.reimprimirVentaQuery;
    }
};
ReimprimirVentaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ReimprimirVentaGQL);



/***/ }),

/***/ 65918:
/*!***********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/saveCobroDetalle.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveCobroDetalleGQL": () => (/* binding */ SaveCobroDetalleGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let SaveCobroDetalleGQL = class SaveCobroDetalleGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveCobroDetalleQuery;
    }
};
SaveCobroDetalleGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveCobroDetalleGQL);



/***/ }),

/***/ 30113:
/*!****************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/saveVenta.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveVentaGQL": () => (/* binding */ SaveVentaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let SaveVentaGQL = class SaveVentaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveVenta;
    }
};
SaveVentaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveVentaGQL);



/***/ }),

/***/ 25175:
/*!********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/saveVentaItem.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveVentaItemGQL": () => (/* binding */ SaveVentaItemGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let SaveVentaItemGQL = class SaveVentaItemGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveVentaItemQuery;
    }
};
SaveVentaItemGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveVentaItemGQL);



/***/ }),

/***/ 26656:
/*!*****************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/ventaPorId.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaPorIdGQL": () => (/* binding */ VentaPorIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let VentaPorIdGQL = class VentaPorIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.ventaQuery;
    }
};
VentaPorIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], VentaPorIdGQL);



/***/ }),

/***/ 30489:
/*!**********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/ventaPorPeriodo.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaPorPeriodoGQL": () => (/* binding */ VentaPorPeriodoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let VentaPorPeriodoGQL = class VentaPorPeriodoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.ventaPorPeriodoQuery;
    }
};
VentaPorPeriodoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], VentaPorPeriodoGQL);



/***/ }),

/***/ 43421:
/*!**********************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/graphql/ventasPorCajaId.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaPorCajaIdGQL": () => (/* binding */ VentaPorCajaIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 31891);




class Response {
}
let VentaPorCajaIdGQL = class VentaPorCajaIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.ventasPorCajaIdQuery;
    }
};
VentaPorCajaIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], VentaPorCajaIdGQL);



/***/ }),

/***/ 6356:
/*!************************************************************!*\
  !*** ./src/app/graphql/operaciones/venta/venta.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VentaService": () => (/* binding */ VentaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _graphql_cancelarVenta__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/cancelarVenta */ 89874);
/* harmony import */ var _graphql_reimprimirVenta__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./graphql/reimprimirVenta */ 75126);
/* harmony import */ var _graphql_saveVenta__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./graphql/saveVenta */ 30113);
/* harmony import */ var _graphql_ventaPorId__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./graphql/ventaPorId */ 26656);
/* harmony import */ var _graphql_ventasPorCajaId__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./graphql/ventasPorCajaId */ 43421);
/* harmony import */ var _graphql_ventaPorPeriodo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/ventaPorPeriodo */ 30489);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _graphql_deleteVenta__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql/deleteVenta */ 9329);
/* harmony import */ var _graphql_imprimirPagare__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./graphql/imprimirPagare */ 16217);
/* harmony import */ var _graphql_count_venta__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./graphql/count-venta */ 12526);
/* harmony import */ var _graphql_saveVentaItem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./graphql/saveVentaItem */ 25175);
/* harmony import */ var _graphql_saveCobroDetalle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./graphql/saveCobroDetalle */ 65918);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);

















let VentaService = class VentaService {
    constructor(genericService, saveVenta, mainService, cancelarVenta, reimprimirVenta, ventasPorCajaId, ventaPorId, ventaPorPeriodo, notificacionBar, deleteVenta, imprimirPagare, countVenta, saveVentaItemQuery, saveCobroDetalleQuery) {
        this.genericService = genericService;
        this.saveVenta = saveVenta;
        this.mainService = mainService;
        this.cancelarVenta = cancelarVenta;
        this.reimprimirVenta = reimprimirVenta;
        this.ventasPorCajaId = ventasPorCajaId;
        this.ventaPorId = ventaPorId;
        this.ventaPorPeriodo = ventaPorPeriodo;
        this.notificacionBar = notificacionBar;
        this.deleteVenta = deleteVenta;
        this.imprimirPagare = imprimirPagare;
        this.countVenta = countVenta;
        this.saveVentaItemQuery = saveVentaItemQuery;
        this.saveCobroDetalleQuery = saveCobroDetalleQuery;
    }
    // $venta:VentaInput!, $venteItemList: [VentaItemInput], $cobro: CobroInput, $cobroDetalleList: [CobroDetalleInput]
    // onSaveVenta(venta: Venta, cobro: Cobro, ticket, ventaCreditoInput?, ventaCreditoCuotaInputList?): Observable<any> {
    //   let ventaItemInputList: VentaItemInput[] = [];
    //   let cobroDetalleInputList: CobroDetalleInput[] = [];
    //   let ventaInput: VentaInput = venta.toInput();
    //   let cobroInput: CobroInput = cobro.toInput();
    //   ventaInput.estado = VentaEstado.CONCLUIDA;
    //   ventaInput.usuarioId = this.mainService?.usuarioActual?.id;
    //   cobroInput.usuarioId = this.mainService?.usuarioActual?.id;
    //   venta.ventaItemList.forEach((e) => {
    //     ventaItemInputList.push(e.toInput());
    //   });
    //   cobro.cobroDetalleList.forEach((e) => {
    //     cobroDetalleInputList.push(e.toInput());
    //   });
    //   return new Observable((obs) => {
    //     this.saveVenta
    //       .mutate(
    //         {
    //           ventaInput: ventaInput,
    //           ventaItemList: ventaItemInputList,
    //           cobro: cobroInput,
    //           cobroDetalleList: cobroDetalleInputList,
    //           ticket,
    //           printerName: environment['printers']['ticket'],
    //           local: environment['local'],
    //           pdvId: environment['pdvId'],
    //           ventaCreditoInput,
    //           ventaCreditoCuotaInputList
    //         },
    //         {
    //           errorPolicy: "all",
    //           fetchPolicy: "no-cache",
    //         }
    //       ).pipe(untilDestroyed(this))
    //       .subscribe((res) => {
    //         obs.next(res.data["data"]);
    //       });
    //   });
    // }
    // onDeleteVenta(id): Observable<boolean> {
    //   return this.genericService.onDelete(this.deleteVenta, id, null, null, false, false);
    // }
    // onReimprimirVenta(id): Observable<boolean> {
    //   return new Observable((obs) => {
    //     this.reimprimirVenta
    //       .mutate(
    //         {
    //           id,
    //           printerName: environment['printers']['ticket'],
    //           local: environment['local']
    //         },
    //         {
    //           fetchPolicy: "no-cache",
    //           errorPolicy: "all",
    //         }
    //       ).pipe(untilDestroyed(this))
    //       .subscribe((res) => {
    //         if (res.errors == null) {
    //           obs.next(res.data.data);
    //         } else {
    //           obs.next(null);
    //         }
    //       });
    //   });
    // }
    // onImprimirPagare(id, itens): Observable<boolean> {
    //   return new Observable((obs) => {
    //     this.imprimirPagare
    //       .mutate(
    //         {
    //           id,
    //           itens,
    //           printerName: environment['printers']['ticket'],
    //           local: environment['local']
    //         },
    //         {
    //           fetchPolicy: "no-cache",
    //           errorPolicy: "all",
    //         }
    //       ).pipe(untilDestroyed(this))
    //       .subscribe((res) => {
    //         if (res.errors == null) {
    //           obs.next(res.data.data);
    //         } else {
    //           obs.next(null);
    //         }
    //       });
    //   });
    // }
    // onCancelarVenta(id, sucId): Observable<boolean> {
    //   return new Observable((obs) => {
    //     this.cancelarVenta
    //       .mutate(
    //         {
    //           id,
    //           sucId
    //         },
    //         {
    //           fetchPolicy: "no-cache",
    //           errorPolicy: "all",
    //         }
    //       ).pipe(untilDestroyed(this))
    //       .subscribe((res) => {
    //         if (res.errors == null) {
    //           obs.next(res.data.data);
    //         } else {
    //           obs.next(null);
    //         }
    //       });
    //   });
    // }
    // onSearch(id, page?, size?, asc?, sucId?, formaPago?, estado?): Observable<Venta[]> {
    //   this.genericService.isLoading = true;
    //   if (page == null) page = 0;
    //   if (size == null) size = 20;
    //   if (asc == null) asc = true;
    //   console.log(id, page, size, asc, sucId, formaPago, estado);
    //   return new Observable((obs) => {
    //     this.ventasPorCajaId
    //       .fetch(
    //         {
    //           id,
    //           page,
    //           size,
    //           asc,
    //           sucId,
    //           formaPago,
    //           estado
    //         },
    //         {
    //           fetchPolicy: "no-cache",
    //           errorPolicy: "all",
    //         }
    //       ).pipe(untilDestroyed(this))
    //       .subscribe((res) => {
    //         this.genericService.isLoading = false;
    //         if (res.errors == null) {
    //           obs.next(res.data.data);
    //         } else {
    //           obs.next(null);
    //         }
    //       });
    //   });
    // }
    onGetPorId(id, sucId) {
        return this.genericService.onGetById(this.ventaPorId, id, null, null, sucId);
    }
};
VentaService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_11__.GenericCrudService },
    { type: _graphql_saveVenta__WEBPACK_IMPORTED_MODULE_2__.SaveVentaGQL },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_12__.MainService },
    { type: _graphql_cancelarVenta__WEBPACK_IMPORTED_MODULE_0__.CancelarVentaGQL },
    { type: _graphql_reimprimirVenta__WEBPACK_IMPORTED_MODULE_1__.ReimprimirVentaGQL },
    { type: _graphql_ventasPorCajaId__WEBPACK_IMPORTED_MODULE_4__.VentaPorCajaIdGQL },
    { type: _graphql_ventaPorId__WEBPACK_IMPORTED_MODULE_3__.VentaPorIdGQL },
    { type: _graphql_ventaPorPeriodo__WEBPACK_IMPORTED_MODULE_5__.VentaPorPeriodoGQL },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_13__.NotificacionService },
    { type: _graphql_deleteVenta__WEBPACK_IMPORTED_MODULE_6__.DeleteVentaGQL },
    { type: _graphql_imprimirPagare__WEBPACK_IMPORTED_MODULE_7__.ImprimirPagareGQL },
    { type: _graphql_count_venta__WEBPACK_IMPORTED_MODULE_8__.CountVentaGQL },
    { type: _graphql_saveVentaItem__WEBPACK_IMPORTED_MODULE_9__.SaveVentaItemGQL },
    { type: _graphql_saveCobroDetalle__WEBPACK_IMPORTED_MODULE_10__.SaveCobroDetalleGQL }
];
VentaService = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_15__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Injectable)({
        providedIn: "root",
    })
], VentaService);



/***/ }),

/***/ 88460:
/*!*********************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/cliente.service.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClienteService": () => (/* binding */ ClienteService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var _clienteById__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./clienteById */ 34342);
/* harmony import */ var _clientePorPersonaDocumento__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./clientePorPersonaDocumento */ 60163);
/* harmony import */ var _clientePorPersonaIdFromServer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./clientePorPersonaIdFromServer */ 3214);
/* harmony import */ var _clienteSearchByPersona__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./clienteSearchByPersona */ 96106);
/* harmony import */ var _clienteSearchByPersonaId__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./clienteSearchByPersonaId */ 48529);








let ClienteService = class ClienteService {
    constructor(genericService, getClienteById, searchByPersonaNombre, getClientePorPersonaDocumento, getClientePorPersonaId, getClientePorPersonaIdFromServer) {
        this.genericService = genericService;
        this.getClienteById = getClienteById;
        this.searchByPersonaNombre = searchByPersonaNombre;
        this.getClientePorPersonaDocumento = getClientePorPersonaDocumento;
        this.getClientePorPersonaId = getClientePorPersonaId;
        this.getClientePorPersonaIdFromServer = getClientePorPersonaIdFromServer;
    }
    onGetClientePorPersonaDocumento(texto) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetByTexto(this.getClientePorPersonaDocumento, texto);
        });
    }
    onGetById(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.getClienteById, id);
        });
    }
    onGetByIdFromServer(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.getClientePorPersonaIdFromServer, id);
        });
    }
    onGetByPersonaId(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.getClientePorPersonaId, id);
        });
    }
    onSearch(texto) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetByTexto(this.searchByPersonaNombre, texto);
        });
    }
    onGetByPersonaIdFromServer(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.getClientePorPersonaId, id, null, null, true);
        });
    }
};
ClienteService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_0__.GenericCrudService },
    { type: _clienteById__WEBPACK_IMPORTED_MODULE_1__.ClienteByIdGQL },
    { type: _clienteSearchByPersona__WEBPACK_IMPORTED_MODULE_4__.ClientesSearchByPersonaGQL },
    { type: _clientePorPersonaDocumento__WEBPACK_IMPORTED_MODULE_2__.ClientePersonaDocumentoGQL },
    { type: _clienteSearchByPersonaId__WEBPACK_IMPORTED_MODULE_5__.ClientesSearchByPersonaIdGQL },
    { type: _clientePorPersonaIdFromServer__WEBPACK_IMPORTED_MODULE_3__.ClientePersonaIdFromServerGQL }
];
ClienteService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
        providedIn: 'root'
    })
], ClienteService);



/***/ }),

/***/ 34342:
/*!*****************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/clienteById.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClienteByIdGQL": () => (/* binding */ ClienteByIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 18957);




let ClienteByIdGQL = class ClienteByIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.clienteQuery;
    }
};
ClienteByIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ClienteByIdGQL);



/***/ }),

/***/ 60163:
/*!********************************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/clientePorPersonaDocumento.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientePersonaDocumentoGQL": () => (/* binding */ ClientePersonaDocumentoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 18957);




let ClientePersonaDocumentoGQL = class ClientePersonaDocumentoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.clientePorPersonaDocumento;
    }
};
ClientePersonaDocumentoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ClientePersonaDocumentoGQL);



/***/ }),

/***/ 3214:
/*!***********************************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/clientePorPersonaIdFromServer.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientePersonaIdFromServerGQL": () => (/* binding */ ClientePersonaIdFromServerGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 18957);




let ClientePersonaIdFromServerGQL = class ClientePersonaIdFromServerGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.clientePorPersonaIdFromServer;
    }
};
ClientePersonaIdFromServerGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ClientePersonaIdFromServerGQL);



/***/ }),

/***/ 96106:
/*!****************************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/clienteSearchByPersona.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientesSearchByPersonaGQL": () => (/* binding */ ClientesSearchByPersonaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 18957);




let ClientesSearchByPersonaGQL = class ClientesSearchByPersonaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.clientesSearchByPersona;
    }
};
ClientesSearchByPersonaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ClientesSearchByPersonaGQL);



/***/ }),

/***/ 48529:
/*!******************************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/clienteSearchByPersonaId.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientesSearchByPersonaIdGQL": () => (/* binding */ ClientesSearchByPersonaIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 18957);




let ClientesSearchByPersonaIdGQL = class ClientesSearchByPersonaIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.clienteSearchByPersonaId;
    }
};
ClientesSearchByPersonaIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ClientesSearchByPersonaIdGQL);



/***/ }),

/***/ 18957:
/*!*******************************************************************!*\
  !*** ./src/app/graphql/personas/cliente/graphql/graphql-query.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "clientePorPersonaDocumento": () => (/* binding */ clientePorPersonaDocumento),
/* harmony export */   "clientePorPersonaIdFromServer": () => (/* binding */ clientePorPersonaIdFromServer),
/* harmony export */   "clienteQuery": () => (/* binding */ clienteQuery),
/* harmony export */   "clienteSearchByPersonaId": () => (/* binding */ clienteSearchByPersonaId),
/* harmony export */   "clientesQuery": () => (/* binding */ clientesQuery),
/* harmony export */   "clientesSearchByPersona": () => (/* binding */ clientesSearchByPersona),
/* harmony export */   "clientesSearchByTelefono": () => (/* binding */ clientesSearchByTelefono),
/* harmony export */   "deleteClienteQuery": () => (/* binding */ deleteClienteQuery),
/* harmony export */   "saveCliente": () => (/* binding */ saveCliente)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const clientesQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `{
    clientes{
      id
      persona{
        id
        nombre
      }
      nombre
      credito
      contactos{
        id
        telefono
      }
    }
  }`;
const clientesSearchByPersona = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($texto: String){
    data : clientePorPersona(texto: $texto){
      id
      persona{
        id
        nombre
        direccion
      }
      nombre
      documento
      credito
      contactos{
        id
        telefono
      }
    }
  }`;
const clientePorPersonaDocumento = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($texto: String){
    data : clientePorPersonaDocumento(texto: $texto){
        id
        persona{
          id
          nombre
          direccion
        }
        nombre
        credito
        contactos{
          id
          telefono
        }
    }
  }`;
const clienteSearchByPersonaId = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID){
  data : clientePorPersonaId(id: $id){
      id
      persona{
        id
        nombre
      }
      nombre
      credito
      contactos{
        id
        telefono
      }
      saldo
      tipo
      codigo
  }
}`;
const clientePorPersonaIdFromServer = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID){
  data : clientePorPersonaIdFromServer(id: $id){
      id
      persona{
        id
        nombre
      }
      nombre
      credito
      contactos{
        id
        telefono
      }
      saldo
      tipo
      codigo
  }
}`;
const clientesSearchByTelefono = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($texto: String){
    data : clientePorTelefono(texto: $texto){
      id
      persona{
        id
        nombre
      }
      nombre
      credito
      contactos{
        id
        telefono
      }
    }
  }`;
const clienteQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
    data: cliente(id: $id){
      id
      persona{
        id
        nombre
      }
      nombre
      credito
      contactos{
        id
        telefono
      }
    }
  }`;
const saveCliente = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `mutation saveCliente($entity:ClienteInput!){
      data: saveCliente(cliente:$entity){
        id
      }
    }`;
const deleteClienteQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] ` mutation deleteCliente($id: ID!){
    deleteCliente(id: $id)
}`;


/***/ }),

/***/ 4395:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/convenio/list-convenio/list-convenio.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListConvenioComponent": () => (/* binding */ ListConvenioComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _list_convenio_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-convenio.component.html?ngResource */ 92228);
/* harmony import */ var _list_convenio_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-convenio.component.scss?ngResource */ 63378);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_components_generic_list_dialog_generic_list_dialog_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/generic-list-dialog/generic-list-dialog.component */ 99529);
/* harmony import */ var src_app_domains_venta_credito_venta_credito_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/domains/venta-credito/venta-credito.model */ 32832);
/* harmony import */ var src_app_graphql_financiero_venta_credito_venta_credito_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/graphql/financiero/venta-credito/venta-credito.service */ 30202);
/* harmony import */ var src_app_graphql_operaciones_venta_venta_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/graphql/operaciones/venta/venta.service */ 6356);
/* harmony import */ var src_app_graphql_personas_cliente_graphql_cliente_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/graphql/personas/cliente/graphql/cliente.service */ 88460);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/menu-action.service */ 47257);
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/modal.service */ 71609);













let ListConvenioComponent = class ListConvenioComponent {
    constructor(ventaCreditoService, mainService, clienteService, _location, menuActionService, ventaService, modalService) {
        this.ventaCreditoService = ventaCreditoService;
        this.mainService = mainService;
        this.clienteService = clienteService;
        this._location = _location;
        this.menuActionService = menuActionService;
        this.ventaService = ventaService;
        this.modalService = modalService;
        this.ventaCreditoList = [];
        this.totalVentaCredito = 0;
        this.totalAbiertos = 0;
        this.selectedEstado = src_app_domains_venta_credito_venta_credito_model__WEBPACK_IMPORTED_MODULE_3__.EstadoVentaCredito.ABIERTO;
    }
    ngOnInit() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.clienteService.onGetByPersonaId((_a = this.mainService.usuarioActual) === null || _a === void 0 ? void 0 : _a.persona.id)).subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                this.selectedCliente = res;
                console.log(res);
                if (res != null) {
                    (yield this.ventaCreditoService.onGetPorClienteId(res.id, this.selectedEstado, 0, this.totalVentaCredito)).subscribe(res3 => {
                        this.ventaCreditoList = res3;
                        this.totalVentaCredito = this.ventaCreditoList.length;
                        this.calcularTotal();
                    });
                }
            }));
        });
    }
    calcularTotal() {
        this.ventaCreditoList.forEach(vc => {
            this.totalAbiertos += vc.valorTotal;
        });
    }
    onItemClick(ventaCredito) {
    }
    onBack() {
        this._location.back();
    }
    openFilterMenu() {
    }
    openVentaDetalle(venta) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.ventaService.onGetPorId(venta.id, venta.sucursalId)).subscribe((res) => {
                if (res != null) {
                    let tableData = [
                        {
                            id: 'producto',
                            nombre: 'Producto',
                            width: 100,
                            nested: true,
                            nestedId: 'descripcion'
                        },
                        {
                            id: 'presentacion',
                            nombre: 'Presentación',
                            width: 100,
                            nested: true,
                            nestedId: 'cantidad'
                        },
                        {
                            id: 'cantidad',
                            nombre: 'cantidad',
                            width: 100
                        },
                        {
                            id: 'valorTotal',
                            nombre: 'Total',
                            width: 100
                        }
                    ];
                    let data = {
                        tableData: tableData,
                        titulo: 'Detalle de venta',
                        search: false,
                        inicialData: res.ventaItemList
                    };
                    this.modalService.openModal(src_app_components_generic_list_dialog_generic_list_dialog_component__WEBPACK_IMPORTED_MODULE_2__.GenericListDialogComponent, data);
                }
            });
        });
    }
};
ListConvenioComponent.ctorParameters = () => [
    { type: src_app_graphql_financiero_venta_credito_venta_credito_service__WEBPACK_IMPORTED_MODULE_4__.VentaCreditoService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_7__.MainService },
    { type: src_app_graphql_personas_cliente_graphql_cliente_service__WEBPACK_IMPORTED_MODULE_6__.ClienteService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_11__.Location },
    { type: src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_8__.MenuActionService },
    { type: src_app_graphql_operaciones_venta_venta_service__WEBPACK_IMPORTED_MODULE_5__.VentaService },
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_9__.ModalService }
];
ListConvenioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-list-convenio',
        template: _list_convenio_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_list_convenio_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListConvenioComponent);



/***/ }),

/***/ 82998:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/mis-finanzas-dashboard/mis-finanzas-dashboard.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MisFinanzasDashboardComponent": () => (/* binding */ MisFinanzasDashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mis_finanzas_dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mis-finanzas-dashboard.component.html?ngResource */ 34362);
/* harmony import */ var _mis_finanzas_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mis-finanzas-dashboard.component.scss?ngResource */ 15787);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_generic_utils_numbersUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/generic/utils/numbersUtils */ 37867);
/* harmony import */ var src_app_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/generic/utils/qrUtils */ 83503);
/* harmony import */ var src_app_graphql_financiero_venta_credito_venta_credito_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/graphql/financiero/venta-credito/venta-credito.service */ 30202);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/main.service */ 91557);










let MisFinanzasDashboardComponent = class MisFinanzasDashboardComponent {
    constructor(barcodeScanner, plt, ventaCreditoService, mainService) {
        this.barcodeScanner = barcodeScanner;
        this.plt = plt;
        this.ventaCreditoService = ventaCreditoService;
        this.mainService = mainService;
    }
    ngOnInit() { }
    onQrConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (this.plt.is("mobileweb")) {
            }
            else if (this.plt.is("android") || this.plt.is("iphone")) {
                this.barcodeScanner.scan().then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                    var _a, _b;
                    let data = (0,src_app_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_4__.descodificarQr)(res['text']);
                    let timestamp = (0,src_app_generic_utils_numbersUtils__WEBPACK_IMPORTED_MODULE_3__.stringToInteger)(data.timestamp);
                    let sucursalId = data.idOrigen;
                    (yield this.ventaCreditoService.onVentaCreditoQrAuth((_b = (_a = this.mainService.usuarioActual) === null || _a === void 0 ? void 0 : _a.persona) === null || _b === void 0 ? void 0 : _b.id, timestamp, sucursalId)).subscribe(res => {
                        console.log(res);
                    });
                }));
            }
        });
    }
};
MisFinanzasDashboardComponent.ctorParameters = () => [
    { type: _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.Platform },
    { type: src_app_graphql_financiero_venta_credito_venta_credito_service__WEBPACK_IMPORTED_MODULE_5__.VentaCreditoService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_6__.MainService }
];
MisFinanzasDashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-mis-finanzas-dashboard',
        template: _mis_finanzas_dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner],
        styles: [_mis_finanzas_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MisFinanzasDashboardComponent);



/***/ }),

/***/ 82174:
/*!*******************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/mis-finanzas-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MisFinanzasRoutingModule": () => (/* binding */ MisFinanzasRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _convenio_list_convenio_list_convenio_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./convenio/list-convenio/list-convenio.component */ 4395);
/* harmony import */ var _mis_finanzas_dashboard_mis_finanzas_dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mis-finanzas-dashboard/mis-finanzas-dashboard.component */ 82998);





const routes = [
    {
        path: '',
        component: _mis_finanzas_dashboard_mis_finanzas_dashboard_component__WEBPACK_IMPORTED_MODULE_1__.MisFinanzasDashboardComponent,
    },
    {
        path: 'list-convenio',
        component: _convenio_list_convenio_list_convenio_component__WEBPACK_IMPORTED_MODULE_0__.ListConvenioComponent,
    }
];
let MisFinanzasRoutingModule = class MisFinanzasRoutingModule {
};
MisFinanzasRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
    })
], MisFinanzasRoutingModule);



/***/ }),

/***/ 45735:
/*!***********************************************************!*\
  !*** ./src/app/pages/mis-finanzas/mis-finanzas.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MisFinanzasModule": () => (/* binding */ MisFinanzasModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _mis_finanzas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mis-finanzas-routing.module */ 82174);
/* harmony import */ var _mis_finanzas_dashboard_mis_finanzas_dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mis-finanzas-dashboard/mis-finanzas-dashboard.component */ 82998);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);
/* harmony import */ var _convenio_list_convenio_list_convenio_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./convenio/list-convenio/list-convenio.component */ 4395);









let MisFinanzasModule = class MisFinanzasModule {
};
MisFinanzasModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_mis_finanzas_dashboard_mis_finanzas_dashboard_component__WEBPACK_IMPORTED_MODULE_1__.MisFinanzasDashboardComponent, _convenio_list_convenio_list_convenio_component__WEBPACK_IMPORTED_MODULE_3__.ListConvenioComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _mis_finanzas_routing_module__WEBPACK_IMPORTED_MODULE_0__.MisFinanzasRoutingModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule
        ]
    })
], MisFinanzasModule);



/***/ }),

/***/ 63378:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/convenio/list-convenio/list-convenio.component.scss?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = ".totales {\n  width: 100%;\n  text-align: center;\n  font-size: 1.2em;\n}\n\n.valores {\n  width: 100%;\n  text-align: center;\n  font-size: 1.2em;\n}\n\n.success {\n  color: #43a047;\n}\n\n.warn {\n  color: #f57c00;\n}\n\nion-card {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3QtY29udmVuaW8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7QUFDRiIsImZpbGUiOiJsaXN0LWNvbnZlbmlvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvdGFsZXMge1xuICB3aWR0aDogMTAwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDEuMmVtO1xufVxuXG4udmFsb3JlcyB7XG4gIHdpZHRoOiAxMDAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMS4yZW07XG59XG5cbi5zdWNjZXNzIHtcbiAgY29sb3I6ICM0M2EwNDc7XG59XG5cbi53YXJuIHtcbiAgY29sb3I6ICNmNTdjMDA7XG59XG5cbmlvbi1jYXJkIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuIl19 */";

/***/ }),

/***/ 15787:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/mis-finanzas-dashboard/mis-finanzas-dashboard.component.scss?ngResource ***!
  \************************************************************************************************************/
/***/ ((module) => {

module.exports = ".card {\n  background-color: #f44336 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1pcy1maW5hbnphcy1kYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQ0FBQTtBQUNGIiwiZmlsZSI6Im1pcy1maW5hbnphcy1kYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNDQzMzYgIWltcG9ydGFudDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 92228:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/convenio/list-convenio/list-convenio.component.html?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content style=\"width: 100%\">\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\">Lista de convenios</ion-col>\n    <ion-col size=\"2\" style=\"text-align: center\">\n      <ion-icon\n        name=\"funnel\"\n        style=\"font-size: 1.5em\"\n        (click)=\"openFilterMenu()\"\n      ></ion-icon>\n    </ion-col>\n  </ion-row>\n  <div style=\"padding-left: 5px; padding-right: 5px\">\n    <ion-row>\n      <ion-col size=\"8\"> Convenios del mes: </ion-col>\n      <ion-col size=\"4\" style=\"text-align: end\">\n        {{ totalVentaCredito | number: '1.0-0' }}\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"8\"> Crédito: </ion-col>\n      <ion-col size=\"4\" style=\"text-align: end\">\n        {{ selectedCliente?.credito | number: '1.0-0' }} Gs.\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"8\"> Utilizado: </ion-col>\n      <ion-col size=\"4\" style=\"text-align: end\">\n        {{ totalAbiertos | number: '1.0-0' }} Gs.\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"8\"> Saldo: </ion-col>\n      <ion-col size=\"4\" style=\"text-align: end\">\n        {{ selectedCliente?.saldo | number: '1.0-0' }} Gs.\n      </ion-col>\n    </ion-row>\n  </div>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card\n          class=\"item\"\n          *ngFor=\"let ventaCredito of ventaCreditoList\"\n          (click)=\"onItemClick(ventaCredito)\"\n        >\n          <div>\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"6\">Venta: {{ ventaCredito.venta.id }}</ion-col>\n                <ion-col size=\"6\"\n                  >Fecha: {{ ventaCredito.creadoEn | date: 'short' }}</ion-col\n                >\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\"\n                  >Sucursal:\n                  {{ ventaCredito.sucursal.nombre | titlecase }}</ion-col\n                >\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\"\n                  >Cajero:\n                  {{\n                    ventaCredito.venta.usuario.persona.nombre | titlecase\n                  }}</ion-col\n                >\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\"\n                  >Confirmación:\n                  {{ ventaCredito.tipoConfirmacion | titlecase }}</ion-col\n                >\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\"\n                  >Estado: {{ ventaCredito.estado | titlecase }}</ion-col\n                >\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\">\n                  <div class=\"totales\">Total</div>\n                  <div class=\"valores success\">\n                    Gs. {{ ventaCredito.valorTotal | number: '1.0-0' }}\n                  </div>\n                </ion-col>\n              </ion-row>\n              <ion-row style=\"width: 100%\">\n                <ion-col size=\"12\" class=\"center\">\n                  <ion-button\n                    fill=\"clear\"\n                    class=\"btn-success-flat\"\n                    (click)=\"openVentaDetalle(ventaCredito.venta)\"\n                    >VER DETALLE</ion-button\n                  >\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ }),

/***/ 34362:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/mis-finanzas/mis-finanzas-dashboard/mis-finanzas-dashboard.component.html?ngResource ***!
  \************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-card class=\"card\" [routerLink]=\"['list-convenio']\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Convenios</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Lista de convenios realizados\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"onQrConfirm()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Confirmar via QR</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Confirmar convenios via QR\n    </ion-card-content>\n  </ion-card>\n\n  <!-- <ion-card class=\"card\" [routerLink]=\"['list-vales']\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Vales y anticipos</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Histórico de anticipos. Solicitar un vale.\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" [routerLink]=\"['resumen-financiero']\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Estado financiero</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Resumen general del estado financiero.\n    </ion-card-content>\n  </ion-card> -->\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mis-finanzas_mis-finanzas_module_ts.js.map