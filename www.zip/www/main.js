(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _pages_home_home_home_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/home/home/home.component */ 79328);
/* harmony import */ var _pages_salir_salir_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/salir/salir.component */ 70738);





const routes = [
    {
        path: '',
        component: _pages_home_home_home_component__WEBPACK_IMPORTED_MODULE_0__.HomeComponent
    },
    {
        path: 'inventario',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/inventario/inventario.module */ 30723)).then(m => m.InventarioModule)
    },
    {
        path: 'producto',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/producto/producto.module */ 10212)).then(m => m.ProductoModule)
    },
    {
        path: 'pre-registro',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/funcionario/funcionario.module */ 15677)).then(m => m.FuncionarioModule)
    },
    {
        path: 'salir',
        component: _pages_salir_salir_component__WEBPACK_IMPORTED_MODULE_1__.SalirComponent
    },
    {
        path: 'transferencias',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/transferencias/transferencias.module */ 1225)).then(m => m.TransferenciasModule)
    },
    {
        path: 'splash',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_splash_splash_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./splash/splash.module */ 89623)).then(m => m.SplashPageModule)
    },
    {
        path: 'operaciones',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_operaciones_operaciones_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/operaciones/operaciones.module */ 51264)).then(m => m.OperacionesModule)
    },
    {
        path: 'mis-finanzas',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mis-finanzas_mis-finanzas_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mis-finanzas/mis-finanzas.module */ 45735)).then(m => m.MisFinanzasModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_4__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 33383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 79259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/photo-viewer/ngx */ 13972);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _app_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.module */ 36747);
/* harmony import */ var _components_change_server_ip_dialog_change_server_ip_dialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/change-server-ip-dialog/change-server-ip-dialog.component */ 31962);
/* harmony import */ var _dialog_login_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dialog/login/login.component */ 20260);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/cargando.service */ 68030);
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./services/login.service */ 54120);
/* harmony import */ var _services_main_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./services/main.service */ 91557);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./services/modal.service */ 71609);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 74582);
/* harmony import */ var _services_fingerprint_auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./services/fingerprint-auth.service */ 68133);

















// import { App, URLOpenListenerEvent } from '@capacitor/app';
// declare let window: any; // Don't forget this part!
let AppComponent = class AppComponent {
    constructor(menu, mainService, loginService, popoverController, cargandoService, notificacionService, modalService, photoViewer, appVersion, platfform, fingerprintService) {
        this.menu = menu;
        this.mainService = mainService;
        this.loginService = loginService;
        this.popoverController = popoverController;
        this.cargandoService = cargandoService;
        this.notificacionService = notificacionService;
        this.modalService = modalService;
        this.photoViewer = photoViewer;
        this.appVersion = appVersion;
        this.platfform = platfform;
        this.fingerprintService = fingerprintService;
        this.online = false;
        this.puedeVerInventario = false;
        this.currentVersion = null;
        this.isFarma = false;
        this.optionZbar = {
            flash: 'off',
            drawSight: false
        };
        appVersion.getVersionNumber().then(res => {
            this.currentVersion = res;
        });
        this.isFarma = localStorage.getItem('serverIp').includes('158');
    }
    // initializeApp() {
    //   App.addListener('appUrlOpen', (event: URLOpenListenerEvent) => {
    //     this.zone.run(() => {
    //       // Example url: https://beerswift.app/tabs/tab2
    //       // slug = /tabs/tab2
    //       console.log(event)
    //       const slug = event.url.split(".app").pop();
    //       if (slug) {
    //         this.router.navigateByUrl(slug);
    //       }
    //       // If no match, do nothing - let regular routing
    //       // logic take over
    //     });
    //   });
    // }
    openInventario() {
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            this.showLoginPop();
            this.statusSub = _app_module__WEBPACK_IMPORTED_MODULE_4__.connectionStatusSub.pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.untilDestroyed)(this))
                .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
                let loading = yield this.cargandoService.open('Conectando al servidor..');
                if (res == true) {
                    this.cargandoService.close(loading);
                    this.notificacionService.open('Servidor conectado', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.TipoNotificacion.SUCCESS, 2);
                    this.online = true;
                }
                else if (res == false) {
                    this.online = false;
                    this.notificacionService.open('No se puede acceder al servidor', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.TipoNotificacion.DANGER, 2);
                }
                else {
                    this.cargandoService.close(loading);
                }
            }));
        });
    }
    openMenu() {
        // this.menu.open();
    }
    closeMenu() {
        this.menu.close();
    }
    onSalir() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open("Saliendo...");
            setTimeout(() => {
                this.cargandoService.close(loading);
                this.loginService.logOut();
                this.showLoginPop();
                this.menu.close();
            }, 1000);
        });
    }
    showLoginPop() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            // const pop = await this.popoverController.create({
            //   component: LoginComponent,
            //   cssClass: 'my-custom-class',
            //   translucent: true,
            //   backdropDismiss: false
            // });
            // await pop.present();
            this.modalService.openModal(_dialog_login_login_component__WEBPACK_IMPORTED_MODULE_6__.LoginComponent);
        });
    }
    openTransferencias() {
    }
    onAvatarClick() {
    }
    onIpChange() {
        this.modalService.openModal(_components_change_server_ip_dialog_change_server_ip_dialog_component__WEBPACK_IMPORTED_MODULE_5__.ChangeServerIpDialogComponent).then(res => {
            if (res == true) {
                window.location.reload();
            }
        });
    }
    openInfoPersonales() {
    }
    openMisFinanzas() {
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.MenuController },
    { type: _services_main_service__WEBPACK_IMPORTED_MODULE_9__.MainService },
    { type: _services_login_service__WEBPACK_IMPORTED_MODULE_8__.LoginService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.PopoverController },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_7__.CargandoService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.NotificacionService },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_10__.ModalService },
    { type: _awesome_cordova_plugins_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_2__.PhotoViewer },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_11__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.Platform },
    { type: _services_fingerprint_auth_service__WEBPACK_IMPORTED_MODULE_12__.FingerprintAuthService }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_2__.PhotoViewer, _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_11__.AppVersion],
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule),
/* harmony export */   "HammerConfig": () => (/* binding */ HammerConfig),
/* harmony export */   "appInit": () => (/* binding */ appInit),
/* harmony export */   "connectionStatusSub": () => (/* binding */ connectionStatusSub)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_common_locales_es_PY__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/locales/es-PY */ 1506);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _apollo_client_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @apollo/client/core */ 14000);
/* harmony import */ var _apollo_client_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @apollo/client/core */ 73927);
/* harmony import */ var _apollo_client_core__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @apollo/client/core */ 27156);
/* harmony import */ var _apollo_client_link_context__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @apollo/client/link/context */ 14765);
/* harmony import */ var _apollo_client_link_error__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @apollo/client/link/error */ 40609);
/* harmony import */ var _apollo_client_link_ws__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @apollo/client/link/ws */ 14057);
/* harmony import */ var _apollo_client_utilities__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @apollo/client/utilities */ 36699);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 33244);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var apollo_angular_http__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! apollo-angular/http */ 67720);
/* harmony import */ var ngx_currency__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ngx-currency */ 74172);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 84505);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var subscriptions_transport_ws__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! subscriptions-transport-ws */ 90337);
/* harmony import */ var subscriptions_transport_ws__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(subscriptions_transport_ws__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _dialog_login_cambiar_contrasenha_dialog_cambiar_contrasenha_dialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dialog/login/cambiar-contrasenha-dialog/cambiar-contrasenha-dialog.component */ 17050);
/* harmony import */ var _dialog_login_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dialog/login/login.component */ 20260);
/* harmony import */ var _pages_funcionario_funcionario_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/funcionario/funcionario.module */ 15677);
/* harmony import */ var _pages_inventario_inventario_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/inventario/inventario.module */ 30723);
/* harmony import */ var _pages_producto_producto_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/producto/producto.module */ 10212);
/* harmony import */ var _pages_transferencias_transferencias_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/transferencias/transferencias.module */ 1225);
/* harmony import */ var _services_main_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./services/main.service */ 91557);
/* harmony import */ var _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/fingerprint-aio/ngx */ 63427);































(0,_angular_common__WEBPACK_IMPORTED_MODULE_13__.registerLocaleData)(_angular_common_locales_es_PY__WEBPACK_IMPORTED_MODULE_0__["default"]);
switch (localStorage.getItem('serverIp')) {
    case null:
        localStorage.setItem('serverIp', src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.serverAdress.serverIp);
        localStorage.setItem('serverPort', src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.serverAdress.serverPort);
        break;
    case '':
        localStorage.setItem('serverIp', src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.serverAdress.serverIp);
        localStorage.setItem('serverPort', src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.serverAdress.serverPort);
        break;
    case 'null':
        localStorage.setItem('serverIp', src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.serverAdress.serverIp);
        localStorage.setItem('serverPort', src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.serverAdress.serverPort);
        break;
    default:
        break;
}
const uri = `http://${localStorage.getItem('serverIp')}:${localStorage.getItem('serverPort')}/graphql`;
const wUri = `ws://${localStorage.getItem('serverIp')}:${localStorage.getItem('serverPort')}/subscriptions`;
const errorLink = (0,_apollo_client_link_error__WEBPACK_IMPORTED_MODULE_14__.onError)(({ graphQLErrors, networkError }) => {
});
const wsClient = new subscriptions_transport_ws__WEBPACK_IMPORTED_MODULE_2__.SubscriptionClient(wUri, {
    reconnect: true
});
const connectionStatusSub = new rxjs__WEBPACK_IMPORTED_MODULE_15__.BehaviorSubject(null);
wsClient.onConnected(() => {
    connectionStatusSub.next(true);
});
wsClient.onDisconnected(() => {
    if (connectionStatusSub.value != false) {
        connectionStatusSub.next(false);
    }
});
wsClient.onReconnected(() => {
    connectionStatusSub.next(true);
});
let HammerConfig = class HammerConfig extends _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.HammerGestureConfig {
    constructor() {
        super(...arguments);
        this.overrides = {
            // I will only use the swap gesture so
            // I will deactivate the others to avoid overlaps
            'pinch': { enable: false },
            'rotate': { enable: false }
        };
    }
};
HammerConfig = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Injectable)()
], HammerConfig);

let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent, _dialog_login_login_component__WEBPACK_IMPORTED_MODULE_6__.LoginComponent, _dialog_login_cambiar_contrasenha_dialog_cambiar_contrasenha_dialog_component__WEBPACK_IMPORTED_MODULE_5__.CambiarContrasenhaDialogComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.BrowserModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HttpClientModule,
            apollo_angular__WEBPACK_IMPORTED_MODULE_21__.ApolloModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_22__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule,
            _pages_inventario_inventario_module__WEBPACK_IMPORTED_MODULE_8__.InventarioModule,
            _pages_transferencias_transferencias_module__WEBPACK_IMPORTED_MODULE_10__.TransferenciasModule,
            _pages_producto_producto_module__WEBPACK_IMPORTED_MODULE_9__.ProductoModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.HammerModule,
            ngx_currency__WEBPACK_IMPORTED_MODULE_23__.NgxCurrencyModule,
            _pages_funcionario_funcionario_module__WEBPACK_IMPORTED_MODULE_7__.FuncionarioModule,
            _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_24__.NgxQRCodeModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HttpClientModule,
        ],
        exports: [],
        providers: [
            _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_12__.FingerprintAIO,
            {
                provide: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.HAMMER_GESTURE_CONFIG,
                useClass: HammerConfig
            },
            { provide: _angular_core__WEBPACK_IMPORTED_MODULE_18__.LOCALE_ID, useValue: "es-PY" },
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_25__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicRouteStrategy },
            {
                provide: apollo_angular__WEBPACK_IMPORTED_MODULE_21__.APOLLO_OPTIONS,
                useFactory(httpLink) {
                    const basic = (0,_apollo_client_link_context__WEBPACK_IMPORTED_MODULE_26__.setContext)((operation, context) => ({
                    // headers: {
                    //   Accept: 'charset=utf-8'
                    // }
                    }));
                    const auth = (0,_apollo_client_link_context__WEBPACK_IMPORTED_MODULE_26__.setContext)((operation, context) => {
                        const token = localStorage.getItem('token');
                        if (token === null) {
                            return {};
                        }
                        else {
                            return {
                                headers: {
                                    Authorization: `Token ${token}`,
                                    "Access-Control-Allow-Origin": "*"
                                },
                            };
                        }
                    });
                    // Create an http link:
                    const http = _apollo_client_core__WEBPACK_IMPORTED_MODULE_27__.ApolloLink.from([
                        basic,
                        auth,
                        httpLink.create({
                            uri: uri,
                        }),
                    ]);
                    // Create a WebSocket link:
                    const ws = new _apollo_client_link_ws__WEBPACK_IMPORTED_MODULE_28__.WebSocketLink(wsClient);
                    // using the ability to split links, you can send data to each link
                    // depending on what kind of operation is being sent
                    const link = errorLink.concat((0,_apollo_client_core__WEBPACK_IMPORTED_MODULE_29__.split)(
                    // split based on operation type
                    ({ query }) => {
                        const definition = (0,_apollo_client_utilities__WEBPACK_IMPORTED_MODULE_30__.getMainDefinition)(query);
                        return (definition.kind === 'OperationDefinition' &&
                            definition.operation === 'subscription');
                    }, ws, http));
                    return {
                        link,
                        cache: new _apollo_client_core__WEBPACK_IMPORTED_MODULE_31__.InMemoryCache(),
                    };
                },
                deps: [apollo_angular_http__WEBPACK_IMPORTED_MODULE_32__.HttpLink],
            },
            [
                _services_main_service__WEBPACK_IMPORTED_MODULE_11__.MainService,
                {
                    provide: _angular_core__WEBPACK_IMPORTED_MODULE_18__.APP_INITIALIZER,
                    useFactory: appInit,
                    deps: [_services_main_service__WEBPACK_IMPORTED_MODULE_11__.MainService],
                    multi: true,
                },
            ],
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent],
    })
], AppModule);

function appInit(appConfigService) {
    return () => appConfigService.load();
}


/***/ }),

/***/ 31962:
/*!*****************************************************************************************!*\
  !*** ./src/app/components/change-server-ip-dialog/change-server-ip-dialog.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeServerIpDialogComponent": () => (/* binding */ ChangeServerIpDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _change_server_ip_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-server-ip-dialog.component.html?ngResource */ 12666);
/* harmony import */ var _change_server_ip_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-server-ip-dialog.component.scss?ngResource */ 93404);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/modal.service */ 71609);






let ChangeServerIpDialogComponent = class ChangeServerIpDialogComponent {
    constructor(modalService) {
        this.modalService = modalService;
        this.serverIpControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl();
        this.serverPortControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl();
    }
    ngOnInit() {
    }
    onGuardar() {
        localStorage.setItem('serverIp', this.serverIpControl.value);
        localStorage.setItem('serverPort', this.serverPortControl.value);
        localStorage.setItem('usuarioId', null);
        localStorage.setItem('token', null);
        window.location.reload();
    }
    onCancelar() {
        this.modalService.closeModal(null);
    }
    onBodegaClick() {
        localStorage.setItem('serverIp', '150.136.137.98');
        localStorage.setItem('serverPort', '8081');
        localStorage.setItem('usuarioId', null);
        localStorage.setItem('token', null);
        window.location.reload();
    }
    onFarmaciaClick() {
        localStorage.setItem('serverIp', '158.101.114.87');
        localStorage.setItem('serverPort', '8081');
        localStorage.setItem('usuarioId', null);
        localStorage.setItem('token', null);
        window.location.reload();
    }
};
ChangeServerIpDialogComponent.ctorParameters = () => [
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_2__.ModalService }
];
ChangeServerIpDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-change-server-ip-dialog',
        template: _change_server_ip_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_change_server_ip_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ChangeServerIpDialogComponent);



/***/ }),

/***/ 45642:
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./qr-generator/qr-generator.component */ 45713);
/* harmony import */ var _qr_scanner_dialog_qr_scanner_dialog_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./qr-scanner-dialog/qr-scanner-dialog.component */ 1199);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 33244);
/* harmony import */ var _generic_list_dialog_generic_list_dialog_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./generic-list-dialog/generic-list-dialog.component */ 99529);
/* harmony import */ var _change_server_ip_dialog_change_server_ip_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./change-server-ip-dialog/change-server-ip-dialog.component */ 31962);










let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_qr_scanner_dialog_qr_scanner_dialog_component__WEBPACK_IMPORTED_MODULE_1__.QrScannerDialogComponent, _qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_0__.QrGeneratorComponent, _generic_list_dialog_generic_list_dialog_component__WEBPACK_IMPORTED_MODULE_2__.GenericListDialogComponent, _change_server_ip_dialog_change_server_ip_dialog_component__WEBPACK_IMPORTED_MODULE_3__.ChangeServerIpDialogComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_9__.NgxQRCodeModule
        ],
        exports: [
            _qr_scanner_dialog_qr_scanner_dialog_component__WEBPACK_IMPORTED_MODULE_1__.QrScannerDialogComponent,
            _qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_0__.QrGeneratorComponent
        ]
    })
], ComponentsModule);



/***/ }),

/***/ 99529:
/*!*********************************************************************************!*\
  !*** ./src/app/components/generic-list-dialog/generic-list-dialog.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GenericListDialogComponent": () => (/* binding */ GenericListDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _generic_list_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic-list-dialog.component.html?ngResource */ 75624);
/* harmony import */ var _generic_list_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generic-list-dialog.component.scss?ngResource */ 33603);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/modal.service */ 71609);






let GenericListDialogComponent = class GenericListDialogComponent {
    constructor(modalService) {
        this.modalService = modalService;
        this.buscarControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]);
        this.itemList = [];
    }
    ngOnInit() {
        var _a, _b;
        if (((_a = this.data) === null || _a === void 0 ? void 0 : _a.inicialData) != null) {
            this.itemList = (_b = this.data) === null || _b === void 0 ? void 0 : _b.inicialData;
        }
    }
    onItemClick(item) {
        this.modalService.closeModal(item);
    }
    onBack() {
        this.modalService.closeModal(null);
    }
};
GenericListDialogComponent.ctorParameters = () => [
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_2__.ModalService }
];
GenericListDialogComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
GenericListDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-generic-list-dialog',
        template: _generic_list_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_generic_list_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GenericListDialogComponent);



/***/ }),

/***/ 23254:
/*!*********************************************************************!*\
  !*** ./src/app/components/image-popover/image-popover.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImagePopoverComponent": () => (/* binding */ ImagePopoverComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _image_popover_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./image-popover.component.html?ngResource */ 81361);
/* harmony import */ var _image_popover_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./image-popover.component.scss?ngResource */ 20451);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let ImagePopoverComponent = class ImagePopoverComponent {
    constructor() { }
    ngOnInit() {
    }
};
ImagePopoverComponent.ctorParameters = () => [];
ImagePopoverComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
ImagePopoverComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-image-popover',
        template: _image_popover_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_image_popover_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ImagePopoverComponent);



/***/ }),

/***/ 45713:
/*!*******************************************************************!*\
  !*** ./src/app/components/qr-generator/qr-generator.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrGeneratorComponent": () => (/* binding */ QrGeneratorComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _qr_generator_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./qr-generator.component.html?ngResource */ 95828);
/* harmony import */ var _qr_generator_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./qr-generator.component.scss?ngResource */ 76899);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/pop-over.service */ 21690);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);





let QrGeneratorComponent = class QrGeneratorComponent {
    constructor(popoverService) {
        this.popoverService = popoverService;
    }
    ngOnInit() {
        console.log(this.data);
        if (this.data != null) {
            this.value = this.data;
        }
    }
    onSalir() {
        this.popoverService.close(null);
    }
};
QrGeneratorComponent.ctorParameters = () => [
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_2__.PopOverService }
];
QrGeneratorComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
QrGeneratorComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-qr-generator',
        template: _qr_generator_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_qr_generator_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], QrGeneratorComponent);



/***/ }),

/***/ 1199:
/*!*****************************************************************************!*\
  !*** ./src/app/components/qr-scanner-dialog/qr-scanner-dialog.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrScannerDialogComponent": () => (/* binding */ QrScannerDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _qr_scanner_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./qr-scanner-dialog.component.html?ngResource */ 83777);
/* harmony import */ var _qr_scanner_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./qr-scanner-dialog.component.scss?ngResource */ 30326);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/modal.service */ 71609);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);





let QrScannerDialogComponent = class QrScannerDialogComponent {
    constructor(modalService) {
        this.modalService = modalService;
    }
    ngOnInit() {
        console.log(this.modalService.currentModal);
    }
    onSuccess(e) {
        this.modalService.closeModal(e);
    }
    onError(e) {
        this.modalService.closeModal(e);
    }
    onExit() {
        this.modalService.closeModal(null);
    }
};
QrScannerDialogComponent.ctorParameters = () => [
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_2__.ModalService }
];
QrScannerDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-qr-scanner-dialog',
        template: _qr_scanner_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_qr_scanner_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], QrScannerDialogComponent);



/***/ }),

/***/ 28602:
/*!*****************************************************************!*\
  !*** ./src/app/components/qr-scanner-dialog/scanner.service.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BarcodeFormat": () => (/* binding */ BarcodeFormat),
/* harmony export */   "ScannerService": () => (/* binding */ ScannerService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



var BarcodeFormat;
(function (BarcodeFormat) {
    BarcodeFormat["EAN_13"] = "EAN_13";
    BarcodeFormat["EAN_8"] = "EAN_8";
    BarcodeFormat["QR_CODE"] = "QR_CODE";
})(BarcodeFormat || (BarcodeFormat = {}));
let ScannerService = class ScannerService {
    constructor(matDialog) {
        this.matDialog = matDialog;
    }
};
ScannerService.ctorParameters = () => [
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_0__.DialogoService }
];
ScannerService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ScannerService);



/***/ }),

/***/ 17050:
/*!*************************************************************************************************!*\
  !*** ./src/app/dialog/login/cambiar-contrasenha-dialog/cambiar-contrasenha-dialog.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CambiarContrasenhaDialogComponent": () => (/* binding */ CambiarContrasenhaDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _cambiar_contrasenha_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cambiar-contrasenha-dialog.component.html?ngResource */ 20347);
/* harmony import */ var _cambiar_contrasenha_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cambiar-contrasenha-dialog.component.scss?ngResource */ 40001);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_domains_personas_usuario_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/domains/personas/usuario.model */ 78074);
/* harmony import */ var src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/cargando.service */ 68030);
/* harmony import */ var src_app_services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/pop-over.service */ 21690);
/* harmony import */ var src_app_services_usuario_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/usuario.service */ 65763);










let CambiarContrasenhaDialogComponent = class CambiarContrasenhaDialogComponent {
    constructor(popoverService, usuarioService, cargandoService) {
        this.popoverService = popoverService;
        this.usuarioService = usuarioService;
        this.cargandoService = cargandoService;
        this.password1Control = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3)]);
        this.password2Control = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3)]);
        this.isError = false;
        this.showPassword1 = false;
        this.showPassword2 = false;
        this.selectedUsuario = new src_app_domains_personas_usuario_model__WEBPACK_IMPORTED_MODULE_2__.Usuario;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.formGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
                'pass1': this.password1Control,
                'pass2': this.password2Control
            });
            this.formGroup.valueChanges.pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__.untilDestroyed)(this)).subscribe(res => {
                if (this.password2Control.value != null && this.password1Control.value != this.password2Control.value) {
                    this.isError = true;
                }
                else {
                    this.isError = false;
                }
            });
            let loading = yield this.cargandoService.open('Cargando...');
            setTimeout(() => {
                if (this.data != null) {
                    this.selectedUsuario = Object.assign(this.selectedUsuario, this.data);
                }
                else {
                    this.popoverService.close(null);
                }
                this.cargandoService.close(loading);
            }, 500);
        });
    }
    onCancel() {
        this.popoverService.close(null);
    }
    onAceptar() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.selectedUsuario.password = this.password1Control.value;
            (yield this.usuarioService.onSaveUsuario(this.selectedUsuario.toInput()))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    console.log(res);
                    this.popoverService.close(res);
                }
            });
        });
    }
};
CambiarContrasenhaDialogComponent.ctorParameters = () => [
    { type: src_app_services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopOverService },
    { type: src_app_services_usuario_service__WEBPACK_IMPORTED_MODULE_5__.UsuarioService },
    { type: src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_3__.CargandoService }
];
CambiarContrasenhaDialogComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input }]
};
CambiarContrasenhaDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-cambiar-contrasenha-dialog',
        template: _cambiar_contrasenha_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_cambiar_contrasenha_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CambiarContrasenhaDialogComponent);



/***/ }),

/***/ 20260:
/*!*************************************************!*\
  !*** ./src/app/dialog/login/login.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.component.html?ngResource */ 11073);
/* harmony import */ var _login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss?ngResource */ 99196);
/* harmony import */ var _pages_funcionario_pre_registro_funcionario_pre_registro_funcionario_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../pages/funcionario/pre-registro-funcionario/pre-registro-funcionario.component */ 84570);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/modal.service */ 71609);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../services/cargando.service */ 68030);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/login.service */ 54120);
/* harmony import */ var src_app_components_change_server_ip_dialog_change_server_ip_dialog_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/change-server-ip-dialog/change-server-ip-dialog.component */ 31962);














let LoginComponent = class LoginComponent {
    constructor(loginService, popoverController, cargandoService, notificacionService, router, modalService, platform, toastController) {
        this.loginService = loginService;
        this.popoverController = popoverController;
        this.cargandoService = cargandoService;
        this.notificacionService = notificacionService;
        this.router = router;
        this.modalService = modalService;
        this.platform = platform;
        this.toastController = toastController;
        this.selectedUsuario = null;
        this.usuarioControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.passwordControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.showPassword = false;
        this.msg = "Bienvenido/a";
        this.error = null;
        this.activateDev = 0;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.formGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroup({
                'usuario': this.usuarioControl,
                'password': this.passwordControl
            });
            this.loginService.isAuthenticated()
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_10__.untilDestroyed)(this))
                .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
                if (res != null) {
                    this.onSelectUsuarioAndDismiss(res);
                }
            }));
        });
    }
    onLogin() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.error = null;
            let usuario = this.usuarioControl.value;
            if (usuario[usuario.length - 1] == ' ') {
                usuario = usuario.substring(0, usuario.length - 2);
            }
            (yield this.loginService.login(usuario, this.passwordControl.value))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_10__.untilDestroyed)(this))
                .subscribe(res => {
                if (res.error == null) {
                    this.onSelectUsuarioAndDismiss(res.usuario);
                }
                else {
                    this.error = res.error['message'];
                    this.notificacionService.open(this.error, src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__.TipoNotificacion.DANGER, 10);
                }
            });
        });
    }
    onSelectUsuarioAndDismiss(usuario) {
        this.selectedUsuario = usuario;
        setTimeout(() => {
            this.modalService.closeModal(null);
        }, 2000);
    }
    onSolicitarNuevoUsuario() {
        this.modalService.closeModal(null);
        setTimeout(() => {
            this.modalService.openModal(_pages_funcionario_pre_registro_funcionario_pre_registro_funcionario_component__WEBPACK_IMPORTED_MODULE_2__.PreRegistroFuncionarioComponent);
        }, 1000);
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
    onDev() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.activateDev++;
            if (this.activateDev > 4 && this.activateDev < 8) {
                const t = yield this.toastController.create({
                    message: `Faltan ${8 - this.activateDev} para el DEV MODE`,
                    duration: 1
                });
                t.present();
            }
            else if (this.activateDev == 8) {
                this.modalService.openModal(src_app_components_change_server_ip_dialog_change_server_ip_dialog_component__WEBPACK_IMPORTED_MODULE_7__.ChangeServerIpDialogComponent).then(res => {
                    if (res == true) {
                        window.location.reload();
                    }
                });
            }
        });
    }
};
LoginComponent.ctorParameters = () => [
    { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_6__.LoginService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.PopoverController },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_5__.CargandoService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__.NotificacionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_3__.ModalService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ToastController }
];
LoginComponent.propDecorators = {
    nicknameInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild, args: ['nickname', { static: false },] }],
    passwordInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild, args: ['password', { static: false },] }]
};
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_10__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-login',
        template: _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginComponent);



/***/ }),

/***/ 69718:
/*!***********************************************************************!*\
  !*** ./src/app/domains/empresarial/sucursal/graphql/graphql-query.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteSucursalQuery": () => (/* binding */ deleteSucursalQuery),
/* harmony export */   "saveSucursal": () => (/* binding */ saveSucursal),
/* harmony export */   "sucursalActualQuery": () => (/* binding */ sucursalActualQuery),
/* harmony export */   "sucursalQuery": () => (/* binding */ sucursalQuery),
/* harmony export */   "sucursalesQuery": () => (/* binding */ sucursalesQuery),
/* harmony export */   "sucursalesSearch": () => (/* binding */ sucursalesSearch)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const sucursalesQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `{
    data: sucursales {
      id
      nombre
      localizacion
      ciudad{
        id
      }
      creadoEn
      usuario{
        id
      }
    }
  }`;
const sucursalesSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($texto: String){
    data : sucursalesSearch(texto: $texto){
      id
      nombre
      localizacion
      ciudad{
        id
      }
      creadoEn
      usuario{
        id
      }
    }
  }`;
const sucursalQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
    data : sucursal(id: $id){
      id
      nombre
      localizacion
      ciudad{
        id
      }
      creadoEn
      usuario{
        id
      }
    }
  }`;
const sucursalActualQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query{
    data : sucursalActual{
      id
      nombre
    }
  }`;
const saveSucursal = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `mutation saveSucursal($entity:SucursalInput!){
      data: saveSucursal(sucursal:$entity){
        id
      }
    }`;
const deleteSucursalQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] ` mutation deleteSucursal($id: ID!){
      deleteSucursal(id: $id)
    }`;


/***/ }),

/***/ 48629:
/*!************************************************************************!*\
  !*** ./src/app/domains/empresarial/sucursal/graphql/sucursalActual.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SucursalActualGQL": () => (/* binding */ SucursalActualGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 69718);




let SucursalActualGQL = class SucursalActualGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.sucursalActualQuery;
    }
};
SucursalActualGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SucursalActualGQL);



/***/ }),

/***/ 61185:
/*!**********************************************************************!*\
  !*** ./src/app/domains/empresarial/sucursal/graphql/sucursalById.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SucursalByIdGQL": () => (/* binding */ SucursalByIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 69718);




let SucursalByIdGQL = class SucursalByIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.sucursalQuery;
    }
};
SucursalByIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SucursalByIdGQL);



/***/ }),

/***/ 32166:
/*!*************************************************************************!*\
  !*** ./src/app/domains/empresarial/sucursal/graphql/sucursalesQuery.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SucursalesGQL": () => (/* binding */ SucursalesGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 69718);




let SucursalesGQL = class SucursalesGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.sucursalesQuery;
    }
};
SucursalesGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SucursalesGQL);



/***/ }),

/***/ 17976:
/*!******************************************************************!*\
  !*** ./src/app/domains/empresarial/sucursal/sucursal.service.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SucursalService": () => (/* binding */ SucursalService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _graphql_sucursalById__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/sucursalById */ 61185);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _graphql_sucursalesQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./graphql/sucursalesQuery */ 32166);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../environments/environment */ 92340);
/* harmony import */ var _graphql_sucursalActual__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/sucursalActual */ 48629);











let SucursalService = class SucursalService {
    constructor(getAllSucursales, NotificacionService, getSucursalActual, getSucursal, http, genericCrudService) {
        this.getAllSucursales = getAllSucursales;
        this.NotificacionService = NotificacionService;
        this.getSucursalActual = getSucursalActual;
        this.getSucursal = getSucursal;
        this.http = http;
        this.genericCrudService = genericCrudService;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders({
                Accept: "application/json",
                "Content-Type": "application/json",
            }),
        };
    }
    onGetAllSucursales() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onGetAll(this.getAllSucursales);
        });
    }
    onGetSucursal(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onGetById(this.getSucursal, id);
        });
    }
    getSucursalesAdmin() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable((obs) => {
            let httpBody = {
                nickname: "ADMIN",
                password: "ADMIN",
            };
            let httpResponse = this.http
                .post(`http://${_environments_environment__WEBPACK_IMPORTED_MODULE_4__.serverAdress.serverIp}:${_environments_environment__WEBPACK_IMPORTED_MODULE_4__.serverAdress.serverPort}/config/all-sucursales`, httpBody, this.httpOptions)
                .subscribe((res) => {
                obs.next(res);
            }, (error) => {
                obs.next(error);
            });
        });
    }
};
SucursalService.ctorParameters = () => [
    { type: _graphql_sucursalesQuery__WEBPACK_IMPORTED_MODULE_3__.SucursalesGQL },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_2__.NotificacionService },
    { type: _graphql_sucursalActual__WEBPACK_IMPORTED_MODULE_5__.SucursalActualGQL },
    { type: _graphql_sucursalById__WEBPACK_IMPORTED_MODULE_0__.SucursalByIdGQL },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_1__.GenericCrudService }
];
SucursalService = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_9__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable)({
        providedIn: "root",
    })
], SucursalService);



/***/ }),

/***/ 61246:
/*!****************************************************!*\
  !*** ./src/app/domains/enums/tipo-entidad.enum.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TipoEntidad": () => (/* binding */ TipoEntidad)
/* harmony export */ });
var TipoEntidad;
(function (TipoEntidad) {
    TipoEntidad["PRODUCTO"] = "PRO";
    TipoEntidad["CODIGO"] = "CO";
    TipoEntidad["PRESENTACION"] = "PRE";
    TipoEntidad["LONG"] = "LONG";
    TipoEntidad["USUARIO"] = "USR";
    TipoEntidad["PERSONA"] = "PER";
    TipoEntidad["PAIS"] = "PAIS";
    TipoEntidad["CIUDAD"] = "CIU";
    TipoEntidad["USUARIO_UPDATE"] = "USUARIO_UPDATE";
    TipoEntidad["FAMILIA"] = "FAM";
    TipoEntidad["SUBFAMILIA"] = "SFM";
    TipoEntidad["TIPO_PRESENTACION"] = "TPR";
    TipoEntidad["PDV_CATEGORIA"] = "PDV_CATEGORIA";
    TipoEntidad["PDV_GRUPO"] = "PDV_GRUPO";
    TipoEntidad["PDV_GRUPO_PRODUCTO"] = "PDV_GRUPO_PRODUCTO";
    TipoEntidad["SUCURSAL"] = "SUC";
    TipoEntidad["TIPO_PRECIO"] = "TPC";
    TipoEntidad["PRECIO_POR_SUCURSAL"] = "PPS";
    TipoEntidad["BANCO"] = "BANCO";
    TipoEntidad["CUENTA_BANCARIA"] = "CTB";
    TipoEntidad["MONEDA"] = "MON";
    TipoEntidad["MONEDAS_BILLETES"] = "MBT";
    TipoEntidad["FORMA_DE_PAGO"] = "FDP";
    TipoEntidad["DOCUMENTO"] = "DOC";
    TipoEntidad["MALETIN"] = "MLT";
    TipoEntidad["CARGO"] = "CARGO";
    TipoEntidad["TIPO_GASTO"] = "TGT";
    TipoEntidad["TIPO_GASTO_UPDATE"] = "TGU";
    TipoEntidad["CAMBIO"] = "CAMBIO";
    TipoEntidad["BARRIO"] = "BARRIO";
    TipoEntidad["CONTACTO"] = "CTC";
    TipoEntidad["CLIENTE"] = "CLI";
    TipoEntidad["FUNCIONARIO"] = "FUNC";
    TipoEntidad["PROVEEDOR"] = "PRV";
    TipoEntidad["VENDEDOR"] = "VDR";
    TipoEntidad["VENDEDOR_PROVEEDOR"] = "VDPR";
    TipoEntidad["ROLE"] = "ROL";
    TipoEntidad["USUARIO_ROLE"] = "URL";
    TipoEntidad["LOCAL"] = "LCL";
    TipoEntidad["TRANSFERENCIA"] = "TRF";
    TipoEntidad["TRANSFERENCIA_ITEM"] = "ITRF";
    TipoEntidad["TRANSFERENCIA_ITEM_DETALLE"] = "TRANSFERENCIA_ITEM_DETALLE";
    TipoEntidad["INVENTARIO"] = "INV";
    TipoEntidad["CONTEO"] = "CONTEO";
})(TipoEntidad || (TipoEntidad = {}));


/***/ }),

/***/ 78074:
/*!***************************************************!*\
  !*** ./src/app/domains/personas/usuario.model.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Usuario": () => (/* binding */ Usuario),
/* harmony export */   "UsuarioInput": () => (/* binding */ UsuarioInput)
/* harmony export */ });
class Usuario {
    toInput() {
        var _a, _b;
        let input = new UsuarioInput;
        input.id = this.id;
        input.personaId = (_a = this.persona) === null || _a === void 0 ? void 0 : _a.id;
        input.password = this.password;
        input.nickname = this.nickname;
        input.usuarioId = (_b = this.usuario) === null || _b === void 0 ? void 0 : _b.id;
        return input;
    }
}
class UsuarioInput {
}


/***/ }),

/***/ 57990:
/*!********************************************************!*\
  !*** ./src/app/domains/sector/graphql/deleteSector.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteSectorGQL": () => (/* binding */ DeleteSectorGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 75369);




let DeleteSectorGQL = class DeleteSectorGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteSectorQuery;
    }
};
DeleteSectorGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteSectorGQL);



/***/ }),

/***/ 75369:
/*!*********************************************************!*\
  !*** ./src/app/domains/sector/graphql/graphql-query.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteSectorQuery": () => (/* binding */ deleteSectorQuery),
/* harmony export */   "saveSector": () => (/* binding */ saveSector),
/* harmony export */   "sectorQuery": () => (/* binding */ sectorQuery),
/* harmony export */   "sectoresQuery": () => (/* binding */ sectoresQuery),
/* harmony export */   "sectoresSearch": () => (/* binding */ sectoresSearch)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const sectoresQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
  data : sectores(id: $id){
    id
    sucursal {
      nombre
    }
    descripcion
    activo
    creadoEn
    usuario{
      id
    }
    zonaList {
      id
      descripcion
    }
  }
}`;
const sectoresSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($texto: String){
    data : sectoresSearch(texto: $texto){
      id
      sucursal {
        nombre
      }
      descripcion
      activo
      creadoEn
      usuario{
        id
      }
      zonaList {
        id
        descripcion
      }
    }
  }`;
const sectorQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
    data : sector(id: $id){
      id
      sucursal {
        nombre
      }
      descripcion
      activo
      creadoEn
      usuario{
        id
      }
      zonaList {
        id
        descripcion
      }
    }
  }`;
const saveSector = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `mutation saveSector($entity:SectorInput!){
      data: saveSector(sector:$entity){
        id
      sucursal {
        nombre
      }
      descripcion
      activo
      creadoEn
      usuario{
        id
      }
      zonaList {
        id
        descripcion
      }
      }
    }`;
const deleteSectorQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] ` mutation deleteSector($id: ID!){
      deleteSector(id: $id)
    }`;


/***/ }),

/***/ 73080:
/*!******************************************************!*\
  !*** ./src/app/domains/sector/graphql/saveSector.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveSectorGQL": () => (/* binding */ SaveSectorGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 75369);




let SaveSectorGQL = class SaveSectorGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveSector;
    }
};
SaveSectorGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveSectorGQL);



/***/ }),

/***/ 98929:
/*!******************************************************!*\
  !*** ./src/app/domains/sector/graphql/sectorById.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SectorByIdGQL": () => (/* binding */ SectorByIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 75369);




let SectorByIdGQL = class SectorByIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.sectorQuery;
    }
};
SectorByIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SectorByIdGQL);



/***/ }),

/***/ 88879:
/*!*********************************************************!*\
  !*** ./src/app/domains/sector/graphql/sectoresQuery.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SectoresGQL": () => (/* binding */ SectoresGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 75369);




let SectoresGQL = class SectoresGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.sectoresQuery;
    }
};
SectoresGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SectoresGQL);



/***/ }),

/***/ 57701:
/*!**************************************************!*\
  !*** ./src/app/domains/sector/sector.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SectorService": () => (/* binding */ SectorService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _graphql_deleteSector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/deleteSector */ 57990);
/* harmony import */ var _graphql_saveSector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./graphql/saveSector */ 73080);
/* harmony import */ var _graphql_sectoresQuery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./graphql/sectoresQuery */ 88879);
/* harmony import */ var _graphql_sectorById__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./graphql/sectorById */ 98929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);







let SectorService = class SectorService {
    constructor(genericCrud, getSector, getSectores, saveSector, deleteSector) {
        this.genericCrud = genericCrud;
        this.getSector = getSector;
        this.getSectores = getSectores;
        this.saveSector = saveSector;
        this.deleteSector = deleteSector;
    }
    onGetSector(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetById(this.getSector, id);
        });
    }
    onGetSectores(sucursalId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetById(this.getSectores, sucursalId);
        });
    }
    onSaveSector(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onSave(this.saveSector, input);
        });
    }
    onDeleteSector(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onDelete(this.deleteSector, id);
        });
    }
};
SectorService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_4__.GenericCrudService },
    { type: _graphql_sectorById__WEBPACK_IMPORTED_MODULE_3__.SectorByIdGQL },
    { type: _graphql_sectoresQuery__WEBPACK_IMPORTED_MODULE_2__.SectoresGQL },
    { type: _graphql_saveSector__WEBPACK_IMPORTED_MODULE_1__.SaveSectorGQL },
    { type: _graphql_deleteSector__WEBPACK_IMPORTED_MODULE_0__.DeleteSectorGQL }
];
SectorService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], SectorService);



/***/ }),

/***/ 18531:
/*!*************************************************!*\
  !*** ./src/app/generic/generic-crud.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GenericCrudService": () => (/* binding */ GenericCrudService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../services/cargando.service */ 68030);
/* harmony import */ var _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _services_main_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/main.service */ 91557);










let GenericCrudService = class GenericCrudService {
    constructor(mainService, dialogoService, notificacionService, cargandoService, apollo) {
        this.mainService = mainService;
        this.dialogoService = dialogoService;
        this.notificacionService = notificacionService;
        this.cargandoService = cargandoService;
        this.apollo = apollo;
        this.isLoading = false;
    }
    onCustomGet(gql, data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch(data, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.isLoading = false;
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        if (res.data["data"] != null) {
                            this.notificacionService.success("Item encontrada");
                        }
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onCustomSub(gql, data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .subscribe(data, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.isLoading = false;
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        if (res.data["data"] != null) {
                            this.notificacionService.success("Item encontrada");
                        }
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onGetAll(gql, page, size) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch({ page, size }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.isLoading = false;
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                    }
                    else {
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onGetById(gql, id, page, size, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = true;
            let loading = yield this.cargandoService.open('Buscando...', false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch({ id, page, size, sucId }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.isLoading = false;
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        if (res.data["data"] == null) {
                            this.notificacionService.open('Item no encontrado', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.WARN, 2);
                        }
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onGet(gql, data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = true;
            let loading = yield this.cargandoService.open('Buscando...', false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch(data, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.isLoading = false;
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        if (res.data["data"] == null) {
                            this.notificacionService.open('Item no encontrado', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.WARN, 2);
                        }
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onGetByTexto(gql, texto) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = true;
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch({ texto }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    console.log(res);
                    this.cargandoService.close(loading);
                    this.isLoading = false;
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onGetByTextoPorSucursal(gql, texto, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = true;
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch({ texto, sucId }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    console.log(res);
                    this.cargandoService.close(loading);
                    this.isLoading = false;
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onSave(gql, input, sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = true;
            let loading = yield this.cargandoService.open(null, false);
            if (input.usuarioId == null) {
                input.usuarioId = +localStorage.getItem("usuarioId");
            }
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .mutate({ entity: input, sucId }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.isLoading = false;
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        this.notificacionService.open('Guardado con éxito', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.SUCCESS, 2);
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onDelete(gql, id, titulo, data, showDialog) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                if (showDialog == false) {
                    gql
                        .mutate({
                        id,
                    }, { errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                        .subscribe((res) => {
                        this.cargandoService.close(loading);
                        if (res.errors == null) {
                            this.notificacionService.open('Eliminado con éxito', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.SUCCESS, 2);
                            obs.next(true);
                        }
                        else {
                            {
                                console.log(res.errors);
                                this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                                obs.next(null);
                            }
                        }
                    });
                }
                else {
                    this.cargandoService.close(loading);
                    this.dialogoService
                        .open("Atención!!", "Realemente desea eliminar este item:" + titulo, true).then((res1) => {
                        if (res1) {
                            gql
                                .mutate({
                                id,
                            }, { errorPolicy: "all" })
                                .subscribe((res) => {
                                this.cargandoService.close(loading);
                                if (res.errors == null) {
                                    this.notificacionService.open('Eliminado con éxito', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.SUCCESS, 2);
                                    obs.next(true);
                                }
                                else {
                                    {
                                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                                        obs.next(null);
                                    }
                                }
                            });
                        }
                    });
                }
            });
        });
    }
    onGetByFecha(gql, inicio, fin) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let hoy = new Date();
            let ayer = new Date(hoy.getDay() - 1);
            ayer.setHours(0);
            ayer.setMinutes(0);
            ayer.setSeconds(0);
            let loading = yield this.cargandoService.open(null, false);
            if (inicio == null) {
                if (fin == null) {
                    inicio = ayer;
                    fin = hoy;
                }
                else {
                    let aux = new Date(fin);
                    aux.setHours(0);
                    aux.setMinutes(0);
                    aux.setSeconds(0);
                    inicio = aux;
                }
            }
            else {
                if (fin == null) {
                    fin = hoy;
                }
            }
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .fetch({ inicio, fin }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                    }
                    else {
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
    onSaveConDetalle(gql, entity, detalleList, info) {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            entity.usuarioId = (_b = (_a = this.mainService) === null || _a === void 0 ? void 0 : _a.usuarioActual) === null || _b === void 0 ? void 0 : _b.id;
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .mutate({
                    entity,
                    detalleList,
                }, {
                    fetchPolicy: "no-cache",
                    errorPolicy: "all",
                }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        this.notificacionService.open('Guardado con éxito', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.SUCCESS, 2);
                        obs.next(res.data['data']);
                    }
                    else {
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                        console.log(res);
                        obs.next(null);
                    }
                });
            });
        });
    }
    onCustomSave(gql, data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable((obs) => {
                gql
                    .mutate(data, {
                    fetchPolicy: "no-cache",
                    errorPolicy: "all",
                }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        this.notificacionService.open('Guardado con éxito', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.SUCCESS, 2);
                        obs.next(res.data['data']);
                    }
                    else {
                        this.notificacionService.open('Ups!! Algo salió mal', _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.TipoNotificacion.DANGER, 2);
                        console.log(res);
                        obs.next(null);
                    }
                });
            });
        });
    }
};
GenericCrudService.ctorParameters = () => [
    { type: _services_main_service__WEBPACK_IMPORTED_MODULE_3__.MainService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService },
    { type: _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.NotificacionService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_0__.CargandoService },
    { type: apollo_angular__WEBPACK_IMPORTED_MODULE_7__.Apollo }
];
GenericCrudService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable)({
        providedIn: "root",
    })
], GenericCrudService);



/***/ }),

/***/ 8535:
/*!********************************************!*\
  !*** ./src/app/generic/utils/dateUtils.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "convertMsToTime": () => (/* binding */ convertMsToTime),
/* harmony export */   "dateToString": () => (/* binding */ dateToString)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 36362);

function dateToString(date) {
    if (date != null) {
        return (0,_angular_common__WEBPACK_IMPORTED_MODULE_0__.formatDate)(date, 'yyyy-MM-dd HH:mm', 'en-Us');
    }
}
function convertMsToTime(milliseconds) {
    let seconds = Math.floor(milliseconds / 1000);
    let minutes = Math.floor(seconds / 60);
    let hours = Math.floor(minutes / 60);
    seconds = seconds % 60;
    minutes = minutes % 60;
    // 👇️ If you don't want to roll hours over, e.g. 24 to 00
    // 👇️ comment (or remove) the line below
    // commenting next line gets you `24:00:00` instead of `00:00:00`
    // or `36:15:31` instead of `12:15:31`, etc.
    // hours = hours % 24;
    return `${padTo2Digits(hours)}:${padTo2Digits(minutes)}:${padTo2Digits(seconds)}`;
}
function padTo2Digits(num) {
    return num.toString().padStart(2, '0');
}


/***/ }),

/***/ 37867:
/*!***********************************************!*\
  !*** ./src/app/generic/utils/numbersUtils.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CurrencyMask": () => (/* binding */ CurrencyMask),
/* harmony export */   "NumberUtils": () => (/* binding */ NumberUtils),
/* harmony export */   "isInt": () => (/* binding */ isInt),
/* harmony export */   "stringToCantidad": () => (/* binding */ stringToCantidad),
/* harmony export */   "stringToDecimal": () => (/* binding */ stringToDecimal),
/* harmony export */   "stringToInteger": () => (/* binding */ stringToInteger),
/* harmony export */   "stringToUnknown": () => (/* binding */ stringToUnknown),
/* harmony export */   "updateDataSource": () => (/* binding */ updateDataSource),
/* harmony export */   "updateDataSourceWithId": () => (/* binding */ updateDataSourceWithId)
/* harmony export */ });
/* harmony import */ var ngx_currency__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ngx-currency */ 74172);

class NumberUtils {
}
class CurrencyMask {
    constructor() {
        this.showMaskTyped = 'true';
        this.currencyOptionsGuarani = {
            allowNegative: true,
            precision: 0,
            thousands: '.',
            nullable: false,
            inputMode: ngx_currency__WEBPACK_IMPORTED_MODULE_0__.CurrencyMaskInputMode.NATURAL,
            align: 'right',
            allowZero: true,
            decimal: null,
            prefix: '',
            suffix: '',
            max: null,
            min: null,
        };
        this.currencyOptionsNoGuarani = {
            allowNegative: true,
            precision: 2,
            thousands: ',',
            nullable: false,
            inputMode: ngx_currency__WEBPACK_IMPORTED_MODULE_0__.CurrencyMaskInputMode.FINANCIAL,
            align: 'right',
            allowZero: true,
            decimal: '.',
            prefix: '',
            suffix: '',
            max: null,
            min: null,
        };
        this.currencyOptionsCantidad = {
            allowNegative: true,
            precision: 2,
            thousands: ',',
            nullable: false,
            inputMode: ngx_currency__WEBPACK_IMPORTED_MODULE_0__.CurrencyMaskInputMode.NATURAL,
            align: 'right',
            allowZero: true,
            decimal: '.',
            prefix: '',
            suffix: '',
            max: null,
            min: null,
        };
    }
}
function isInt(n) {
    return n % 1 === 0;
}
function updateDataSource(arr, value, index) {
    let aux = arr;
    if (value != null) {
        if (index != null) {
            aux[index] = value;
        }
        else {
            aux.push(value);
        }
    }
    else {
        arr = arr.splice(index, 1);
    }
    return aux;
}
function updateDataSourceWithId(arr, value, id) {
    let aux = arr;
    if (id != null) {
        let index = arr.findIndex(e => e.id == id);
        if (index != -1) {
            aux[index] = value;
        }
        else {
            aux.push(value);
        }
    }
    return aux;
}
function stringToInteger(texto) {
    let lenght = texto.length;
    let factor = Math.floor((lenght - 1) / 3);
    let auxIndex = lenght;
    for (let index = factor; index > 0; index--) {
        auxIndex -= 3;
        texto = texto.slice(0, auxIndex) + "." + texto.slice(auxIndex);
    }
    return texto;
}
function stringToDecimal(texto) {
    // if(texto[texto.length-1]=='0' && texto[texto.length-2]=='0' && texto[texto.length-3]=='.'){
    //   texto = texto.slice(0, texto.length - 3);
    // }
    if (texto == '0') {
        return '0,00';
    }
    else {
        texto = texto.replace('.', ',');
        let dotIndex = texto.indexOf(',');
        if (texto[dotIndex + 2] == null) {
            texto = texto + '0';
        }
        texto = stringToInteger(texto.slice(0, texto.length - 3)) + texto.slice(texto.length - 3, texto.length);
        return texto;
    }
}
function stringToCantidad(texto) {
    if (texto[texto.length - 1] == '0' && texto[texto.length - 2] == '0' && texto[texto.length - 3] == '0' && texto[texto.length - 4] == '.') {
        texto = texto.slice(0, texto.length - 4);
    }
    if (texto == '0') {
        return '0,00';
    }
    else {
        texto = texto.replace('.', ',');
        let dotIndex = texto.indexOf(',');
        if (texto[dotIndex + 2] == null) {
            texto = texto + '0';
        }
        texto = stringToInteger(texto.slice(0, texto.length - 3)) + texto.slice(texto.length - 3, texto.length);
        return texto;
    }
}
function stringToUnknown(texto) {
    if (texto[texto.length - 3] == '.') {
        return stringToDecimal(texto);
    }
    else {
        return stringToInteger(texto);
    }
}


/***/ }),

/***/ 83503:
/*!******************************************!*\
  !*** ./src/app/generic/utils/qrUtils.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrData": () => (/* binding */ QrData),
/* harmony export */   "codificarQr": () => (/* binding */ codificarQr),
/* harmony export */   "descodificarQr": () => (/* binding */ descodificarQr)
/* harmony export */ });
class QrData {
}
function codificarQr(data) {
    return 'frc-' + (data === null || data === void 0 ? void 0 : data.sucursalId) + '-' + (data === null || data === void 0 ? void 0 : data.tipoEntidad) + '-' + (data === null || data === void 0 ? void 0 : data.idOrigen) + '-' + (data === null || data === void 0 ? void 0 : data.idCentral) + '-' + (data === null || data === void 0 ? void 0 : data.componentToOpen) + '-' + (data === null || data === void 0 ? void 0 : data.data) + '-' + (data === null || data === void 0 ? void 0 : data.timestamp);
}
function descodificarQr(codigo) {
    let arr = codigo.split('-');
    let res = {
        sucursalId: arr[1],
        tipoEntidad: arr[2],
        idOrigen: arr[3],
        idCentral: arr[4],
        componentToOpen: arr[5],
        data: arr[6],
        timestamp: arr[7]
    };
    return res;
}


/***/ }),

/***/ 44426:
/*!***********************************************!*\
  !*** ./src/app/generic/utils/string-utils.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "comparatorLike": () => (/* binding */ comparatorLike)
/* harmony export */ });
function comparatorLike(str1, str2) {
    let length = str1.length;
    let newStr = '';
    for (let index = 0; index < length; index++) {
        if (str1[index] != ' ') {
            newStr = newStr + str1[index] + '.*';
        }
    }
    return str2.match(new RegExp(newStr, 'i'));
}


/***/ }),

/***/ 48942:
/*!*******************************************************************!*\
  !*** ./src/app/graphql/personas/usuario/graphql/graphql-query.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteUsuarioQuery": () => (/* binding */ deleteUsuarioQuery),
/* harmony export */   "saveUsuario": () => (/* binding */ saveUsuario),
/* harmony export */   "usuarioPorPersonaIdQuery": () => (/* binding */ usuarioPorPersonaIdQuery),
/* harmony export */   "usuarioQuery": () => (/* binding */ usuarioQuery),
/* harmony export */   "usuariosQuery": () => (/* binding */ usuariosQuery),
/* harmony export */   "usuariosSearch": () => (/* binding */ usuariosSearch)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const usuariosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    usuario {
      id
      nickname
      persona {
        id
        nombre
      }
      password
      creadoEn
      usuario {
        persona {
          nombre
        }
      }
    }
  }
`;
const usuariosSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: usuarioSearch(texto: $texto) {
      id
      nickname
      persona {
        id
        nombre
      }
      password
      creadoEn
      usuario {
        persona {
          nombre
        }
      }
    }
  }
`;
const usuarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: usuario(id: $id) {
      id
      nickname
      persona {
        id
        nombre
      }
      password
      creadoEn
      usuario {
        persona {
          nombre
        }
      }
      roles
    }
  }
`;
const usuarioPorPersonaIdQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: usuarioPorPersonaId(id: $id) {
      id
      nickname
      persona {
        id
        nombre
      }
      password
      creadoEn
      usuario {
        persona {
          nombre
        }
      }
      roles
    }
  }
`;
const saveUsuario = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveUsuario($entity: UsuarioInput!) {
    data: saveUsuario(usuario: $entity) {
      id
      nickname
      persona {
        id
        nombre
      }
      password
      creadoEn
      usuario {
        persona {
          nombre
        }
      }
    }
  }
`;
const deleteUsuarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteUsuario($id: ID!) {
    deleteUsuario(id: $id)
  }
`;
// usuarioPorPersonaId


/***/ }),

/***/ 55354:
/*!*****************************************************************!*\
  !*** ./src/app/graphql/personas/usuario/graphql/saveUsuario.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveUsuarioGQL": () => (/* binding */ SaveUsuarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 48942);




let SaveUsuarioGQL = class SaveUsuarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveUsuario;
    }
};
SaveUsuarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveUsuarioGQL);



/***/ }),

/***/ 25301:
/*!******************************************************************!*\
  !*** ./src/app/graphql/personas/usuario/graphql/usuarioPorId.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuarioPorIdGQL": () => (/* binding */ UsuarioPorIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 48942);




let UsuarioPorIdGQL = class UsuarioPorIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.usuarioQuery;
    }
};
UsuarioPorIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], UsuarioPorIdGQL);



/***/ }),

/***/ 85747:
/*!*************************************************************************!*\
  !*** ./src/app/graphql/personas/usuario/graphql/usuarioPorPersonaId.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuarioPorPersonaIdGQL": () => (/* binding */ UsuarioPorPersonaIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 48942);




let UsuarioPorPersonaIdGQL = class UsuarioPorPersonaIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.usuarioPorPersonaIdQuery;
    }
};
UsuarioPorPersonaIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], UsuarioPorPersonaIdGQL);



/***/ }),

/***/ 74003:
/*!*******************************************************************!*\
  !*** ./src/app/graphql/personas/usuario/graphql/usuarioSearch.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuarioSearchGQL": () => (/* binding */ UsuarioSearchGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 48942);




class Response {
}
let UsuarioSearchGQL = class UsuarioSearchGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.usuariosSearch;
    }
};
UsuarioSearchGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], UsuarioSearchGQL);



/***/ }),

/***/ 75130:
/*!************************************************!*\
  !*** ./src/app/pages/codigo/codigo.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodigoService": () => (/* binding */ CodigoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _graphql_codigoPorCodigo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/codigoPorCodigo */ 98131);
/* harmony import */ var _graphql_codigoPorPresentacionId__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./graphql/codigoPorPresentacionId */ 41364);
/* harmony import */ var _graphql_deleteCodigo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./graphql/deleteCodigo */ 57936);
/* harmony import */ var _graphql_saveCodigo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./graphql/saveCodigo */ 7356);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 84505);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);












let CodigoService = class CodigoService {
    constructor(mainService, saveCodigo, getCodigosPorPresentacionId, deleteCodigo, notificacionService, getCodigoPorCodigo, dialogoService, genericService) {
        this.mainService = mainService;
        this.saveCodigo = saveCodigo;
        this.getCodigosPorPresentacionId = getCodigosPorPresentacionId;
        this.deleteCodigo = deleteCodigo;
        this.notificacionService = notificacionService;
        this.getCodigoPorCodigo = getCodigoPorCodigo;
        this.dialogoService = dialogoService;
        this.genericService = genericService;
        this.dataOBs = new rxjs__WEBPACK_IMPORTED_MODULE_8__.BehaviorSubject(null);
    }
    onGetCodigosPorPresentacionId(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.getCodigosPorPresentacionId, id);
        });
    }
    onSaveCodigo(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            input.id == null ? (input.activo = true) : null;
            if (input.principal == false)
                input.principal = null;
            return yield this.genericService.onSave(this.saveCodigo, input);
        });
    }
    onDeleteCodigo(codigo) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onDelete(this.deleteCodigo, codigo.id);
        });
    }
    onGetCodigoPorCodigo(texto) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetByTexto(this.getCodigoPorCodigo, texto);
        });
    }
};
CodigoService.ctorParameters = () => [
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_4__.MainService },
    { type: _graphql_saveCodigo__WEBPACK_IMPORTED_MODULE_3__.SaveCodigoGQL },
    { type: _graphql_codigoPorPresentacionId__WEBPACK_IMPORTED_MODULE_1__.CodigosPorPresentacionIdGQL },
    { type: _graphql_deleteCodigo__WEBPACK_IMPORTED_MODULE_2__.DeleteCodigoGQL },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__.NotificacionService },
    { type: _graphql_codigoPorCodigo__WEBPACK_IMPORTED_MODULE_0__.CodigoPorCodigoGQL },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_6__.DialogoService },
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_7__.GenericCrudService }
];
CodigoService = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_10__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Injectable)({
        providedIn: "root",
    })
], CodigoService);



/***/ }),

/***/ 98131:
/*!*********************************************************!*\
  !*** ./src/app/pages/codigo/graphql/codigoPorCodigo.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodigoPorCodigoGQL": () => (/* binding */ CodigoPorCodigoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 54311);




let CodigoPorCodigoGQL = class CodigoPorCodigoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.codigoPorCodigo;
    }
};
CodigoPorCodigoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CodigoPorCodigoGQL);



/***/ }),

/***/ 41364:
/*!*****************************************************************!*\
  !*** ./src/app/pages/codigo/graphql/codigoPorPresentacionId.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodigosPorPresentacionIdGQL": () => (/* binding */ CodigosPorPresentacionIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 54311);




let CodigosPorPresentacionIdGQL = class CodigosPorPresentacionIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.codigosPorPresentacionId;
    }
};
CodigosPorPresentacionIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CodigosPorPresentacionIdGQL);



/***/ }),

/***/ 57936:
/*!******************************************************!*\
  !*** ./src/app/pages/codigo/graphql/deleteCodigo.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteCodigoGQL": () => (/* binding */ DeleteCodigoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 54311);




let DeleteCodigoGQL = class DeleteCodigoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteCodigoQuery;
    }
};
DeleteCodigoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteCodigoGQL);



/***/ }),

/***/ 54311:
/*!*******************************************************!*\
  !*** ./src/app/pages/codigo/graphql/graphql-query.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "codigoPorCodigo": () => (/* binding */ codigoPorCodigo),
/* harmony export */   "codigoQuery": () => (/* binding */ codigoQuery),
/* harmony export */   "codigosPorPresentacionId": () => (/* binding */ codigosPorPresentacionId),
/* harmony export */   "codigosQuery": () => (/* binding */ codigosQuery),
/* harmony export */   "deleteCodigoQuery": () => (/* binding */ deleteCodigoQuery),
/* harmony export */   "saveCodigo": () => (/* binding */ saveCodigo)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const codigosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    id
    activo
    principal
    codigo
  }
`;
// export const codigoPorProductoId = gql
// `
// `
const codigoPorCodigo = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: codigoPorCodigo(texto: $texto) {
      id
      activo
      principal
      codigo
      presentacion {
        id
        cantidad
        activo
        producto {
          id
          descripcion
          balanza
        }
      }
    }
  }
`;
const codigosPorPresentacionId = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: Int) {
    data: codigosPorPresentacionId(id: $id) {
      id
      activo
      principal
      codigo
    }
  }
`;
const codigoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: codigo(id: $id) {
      id
      activo
      principal
      codigo
    }
  }
`;
const saveCodigo = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveCodigo($entity: CodigoInput!) {
    data: saveCodigo(codigo: $entity) {
      id
      activo
      principal
      codigo
      presentacion {
        id
      }
    }
  }
`;
const deleteCodigoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteCodigo($id: ID!) {
    deleteCodigo(id: $id)
  }
`;


/***/ }),

/***/ 7356:
/*!****************************************************!*\
  !*** ./src/app/pages/codigo/graphql/saveCodigo.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveCodigoGQL": () => (/* binding */ SaveCodigoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 54311);




let SaveCodigoGQL = class SaveCodigoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveCodigo;
    }
};
SaveCodigoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveCodigoGQL);



/***/ }),

/***/ 1897:
/*!*****************************************************************!*\
  !*** ./src/app/pages/funcionario/funcionario-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FuncionarioRoutingModule": () => (/* binding */ FuncionarioRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _pre_registro_funcionario_pre_registro_funcionario_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pre-registro-funcionario/pre-registro-funcionario.component */ 84570);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);




const routes = [
    {
        path: 'pre-registro',
        component: _pre_registro_funcionario_pre_registro_funcionario_component__WEBPACK_IMPORTED_MODULE_0__.PreRegistroFuncionarioComponent,
    }
];
let FuncionarioRoutingModule = class FuncionarioRoutingModule {
};
FuncionarioRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], FuncionarioRoutingModule);



/***/ }),

/***/ 47953:
/*!********************************************************!*\
  !*** ./src/app/pages/funcionario/funcionario.model.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreRegistroFuncionario": () => (/* binding */ PreRegistroFuncionario),
/* harmony export */   "PreRegistroFuncionarioInput": () => (/* binding */ PreRegistroFuncionarioInput)
/* harmony export */ });
class PreRegistroFuncionario {
    toInput() {
        var _a, _b;
        let input = new PreRegistroFuncionarioInput();
        input.id = this.id;
        input.nombreCompleto = this.nombreCompleto;
        input.apodo = this.apodo;
        input.documento = this.documento;
        input.telefonoPersonal = this.telefonoPersonal;
        input.telefonoEmergencia = this.telefonoEmergencia;
        input.nombreContactoEmergencia = this.nombreContactoEmergencia;
        input.email = this.email;
        input.ciudadId = (_a = this.ciudad) === null || _a === void 0 ? void 0 : _a.id;
        input.direccion = this.direccion;
        input.sucursalId = (_b = this.sucursal) === null || _b === void 0 ? void 0 : _b.id;
        input.fechaNacimiento = this.fechaNacimiento;
        input.fechaIngreso = this.fechaIngreso;
        input.habilidades = this.habilidades;
        input.registroConducir = this.registroConducir;
        input.nivelEducacion = this.nivelEducacion;
        input.observacion = this.observacion;
        return input;
    }
}
class PreRegistroFuncionarioInput {
}


/***/ }),

/***/ 15677:
/*!*********************************************************!*\
  !*** ./src/app/pages/funcionario/funcionario.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FuncionarioModule": () => (/* binding */ FuncionarioModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _pre_registro_funcionario_pre_registro_funcionario_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pre-registro-funcionario/pre-registro-funcionario.component */ 84570);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _funcionario_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./funcionario-routing.module */ 1897);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);







let FuncionarioModule = class FuncionarioModule {
};
FuncionarioModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_pre_registro_funcionario_pre_registro_funcionario_component__WEBPACK_IMPORTED_MODULE_0__.PreRegistroFuncionarioComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _funcionario_routing_module__WEBPACK_IMPORTED_MODULE_1__.FuncionarioRoutingModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
        ]
    })
], FuncionarioModule);



/***/ }),

/***/ 77574:
/*!**********************************************************!*\
  !*** ./src/app/pages/funcionario/funcionario.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FuncionarioService": () => (/* binding */ FuncionarioService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/cargando.service */ 68030);
/* harmony import */ var _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/notificacion.service */ 11818);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _graphql_deletePreRegistroFuncionario__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./graphql/deletePreRegistroFuncionario */ 32907);
/* harmony import */ var _graphql_preRegistroFuncionarioById__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/preRegistroFuncionarioById */ 23879);
/* harmony import */ var _graphql_preRegistroFuncionariosQuery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql/preRegistroFuncionariosQuery */ 77601);
/* harmony import */ var _graphql_savePreRegistroFuncionario__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./graphql/savePreRegistroFuncionario */ 62304);













let FuncionarioService = class FuncionarioService {
    constructor(genericCrud, getPreRegistroFuncionario, getPreRegistroFuncionarioes, savePreRegistroFuncionario, deletePreRegistroFuncionario, http, notificacionService, cargandoService) {
        this.genericCrud = genericCrud;
        this.getPreRegistroFuncionario = getPreRegistroFuncionario;
        this.getPreRegistroFuncionarioes = getPreRegistroFuncionarioes;
        this.savePreRegistroFuncionario = savePreRegistroFuncionario;
        this.deletePreRegistroFuncionario = deletePreRegistroFuncionario;
        this.http = http;
        this.notificacionService = notificacionService;
        this.cargandoService = cargandoService;
    }
    onGetPreRegistroFuncionario(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetById(this.getPreRegistroFuncionario, id);
        });
    }
    onGetPreRegistroFuncionarioes(sucursalId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onGetById(this.getPreRegistroFuncionarioes, sucursalId);
        });
    }
    onSavePreRegistroFuncionario(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open();
            console.log(input);
            let httpOptions = {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpHeaders({
                    Accept: "application/json",
                    "Content-Type": "application/json",
                }),
            };
            return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(obs => {
                this.http.post(`http://${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.serverAdress.serverIp}:${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.serverAdress.serverPort}/config/pre-registro`, input, httpOptions).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe(res => {
                    this.cargandoService.close(loading);
                    if ((res === null || res === void 0 ? void 0 : res.id) != null) {
                        obs.next(true);
                        this.notificacionService.openGuardadoConExito();
                    }
                    else {
                        obs.next(false);
                    }
                });
            });
        });
    }
    onDeletePreRegistroFuncionario(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrud.onDelete(this.deletePreRegistroFuncionario, id);
        });
    }
};
FuncionarioService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_2__.GenericCrudService },
    { type: _graphql_preRegistroFuncionarioById__WEBPACK_IMPORTED_MODULE_5__.PreRegistroFuncionarioByIdGQL },
    { type: _graphql_preRegistroFuncionariosQuery__WEBPACK_IMPORTED_MODULE_6__.PreRegistroFuncionarioesGQL },
    { type: _graphql_savePreRegistroFuncionario__WEBPACK_IMPORTED_MODULE_7__.SavePreRegistroFuncionarioGQL },
    { type: _graphql_deletePreRegistroFuncionario__WEBPACK_IMPORTED_MODULE_4__.DeletePreRegistroFuncionarioGQL },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClient },
    { type: _services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.NotificacionService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_0__.CargandoService }
];
FuncionarioService = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Injectable)({
        providedIn: 'root'
    })
], FuncionarioService);



/***/ }),

/***/ 32907:
/*!***************************************************************************!*\
  !*** ./src/app/pages/funcionario/graphql/deletePreRegistroFuncionario.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeletePreRegistroFuncionarioGQL": () => (/* binding */ DeletePreRegistroFuncionarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 2654);




let DeletePreRegistroFuncionarioGQL = class DeletePreRegistroFuncionarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deletePreRegistroFuncionarioQuery;
    }
};
DeletePreRegistroFuncionarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeletePreRegistroFuncionarioGQL);



/***/ }),

/***/ 2654:
/*!************************************************************!*\
  !*** ./src/app/pages/funcionario/graphql/graphql-query.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deletePreRegistroFuncionarioQuery": () => (/* binding */ deletePreRegistroFuncionarioQuery),
/* harmony export */   "preRegistroFuncionarioQuery": () => (/* binding */ preRegistroFuncionarioQuery),
/* harmony export */   "preRegistroFuncionariosQuery": () => (/* binding */ preRegistroFuncionariosQuery),
/* harmony export */   "preRegistroFuncionariosSearch": () => (/* binding */ preRegistroFuncionariosSearch),
/* harmony export */   "savePreRegistroFuncionario": () => (/* binding */ savePreRegistroFuncionario)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const preRegistroFuncionariosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
  data : preRegistroFuncionarios(id: $id){
    id
    nombreCompleto
    apodo
    documento
    telefonoPersonal
    telefonoEmergencia
    nombreContactoEmergencia
    email
    ciudad {
      id
      nombre
    }
    direccion
    sucursal {
      id
      nombre
    }
    fechaNacimiento
    fechaIngreso
    habilidades
    registroConducir
    nivelEducacion
    observacion
    creadoEn
  }
}`;
const preRegistroFuncionariosSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($texto: String){
    data : preRegistroFuncionariosSearch(texto: $texto){
      id
      nombreCompleto
      apodo
      documento
      telefonoPersonal
      telefonoEmergencia
      nombreContactoEmergencia
      email
      ciudad {
        id
        nombre
      }
      direccion
      sucursal {
        id
        nombre
      }
      fechaNacimiento
      fechaIngreso
      habilidades
      registroConducir
      nivelEducacion
      observacion
      creadoEn
    }
  }`;
const preRegistroFuncionarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `query($id: ID!){
    data : preRegistroFuncionario(id: $id){
      id
      nombreCompleto
      apodo
      documento
      telefonoPersonal
      telefonoEmergencia
      nombreContactoEmergencia
      email
      ciudad {
        id
        nombre
      }
      direccion
      sucursal {
        id
        nombre
      }
      fechaNacimiento
      fechaIngreso
      habilidades
      registroConducir
      nivelEducacion
      observacion
      creadoEn
    }
  }`;
const savePreRegistroFuncionario = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `mutation savePreRegistroFuncionario($entity:PreRegistroFuncionarioInput!){
      data: savePreRegistroFuncionario(preRegistroFuncionario:$entity){
        id
        nombreCompleto
        apodo
        documento
        telefonoPersonal
        telefonoEmergencia
        nombreContactoEmergencia
        email
        ciudad {
          id
          nombre
        }
        direccion
        sucursal {
          id
          nombre
        }
        fechaNacimiento
        fechaIngreso
        habilidades
        registroConducir
        nivelEducacion
        observacion
        creadoEn
      }
    }`;
const deletePreRegistroFuncionarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] ` mutation deletePreRegistroFuncionario($id: ID!){
      deletePreRegistroFuncionario(id: $id)
    }`;


/***/ }),

/***/ 23879:
/*!*************************************************************************!*\
  !*** ./src/app/pages/funcionario/graphql/preRegistroFuncionarioById.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreRegistroFuncionarioByIdGQL": () => (/* binding */ PreRegistroFuncionarioByIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 2654);




let PreRegistroFuncionarioByIdGQL = class PreRegistroFuncionarioByIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.preRegistroFuncionarioQuery;
    }
};
PreRegistroFuncionarioByIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], PreRegistroFuncionarioByIdGQL);



/***/ }),

/***/ 77601:
/*!***************************************************************************!*\
  !*** ./src/app/pages/funcionario/graphql/preRegistroFuncionariosQuery.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreRegistroFuncionarioesGQL": () => (/* binding */ PreRegistroFuncionarioesGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 2654);




let PreRegistroFuncionarioesGQL = class PreRegistroFuncionarioesGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.preRegistroFuncionariosQuery;
    }
};
PreRegistroFuncionarioesGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], PreRegistroFuncionarioesGQL);



/***/ }),

/***/ 62304:
/*!*************************************************************************!*\
  !*** ./src/app/pages/funcionario/graphql/savePreRegistroFuncionario.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SavePreRegistroFuncionarioGQL": () => (/* binding */ SavePreRegistroFuncionarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 2654);




let SavePreRegistroFuncionarioGQL = class SavePreRegistroFuncionarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.savePreRegistroFuncionario;
    }
};
SavePreRegistroFuncionarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SavePreRegistroFuncionarioGQL);



/***/ }),

/***/ 84570:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/funcionario/pre-registro-funcionario/pre-registro-funcionario.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreRegistroFuncionarioComponent": () => (/* binding */ PreRegistroFuncionarioComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _pre_registro_funcionario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pre-registro-funcionario.component.html?ngResource */ 73118);
/* harmony import */ var _pre_registro_funcionario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pre-registro-funcionario.component.scss?ngResource */ 33713);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/cargando.service */ 68030);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _funcionario_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../funcionario.service */ 77574);
/* harmony import */ var _funcionario_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../funcionario.model */ 47953);
/* harmony import */ var _dialog_login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../../dialog/login/login.component */ 20260);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/domains/empresarial/sucursal/sucursal.service */ 17976);













let PreRegistroFuncionarioComponent = class PreRegistroFuncionarioComponent {
    constructor(modalService, funcionarioService, cargandoService, platform, sucursalService) {
        this.modalService = modalService;
        this.funcionarioService = funcionarioService;
        this.cargandoService = cargandoService;
        this.platform = platform;
        this.sucursalService = sucursalService;
        this.nombreCompleto = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.apodo = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl();
        this.documento = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.telefonoPersonal = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.telefonoEmergencia = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.nombreContactoEmergencia = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl();
        this.ciudad = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.direccion = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.sucursal = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.fechaNacimiento = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.fechaIngreso = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl();
        this.habilidades = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
        this.registroConducir = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(false);
        this.nivelEducacion = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl();
        this.observacion = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl();
        this.generoControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl();
        this.habilidadesInformaticas = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl([]);
        this.habilidadesGenerales = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl([]);
        sucursalService.getSucursalesAdmin()
            .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_9__.untilDestroyed)(this))
            .subscribe(res => {
            if (res != null) {
                this.sucursalList = res['sucursalList'];
                if (this.sucursalList != null) {
                    this.sucursalList = this.sucursalList.filter(s => s.id != 0).sort((a, b) => {
                        if (a.id > b.id) {
                            return 1;
                        }
                        else {
                            return -1;
                        }
                    });
                }
            }
        });
    }
    ngOnInit() {
        this.formGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroup({
            'nombreControl': this.nombreCompleto,
            'apodo': this.apodo,
            'documento': this.documento,
            'telefonoPersonal': this.telefonoPersonal,
            'telefonoEmergencia': this.telefonoEmergencia,
            'nombreContactoEmergencia': this.nombreContactoEmergencia,
            'email': this.email,
            'ciudad': this.ciudad,
            'direccion': this.direccion,
            'sucursal': this.sucursal,
            'fechaNacimiento': this.fechaNacimiento,
            'fechaIngreso': this.fechaIngreso,
            'habilidades': this.habilidades,
            'registroConducir': this.registroConducir,
            'nivelEducacion': this.nivelEducacion,
            'observacion': this.observacion,
            'generoControl': this.generoControl
        });
    }
    onCancel() {
        this.modalService.closeModal(null);
        this.modalService.openModal(_dialog_login_login_component__WEBPACK_IMPORTED_MODULE_5__.LoginComponent);
    }
    onAceptar() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            if (this.habilidadesInformaticas.value != null) {
                this.habilidades.setValue([...this.habilidadesInformaticas.value]);
            }
            if (this.habilidadesGenerales.value != null) {
                this.habilidades.setValue([...this.habilidadesGenerales.value]);
            }
            let entity = new _funcionario_model__WEBPACK_IMPORTED_MODULE_4__.PreRegistroFuncionario;
            entity.apodo = this.apodo.value;
            entity.ciudad = this.ciudad.value;
            entity.direccion = this.direccion.value;
            entity.documento = this.documento.value;
            entity.email = this.email.value;
            entity.fechaIngreso = new Date(this.fechaIngreso.value);
            entity.fechaNacimiento = new Date(this.fechaNacimiento.value);
            entity.habilidades = this.habilidades.value.toString();
            entity.nivelEducacion = this.nivelEducacion.value;
            entity.nombreCompleto = this.nombreCompleto.value;
            entity.nombreContactoEmergencia = this.nombreContactoEmergencia.value;
            entity.observacion = this.observacion.value;
            entity.registroConducir = this.registroConducir.value;
            entity.sucursal = this.sucursal.value;
            entity.telefonoEmergencia = this.telefonoEmergencia.value;
            entity.telefonoPersonal = this.telefonoPersonal.value;
            (yield this.funcionarioService.onSavePreRegistroFuncionario(entity))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_9__.untilDestroyed)(this))
                .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                if (res != null) {
                    this.modalService.closeModal(null);
                    let loading = yield this.cargandoService.open();
                    setTimeout(() => {
                        this.cargandoService.close(loading);
                        this.modalService.openModal(_dialog_login_login_component__WEBPACK_IMPORTED_MODULE_5__.LoginComponent);
                    }, 1000);
                }
            }));
        });
    }
    ionViewDidEnter() {
        this.subscription = this.platform.backButton.subscribeWithPriority(9999, () => {
        });
    }
    ionViewWillLeave() {
        this.subscription.unsubscribe();
    }
};
PreRegistroFuncionarioComponent.ctorParameters = () => [
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_6__.ModalService },
    { type: _funcionario_service__WEBPACK_IMPORTED_MODULE_3__.FuncionarioService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_2__.CargandoService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform },
    { type: src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_7__.SucursalService }
];
PreRegistroFuncionarioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_9__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-pre-registro-funcionario',
        template: _pre_registro_funcionario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_pre_registro_funcionario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PreRegistroFuncionarioComponent);



/***/ }),

/***/ 79328:
/*!***************************************************!*\
  !*** ./src/app/pages/home/home/home.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.component.html?ngResource */ 98132);
/* harmony import */ var _home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.component.scss?ngResource */ 85236);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let HomeComponent = class HomeComponent {
    constructor() { }
    ngOnInit() { }
};
HomeComponent.ctorParameters = () => [];
HomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-home',
        template: _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomeComponent);



/***/ }),

/***/ 91763:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/inventario/edit-inventario-item-dialog/edit-inventario-item-dialog.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditInventarioItemDialogComponent": () => (/* binding */ EditInventarioItemDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_inventario_item_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-inventario-item-dialog.component.html?ngResource */ 9301);
/* harmony import */ var _edit_inventario_item_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-inventario-item-dialog.component.scss?ngResource */ 22917);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/cargando.service */ 68030);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var _inventario_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../inventario.model */ 98046);








let EditInventarioItemDialogComponent = class EditInventarioItemDialogComponent {
    constructor(modalService, cargandoService) {
        this.modalService = modalService;
        this.cargandoService = cargandoService;
        this.isPesable = false;
        this.estadosList = Object.values(_inventario_model__WEBPACK_IMPORTED_MODULE_4__.InventarioProductoEstado);
        this.cantidadControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.min(0)]);
        this.vencimientoControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]);
        this.estadoControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(_inventario_model__WEBPACK_IMPORTED_MODULE_4__.InventarioProductoEstado.BUENO);
        this.formGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
            cantidad: this.cantidadControl,
            vencimiento: this.vencimientoControl,
            estado: this.estadoControl
        });
    }
    ngOnInit() {
        var _a, _b, _c, _d;
        if (((_b = (_a = this.data) === null || _a === void 0 ? void 0 : _a.inventarioProductoItem) === null || _b === void 0 ? void 0 : _b.id) != null) {
            this.cargarDatos((_c = this.data) === null || _c === void 0 ? void 0 : _c.inventarioProductoItem);
        }
        else if (((_d = this.data) === null || _d === void 0 ? void 0 : _d.peso) != null) {
            this.cantidadControl.setValue(this.data.peso);
        }
    }
    cargarDatos(invProItem) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open();
            setTimeout(() => {
                this.selectedInventarioProductoItem = new _inventario_model__WEBPACK_IMPORTED_MODULE_4__.InventarioProductoItem;
                Object.assign(this.selectedInventarioProductoItem, invProItem);
                this.isPesable = this.selectedInventarioProductoItem.presentacion.producto.balanza;
                this.selectedInventarioProductoItem.inventarioProducto = this.data.inventarioProducto;
                this.cantidadControl.setValue(invProItem === null || invProItem === void 0 ? void 0 : invProItem.cantidad);
                this.vencimientoControl.setValue(invProItem === null || invProItem === void 0 ? void 0 : invProItem.vencimiento);
                this.estadoControl.setValue(invProItem === null || invProItem === void 0 ? void 0 : invProItem.estado);
                this.cargandoService.close(loading);
            }, 1000);
        });
    }
    onAceptar() {
        if (this.selectedInventarioProductoItem == null) {
            this.selectedInventarioProductoItem = new _inventario_model__WEBPACK_IMPORTED_MODULE_4__.InventarioProductoItem();
            this.selectedInventarioProductoItem.cantidad = this.cantidadControl.value;
            this.selectedInventarioProductoItem.vencimiento = this.vencimientoControl.value;
            this.selectedInventarioProductoItem.inventarioProducto = this.data.inventarioProducto;
            this.selectedInventarioProductoItem.presentacion = this.data.presentacion;
            this.selectedInventarioProductoItem.estado = this.estadoControl.value;
            this.selectedInventarioProductoItem.zona = this.data.inventarioProducto.zona;
        }
        else {
            this.selectedInventarioProductoItem.cantidad = this.cantidadControl.value;
            this.selectedInventarioProductoItem.vencimiento = this.vencimientoControl.value;
            this.selectedInventarioProductoItem.estado = this.estadoControl.value;
        }
        console.log(this.selectedInventarioProductoItem.toInput());
        this.modalService.closeModal(this.selectedInventarioProductoItem.toInput());
    }
    onCancel() {
        this.modalService.closeModal(null);
    }
};
EditInventarioItemDialogComponent.ctorParameters = () => [
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_3__.ModalService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_2__.CargandoService }
];
EditInventarioItemDialogComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input }]
};
EditInventarioItemDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-edit-inventario-item-dialog',
        template: _edit_inventario_item_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edit_inventario_item_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditInventarioItemDialogComponent);



/***/ }),

/***/ 47936:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/inventario/edit-inventario/edit-inventario.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditInventarioComponent": () => (/* binding */ EditInventarioComponent),
/* harmony export */   "InventarioData": () => (/* binding */ InventarioData)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-inventario.component.html?ngResource */ 50633);
/* harmony import */ var _edit_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-inventario.component.scss?ngResource */ 65385);
/* harmony import */ var _domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../domains/enums/tipo-entidad.enum */ 61246);
/* harmony import */ var _generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../generic/utils/qrUtils */ 83503);
/* harmony import */ var _components_qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../components/qr-generator/qr-generator.component */ 45713);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var _edit_inventario_item_dialog_edit_inventario_item_dialog_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../edit-inventario-item-dialog/edit-inventario-item-dialog.component */ 91763);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../../../services/pop-over.service */ 21690);
/* harmony import */ var _producto_search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./../../producto/search-producto-dialog/search-producto-dialog.component */ 38612);
/* harmony import */ var _select_zona_dialog_select_zona_dialog_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./../select-zona-dialog/select-zona-dialog.component */ 11986);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/services/menu-action.service */ 47257);
/* harmony import */ var _inventario_model__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./../inventario.model */ 98046);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./../../../services/cargando.service */ 68030);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _inventario_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./../inventario.service */ 82769);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_domains_sector_sector_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/domains/sector/sector.service */ 57701);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _producto_producto_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../producto/producto.service */ 73112);


























class InventarioData {
}
var OpcionesMostrar;
(function (OpcionesMostrar) {
    OpcionesMostrar["TODOS"] = "TODOS";
    OpcionesMostrar["MIOS"] = "MIOS";
})(OpcionesMostrar || (OpcionesMostrar = {}));
let EditInventarioComponent = class EditInventarioComponent {
    constructor(route, inventarioService, cargandoService, sectorSerice, menuAction, modalService, _location, popoverService, dialogoService, menuActionService, mainService, notificacionService, router, productoService) {
        this.route = route;
        this.inventarioService = inventarioService;
        this.cargandoService = cargandoService;
        this.sectorSerice = sectorSerice;
        this.menuAction = menuAction;
        this.modalService = modalService;
        this._location = _location;
        this.popoverService = popoverService;
        this.dialogoService = dialogoService;
        this.menuActionService = menuActionService;
        this.mainService = mainService;
        this.notificacionService = notificacionService;
        this.router = router;
        this.productoService = productoService;
        this.sectorList = [];
        this.inventarioDataList = [];
        this.mostrarControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormControl(OpcionesMostrar.MIOS);
        this.opcionesMostrarList = Object.values(OpcionesMostrar);
        this.isAddZona = false;
    }
    ngOnInit() {
        this.selectedResponsable = this.mainService.usuarioActual;
        this.route.paramMap
            .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
            .subscribe(res => {
            this.inventarioId = res.get('id');
            if (this.inventarioId != null) {
                this.buscarInventario(this.inventarioId);
            }
        });
    }
    buscarInventario(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.inventarioService.onGetInventario(id)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.selectedInventario = res;
                    this.onGetSectores(this.selectedInventario.sucursal.id);
                    this.ordenarZonas();
                }
            });
        });
    }
    onGetSectores(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.sectorSerice.onGetSectores(id))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                .subscribe(res => {
                console.log(res);
                this.sectorList = res;
            });
        });
    }
    onAddZona() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            let arrAux = this.sectorList;
            let filteredZonas = [];
            (yield this.inventarioService.onGetInventario(this.selectedInventario.id))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null)
                    this.selectedInventario = res;
                this.selectedInventario.inventarioProductoList.forEach(ip => {
                    filteredZonas.push(ip === null || ip === void 0 ? void 0 : ip.zona);
                });
                arrAux.forEach(s => {
                    s.zonaList = s.zonaList.filter(z => filteredZonas.find(fz => fz.id == z.id) == null);
                });
                this.modalService.openModal(_select_zona_dialog_select_zona_dialog_component__WEBPACK_IMPORTED_MODULE_11__.SelectZonaDialogComponent, arrAux).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                    if (res.data != null) {
                        let selectedZona = res.data;
                        let inventarioProducto = new _inventario_model__WEBPACK_IMPORTED_MODULE_14__.InventarioProducto();
                        inventarioProducto.concluido = false;
                        inventarioProducto.inventario = this.selectedInventario;
                        inventarioProducto.zona = selectedZona;
                        (yield this.inventarioService.onSaveInventarioProducto(inventarioProducto.toInput()))
                            .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                            .subscribe(res => {
                            if (res != null) {
                                this.buscarInventario(this.inventarioId);
                            }
                        });
                    }
                }));
            });
        });
    }
    onFinalizarZona(invPro, i) {
        var _a;
        let aux = new _inventario_model__WEBPACK_IMPORTED_MODULE_14__.InventarioProducto;
        invPro = Object.assign(aux, invPro);
        this.dialogoService.open('Atención', `Usted esta finalizando la zona ${(_a = invPro === null || invPro === void 0 ? void 0 : invPro.zona) === null || _a === void 0 ? void 0 : _a.descripcion}. Desea continuar?`).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            if (res.role == 'aceptar') {
                invPro.inventario = this.selectedInventario;
                invPro.concluido = true;
                (yield this.inventarioService.onSaveInventarioProducto(invPro.toInput()))
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                    .subscribe(res2 => {
                    this.selectedInventario.inventarioProductoList[i] = invPro;
                    this.ordenarZonas();
                });
            }
        }));
    }
    onReabrirZona(invPro, i) {
        var _a;
        let aux = new _inventario_model__WEBPACK_IMPORTED_MODULE_14__.InventarioProducto;
        invPro = Object.assign(aux, invPro);
        if (this.verificarAbiertos()) {
            this.dialogoService.open('Atención', `Usted esta reabriendo la zona ${(_a = invPro === null || invPro === void 0 ? void 0 : invPro.zona) === null || _a === void 0 ? void 0 : _a.descripcion}. Desea continuar?`).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                if (res.role == 'aceptar') {
                    invPro.inventario = this.selectedInventario;
                    invPro.concluido = false;
                    (yield this.inventarioService.onSaveInventarioProducto(invPro.toInput()))
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                        .subscribe(res2 => {
                        this.selectedInventario.inventarioProductoList[i] = invPro;
                        this.ordenarZonas();
                    });
                }
            }));
        }
        else {
            this.notificacionService.open('Ya tenes una zona abierta. Despues de concluirla podrás iniciar el inventario de otra', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__.TipoNotificacion.WARN, 3);
        }
    }
    verificarAbiertos() {
        return this.selectedInventario.inventarioProductoList.find(e => e.concluido == false) == null;
    }
    ordenarZonas() {
        this.selectedInventario.inventarioProductoList = this.selectedInventario.inventarioProductoList.sort((a, b) => {
            if (a.concluido == true && b.concluido != true) {
                return 1;
            }
            else {
                return -1;
            }
        });
    }
    onAddProducto(invPro, i) {
        console.log(this.selectedInventario);
        let data = { sucursalId: +this.selectedInventario.sucursal.id };
        this.modalService.openModal(_producto_search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_10__.SearchProductoDialogComponent, { data }).then(res => {
            if (res === null || res === void 0 ? void 0 : res.data) {
                let selectedPresentacion = res.data['presentacion'];
                let selectedProducto = res.data['producto'];
                let data = {
                    inventarioProducto: invPro,
                    producto: selectedProducto,
                    presentacion: selectedPresentacion,
                    inventarioProductoItem: null,
                    peso: res.data['peso']
                };
                this.modalService.openModal(_edit_inventario_item_dialog_edit_inventario_item_dialog_component__WEBPACK_IMPORTED_MODULE_8__.EditInventarioItemDialogComponent, data).then((res2) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                    var _a;
                    if (res2.data != null) {
                        let invProItemAux = res2.data;
                        (yield this.productoService.onGetStockPorSucursal((_a = data.producto) === null || _a === void 0 ? void 0 : _a.id, this.selectedInventario.sucursal.id))
                            .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                            .subscribe(stockResponse => {
                            if (stockResponse != null) {
                                invProItemAux.cantidadFisica = stockResponse;
                                console.log(stockResponse);
                            }
                        });
                        (yield this.inventarioService.onSaveInventarioProductoItem(invProItemAux))
                            .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                            .subscribe(res3 => {
                            if (res3 != null) {
                                console.log(res3);
                                this.selectedInventario.inventarioProductoList.forEach(i => {
                                    if (i.inventarioProductoItemList == null)
                                        i.inventarioProductoItemList = [];
                                    if (i.inventarioProductoItemList.length > 4)
                                        i.inventarioProductoItemList.pop();
                                    i.inventarioProductoItemList.unshift(res3);
                                });
                            }
                        });
                    }
                }));
            }
        });
    }
    onDeleteProducto(invProItem, index, invPro) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.inventarioService.onDeleteInventarioProductoItem(invProItem.id, invProItem.presentacion.producto.descripcion)).subscribe(res => {
                if (res) {
                    this.selectedInventario.inventarioProductoList.forEach((i) => {
                        this.selectedInventario.inventarioProductoList.forEach(i => {
                            if (i.inventarioProductoItemList == null)
                                i.inventarioProductoItemList = [];
                            if (i.id == invPro.id)
                                i.inventarioProductoItemList.splice(index, 1);
                        });
                    });
                }
            });
        });
    }
    onEditProducto(invProItem, index, invPro) {
        var _a;
        let selectedPresentacion = invProItem === null || invProItem === void 0 ? void 0 : invProItem.presentacion;
        let selectedProducto = (_a = invProItem === null || invProItem === void 0 ? void 0 : invProItem.presentacion) === null || _a === void 0 ? void 0 : _a.producto;
        let data = {
            inventarioProducto: invPro,
            producto: selectedProducto,
            presentacion: selectedPresentacion,
            inventarioProductoItem: invProItem
        };
        this.modalService.openModal(_edit_inventario_item_dialog_edit_inventario_item_dialog_component__WEBPACK_IMPORTED_MODULE_8__.EditInventarioItemDialogComponent, data).then((res2) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            if (res2.data != null) {
                (yield this.inventarioService.onSaveInventarioProductoItem(res2.data))
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this))
                    .subscribe(res3 => {
                    if (res3 != null) {
                        this.selectedInventario.inventarioProductoList.forEach(i => {
                            if (i.inventarioProductoItemList == null)
                                i.inventarioProductoItemList = [];
                            if (i.id == invPro.id)
                                i.inventarioProductoItemList[index] = res3;
                        });
                    }
                });
            }
        }));
    }
    openFilterMenu() {
        this.menuActionService.presentActionSheet([
            { texto: 'Todos', role: OpcionesMostrar.TODOS },
            { texto: 'Mios', role: OpcionesMostrar.MIOS },
        ]).then(res => {
            let role = res.role;
            if (role != null)
                this.mostrarControl.setValue(role);
        });
    }
    onRefresh() {
        this.ngOnInit();
    }
    onBack() {
        this._location.back();
    }
    onMenuClick() {
        let menu = [
            { texto: 'Actualizar datos', role: 'actualizar' },
            { texto: 'Resumen', role: 'resumen' },
            { texto: 'Compartir', role: 'compartir' }
        ];
        this.menuActionService.presentActionSheet(menu).then(res => {
            var _a, _b, _c;
            let role = res.role;
            if (role == 'actualizar') {
                this.ngOnInit();
            }
            else if (role == 'resumen') {
                this.router.navigate(['finalizar'], { relativeTo: this.route });
            }
            else if (role == 'compartir') {
                let codigo = new _generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_3__.QrData;
                codigo.sucursalId = (_b = (_a = this.selectedInventario) === null || _a === void 0 ? void 0 : _a.sucursal) === null || _b === void 0 ? void 0 : _b.id;
                codigo.tipoEntidad = _domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_2__.TipoEntidad.INVENTARIO;
                codigo.idCentral = (_c = this.selectedInventario) === null || _c === void 0 ? void 0 : _c.id;
                this.popoverService.open(_components_qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_4__.QrGeneratorComponent, (0,_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_3__.codificarQr)(codigo), _services_pop_over_service__WEBPACK_IMPORTED_MODULE_9__.PopoverSize.XS);
            }
        });
    }
    onGetProductosItemList(invPro, index) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            if (invPro.inventarioProductoItemList == null) {
                (yield this.inventarioService.onGetInventarioProItem(invPro.id, 0)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this)).subscribe(res => {
                    if (res != null) {
                        this.selectedInventario.inventarioProductoList[index].inventarioProductoItemList = res;
                    }
                });
            }
        });
    }
    onCargarMas(invPro, index) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            let page = Math.floor((invPro.inventarioProductoItemList.length - 1) / 5) + 1;
            (yield this.inventarioService.onGetInventarioProItem(invPro.id, page)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.untilDestroyed)(this)).subscribe(res => {
                console.log(res);
                if (res != null) {
                    this.selectedInventario.inventarioProductoList[index].inventarioProductoItemList = this.selectedInventario.inventarioProductoList[index].inventarioProductoItemList.concat(res);
                }
            });
        });
    }
    onCargarMenos(invPro, index) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            let length = this.selectedInventario.inventarioProductoList[index].inventarioProductoItemList.length;
            let sobra = length - 4;
            this.selectedInventario.inventarioProductoList[index].inventarioProductoItemList.splice(length - sobra, sobra - 1);
        });
    }
};
EditInventarioComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_22__.ActivatedRoute },
    { type: _inventario_service__WEBPACK_IMPORTED_MODULE_16__.InventarioService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_15__.CargandoService },
    { type: src_app_domains_sector_sector_service__WEBPACK_IMPORTED_MODULE_17__.SectorService },
    { type: src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_13__.MenuActionService },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_12__.ModalService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_23__.Location },
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_9__.PopOverService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_7__.DialogoService },
    { type: src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_13__.MenuActionService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_6__.MainService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__.NotificacionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_22__.Router },
    { type: _producto_producto_service__WEBPACK_IMPORTED_MODULE_18__.ProductoService }
];
EditInventarioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_20__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.Component)({
        selector: 'app-edit-inventario',
        template: _edit_inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edit_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditInventarioComponent);



/***/ }),

/***/ 86159:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/inventario/finalizar-inventario-resumen/finalizar-inventario-resumen.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FinalizarInventarioResumenComponent": () => (/* binding */ FinalizarInventarioResumenComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _finalizar_inventario_resumen_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./finalizar-inventario-resumen.component.html?ngResource */ 14479);
/* harmony import */ var _finalizar_inventario_resumen_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./finalizar-inventario-resumen.component.scss?ngResource */ 6653);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _inventario_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../inventario.service */ 82769);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inventario_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../inventario.model */ 98046);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var chart_js_auto__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! chart.js/auto */ 93566);
/* harmony import */ var src_app_domains_sector_sector_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/domains/sector/sector.service */ 57701);
/* harmony import */ var src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/generic/utils/dateUtils */ 8535);
/* harmony import */ var src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/cargando.service */ 68030);

















let FinalizarInventarioResumenComponent = class FinalizarInventarioResumenComponent {
    constructor(route, inventarioService, notificacionService, router, _location, sectorService, mainService, dialogoService, cargandoService) {
        this.route = route;
        this.inventarioService = inventarioService;
        this.notificacionService = notificacionService;
        this.router = router;
        this._location = _location;
        this.sectorService = sectorService;
        this.mainService = mainService;
        this.dialogoService = dialogoService;
        this.cargandoService = cargandoService;
        this.sectorList = [];
        this.cantidadZonas = 0;
        this.total = 0;
        this.terminadas = 0;
        this.colaboradores = [];
    }
    ngOnInit() {
        this.route.paramMap.subscribe(res => {
            this.inventarioId = res.get('id');
            if (this.inventarioId != null) {
                this.cargarDatos(this.inventarioId);
            }
            else {
                this.notificacionService.openItemNoEncontrado();
                this.onBack();
            }
        }).unsubscribe();
    }
    cargarDatos(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.inventarioService.onGetInventario(this.inventarioId))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_12__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.selectedInventario = res;
                    this.onGetSectores(this.selectedInventario.sucursal.id);
                    this.selectedInventario.inventarioProductoList.forEach(ip => {
                        if (this.colaboradores.findIndex(u => u.id == ip.usuario.id) == -1) {
                            this.colaboradores.push(ip.usuario);
                        }
                    });
                    if (this.selectedInventario.fechaFin != null) {
                        this.duracion = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_9__.convertMsToTime)(new Date(new Date(this.selectedInventario.fechaFin).getTime() - new Date(this.selectedInventario.fechaInicio).getTime()));
                    }
                    else {
                        this.duracion = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_9__.convertMsToTime)(new Date(new Date().getTime() - new Date(this.selectedInventario.fechaInicio).getTime()));
                    }
                }
            });
        });
    }
    onGetSectores(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.sectorService.onGetSectores(id))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_12__.untilDestroyed)(this))
                .subscribe(res => {
                this.sectorList = res;
                this.sectorList.forEach(s => {
                    this.cantidadZonas = this.cantidadZonas + s.zonaList.length;
                });
                this.doughnutChartMethod();
            });
        });
    }
    doughnutChartMethod() {
        this.total = this.cantidadZonas;
        this.terminadas = this.selectedInventario.inventarioProductoList.filter(ip => ip.concluido == true).length;
        this.doughnutChart = new chart_js_auto__WEBPACK_IMPORTED_MODULE_7__["default"](this.doughnutCanvas.nativeElement, {
            type: 'doughnut',
            data: {
                labels: ['Zonas inventariadas', 'Zonas faltantes'],
                datasets: [{
                        label: '# of Votes',
                        data: [this.terminadas, this.total - this.terminadas],
                        backgroundColor: [
                            '#43a047',
                            '#f57c00'
                        ]
                    }]
            }
        });
    }
    onBack() {
        this._location.back();
    }
    onFinalizar() {
        let texto = 'Realmente desea finalizar este inventario?. Se procedera a ajustar el stock';
        if (this.terminadas > 0)
            texto = `Aún quedan zonas sin inventariar. Realmente desea finalizar este inventario?. Se procedera a ajustar el stock`;
        this.dialogoService.open('Atención!', texto).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            var _a;
            if (res.role == 'aceptar') {
                let loading = yield this.cargandoService.open('Finalizando...');
                this.inventarioService.onFinalizarInventario((_a = this.selectedInventario) === null || _a === void 0 ? void 0 : _a.id)
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_12__.untilDestroyed)(this)) //cuando recibe respuesta se cierra observable
                    .subscribe(respuesta => {
                    this.cargandoService.close(loading);
                    if (respuesta != null)
                        this.selectedInventario = respuesta;
                });
            }
        }));
    }
    onCancelar() {
        let texto = 'Realmente desea cancelar este inventario?. Se procedera a reajustar el stock. Esta acción no se puede deshacer.';
        this.dialogoService.open('Atención!', texto).then(res => {
            var _a;
            if (res.role == 'aceptar') {
                this.inventarioService.onCancelarInventario((_a = this.selectedInventario) === null || _a === void 0 ? void 0 : _a.id)
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_12__.untilDestroyed)(this))
                    .subscribe(res => {
                    if (res) {
                        this.selectedInventario.estado = _inventario_model__WEBPACK_IMPORTED_MODULE_6__.InventarioEstado.CANCELADO;
                    }
                });
            }
        });
    }
};
FinalizarInventarioResumenComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute },
    { type: _inventario_service__WEBPACK_IMPORTED_MODULE_5__.InventarioService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__.NotificacionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_14__.Location },
    { type: src_app_domains_sector_sector_service__WEBPACK_IMPORTED_MODULE_8__.SectorService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__.MainService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService },
    { type: src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_10__.CargandoService }
];
FinalizarInventarioResumenComponent.propDecorators = {
    doughnutCanvas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild, args: ['doughnutCanvas', { static: true },] }]
};
FinalizarInventarioResumenComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_12__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: 'app-finalizar-inventario-resumen',
        template: _finalizar_inventario_resumen_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_finalizar_inventario_resumen_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FinalizarInventarioResumenComponent);

// this.menuActionService.presentActionSheet(menu).then(res => {
//   let role = res.role;
//   if (role == 'actualizar') {
//     this.ngOnInit()
//   } else if (role == 'finalizar') {
//     let zonasAbiertas: string[] = [];
//     this.inventarioService.onGetInventario(this.selectedInventario.id)
//       .pipe(untilDestroyed(this))
//       .subscribe(res2 => {
//         res2.inventarioProductoList.forEach(ip => {
//           if (ip.concluido == false) {
//             zonasAbiertas.push(ip?.zona?.descripcion)
//           }
//         })
//         let texto = 'Realmente desea finalizar este inventario?. Verifica si todas las zonas fueron inventariadas';
//         if (zonasAbiertas.length == 0) {
//           this.dialogoService.open('Atención!!', texto, true).then(res => {
//             if (res.role == 'aceptar') {
//               this.router.navigate(['finalizar'], { relativeTo: this.route });
//             }
//           })
//         } else {
//           let zonas = '';
//           zonasAbiertas.forEach(z => {
//             zonas = zonas.concat(...z + ', ')
//           })
//           this.notificacionService.open('Las siguientes zonas estan abiertas: ' + zonas, TipoNotificacion.WARN, 3)
//         }
//       })
//   }
// })
// }


/***/ }),

/***/ 62755:
/*!*****************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/cancelar-inventario.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CancelarInventarioGQL": () => (/* binding */ CancelarInventarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);




let CancelarInventarioGQL = class CancelarInventarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.cancelarInventarioQuery;
    }
};
CancelarInventarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CancelarInventarioGQL);



/***/ }),

/***/ 89657:
/*!**************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/deleteInventario.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteInventarioGQL": () => (/* binding */ DeleteInventarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let DeleteInventarioGQL = class DeleteInventarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteInventarioQuery;
    }
};
DeleteInventarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteInventarioGQL);



/***/ }),

/***/ 87323:
/*!**********************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/deleteInventarioProducto.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteInventarioProductoGQL": () => (/* binding */ DeleteInventarioProductoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let DeleteInventarioProductoGQL = class DeleteInventarioProductoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteInventarioProductoQuery;
    }
};
DeleteInventarioProductoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteInventarioProductoGQL);



/***/ }),

/***/ 37636:
/*!**************************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/deleteInventarioProductoItem.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteInventarioProductoItemGQL": () => (/* binding */ DeleteInventarioProductoItemGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let DeleteInventarioProductoItemGQL = class DeleteInventarioProductoItemGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteInventarioProductoItemQuery;
    }
};
DeleteInventarioProductoItemGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteInventarioProductoItemGQL);



/***/ }),

/***/ 7884:
/*!******************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/finalizar-inventario.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FinalizarInventarioGQL": () => (/* binding */ FinalizarInventarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);




let FinalizarInventarioGQL = class FinalizarInventarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.finalizarInventarioQuery;
    }
};
FinalizarInventarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], FinalizarInventarioGQL);



/***/ }),

/***/ 77355:
/*!***********************************************************!*\
  !*** ./src/app/pages/inventario/graphql/getInventario.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetInventarioGQL": () => (/* binding */ GetInventarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let GetInventarioGQL = class GetInventarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.inventarioQuery;
    }
};
GetInventarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetInventarioGQL);



/***/ }),

/***/ 60542:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/getInventarioAbiertoPorSucursal.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetInventarioAbiertoPorSucursalGQL": () => (/* binding */ GetInventarioAbiertoPorSucursalGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let GetInventarioAbiertoPorSucursalGQL = class GetInventarioAbiertoPorSucursalGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.inverntarioAbiertoPorSucursalQuery;
    }
};
GetInventarioAbiertoPorSucursalGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetInventarioAbiertoPorSucursalGQL);



/***/ }),

/***/ 30023:
/*!*******************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/getInventarioPorFecha.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetInventarioPorFechaGQL": () => (/* binding */ GetInventarioPorFechaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _inventario_graphql_graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../inventario/graphql/graphql-query */ 95848);




let GetInventarioPorFechaGQL = class GetInventarioPorFechaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _inventario_graphql_graphql_query__WEBPACK_IMPORTED_MODULE_0__.inventarioPorFechaQuery;
    }
};
GetInventarioPorFechaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetInventarioPorFechaGQL);



/***/ }),

/***/ 83718:
/*!*********************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/getInventarioPorUsuario.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetInventarioPorUsuarioGQL": () => (/* binding */ GetInventarioPorUsuarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let GetInventarioPorUsuarioGQL = class GetInventarioPorUsuarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.inventarioPorUsuarioQuery;
    }
};
GetInventarioPorUsuarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetInventarioPorUsuarioGQL);



/***/ }),

/***/ 37031:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/getInventarioProductoItemPorInventarioProducto copy.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetInventarioItemPorInvetarioProductoGQL": () => (/* binding */ GetInventarioItemPorInvetarioProductoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let GetInventarioItemPorInvetarioProductoGQL = class GetInventarioItemPorInvetarioProductoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.inventarioProItemPorInventarioProQuery;
    }
};
GetInventarioItemPorInvetarioProductoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetInventarioItemPorInvetarioProductoGQL);



/***/ }),

/***/ 95848:
/*!***********************************************************!*\
  !*** ./src/app/pages/inventario/graphql/graphql-query.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cancelarInventarioQuery": () => (/* binding */ cancelarInventarioQuery),
/* harmony export */   "deleteInventarioProductoItemQuery": () => (/* binding */ deleteInventarioProductoItemQuery),
/* harmony export */   "deleteInventarioProductoQuery": () => (/* binding */ deleteInventarioProductoQuery),
/* harmony export */   "deleteInventarioQuery": () => (/* binding */ deleteInventarioQuery),
/* harmony export */   "finalizarInventarioQuery": () => (/* binding */ finalizarInventarioQuery),
/* harmony export */   "inventarioPorFechaQuery": () => (/* binding */ inventarioPorFechaQuery),
/* harmony export */   "inventarioPorUsuarioQuery": () => (/* binding */ inventarioPorUsuarioQuery),
/* harmony export */   "inventarioProItemPorInventarioProQuery": () => (/* binding */ inventarioProItemPorInventarioProQuery),
/* harmony export */   "inventarioQuery": () => (/* binding */ inventarioQuery),
/* harmony export */   "inventariosQuery": () => (/* binding */ inventariosQuery),
/* harmony export */   "inverntarioAbiertoPorSucursalQuery": () => (/* binding */ inverntarioAbiertoPorSucursalQuery),
/* harmony export */   "saveInventario": () => (/* binding */ saveInventario),
/* harmony export */   "saveInventarioProducto": () => (/* binding */ saveInventarioProducto),
/* harmony export */   "saveInventarioProductoItem": () => (/* binding */ saveInventarioProductoItem)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const inventariosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: inventarios {
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
          }
          cantidad
          vencimiento
          creadoEn
        }
      }
    }
  }
`;
const inventarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: inventario(id: $id) {
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        id
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        usuario {
          id
          persona {
            nombre
          }
        }
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
      }
    }
  }
`;
const inventarioProItemPorInventarioProQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $page: Int, $size: Int) {
    data: inventarioProductosItemPorInventarioProducto(id: $id, page: $page, size: $size) {
      id
      inventarioProducto {
        id
      }
      zona {
        id
      }
      presentacion {
        id
        cantidad
        producto {
          descripcion
          balanza
        }
      }
      cantidad
      cantidadFisica
      vencimiento
      estado
    }
  }
`;
const inventarioPorUsuarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: inventarioPorUsuario(id: $id) {
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
            producto {
              id
              descripcion
              balanza
              vencimiento
            }
          }
          estado
          cantidad
          vencimiento
          creadoEn
        }
      }
    }
  }
`;
const saveInventario = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveInventario($entity: InventarioInput!) {
    data: saveInventario(inventario: $entity) {
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
          }
          cantidad
          vencimiento
          creadoEn
        }
      }
    }
  }
`;
const deleteInventarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteInventario($id: ID!) {
    deleteInventario(id: $id)
  }
`;
const inventarioPorFechaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($inicio: String, $fin: String) {
    data: inventarioPorFecha(inicio: $inicio, fin: $fin) {
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
          }
          cantidad
          vencimiento
          creadoEn
        }
      }
    }
  }
`;
const saveInventarioProducto = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveInventarioProducto($entity: InventarioProductoInput!) {
    data: saveInventarioProducto(inventarioProducto: $entity) {
        id
        concluido
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        usuario {
          id
          persona {
            nombre
          }
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
          }
          cantidad
          vencimiento
          creadoEn
        }
    }
  }
`;
const deleteInventarioProductoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteInventarioProducto($id: ID!) {
    deleteInventarioProducto(id: $id)
  }
`;
const saveInventarioProductoItem = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveInventarioProductoItem($entity: InventarioProductoItemInput!) {
    data: saveInventarioProductoItem(inventarioProductoItem: $entity) {
      id
      estado
      zona {
        id
        sector {
          id
          descripcion
        }
        descripcion
      }
      presentacion {
        id
        cantidad
        imagenPrincipal
        producto {
          descripcion
        }
      }
      cantidad
      cantidadFisica
      vencimiento
      usuario {
        id
        persona {
          nombre
        }
      }
      creadoEn
    }
  }
`;
const deleteInventarioProductoItemQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteInventarioProductoItem($id: ID!) {
    deleteInventarioProductoItem(id: $id)
  }
`;
// finalizarInventario
const finalizarInventarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation finalizarInventario($id: ID!) {
    data: finalizarInventario(id: $id){
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        producto {
          id
          descripcion
          balanza
          vencimiento
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
          }
          cantidad
          vencimiento
          creadoEn
        }
      }
    }
  }
`;
// cancelarInventario
const cancelarInventarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation cancelarInventario($id: ID!) {
    cancelarInventario(id: $id)
  }
`;
const inverntarioAbiertoPorSucursalQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: inventarioAbiertoPorSucursal(sucId: $id) {
      id
      sucursal {
        id
        nombre
      }
      fechaInicio
      fechaFin
      abierto
      tipo
      estado
      usuario {
        persona {
          nombre
        }
      }
      observacion
      inventarioProductoList {
        id
        concluido
        producto {
          id
          descripcion
        }
        zona {
          id
          sector {
            id
            descripcion
          }
          descripcion
        }
        inventarioProductoItemList {
          id
          presentacion {
            id
            cantidad
            imagenPrincipal
          }
          cantidad
          vencimiento
          creadoEn
        }
      }
    }
  }
`;


/***/ }),

/***/ 32150:
/*!************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/saveInventario.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveInventarioGQL": () => (/* binding */ SaveInventarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let SaveInventarioGQL = class SaveInventarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveInventario;
    }
};
SaveInventarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveInventarioGQL);



/***/ }),

/***/ 92174:
/*!********************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/saveInventarioProducto.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveInventarioProductoGQL": () => (/* binding */ SaveInventarioProductoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let SaveInventarioProductoGQL = class SaveInventarioProductoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveInventarioProducto;
    }
};
SaveInventarioProductoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveInventarioProductoGQL);



/***/ }),

/***/ 19557:
/*!************************************************************************!*\
  !*** ./src/app/pages/inventario/graphql/saveInventarioProductoItem.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveInventarioProductoItemGQL": () => (/* binding */ SaveInventarioProductoItemGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 95848);




let SaveInventarioProductoItemGQL = class SaveInventarioProductoItemGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveInventarioProductoItem;
    }
};
SaveInventarioProductoItemGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveInventarioProductoItemGQL);



/***/ }),

/***/ 78000:
/*!***************************************************************!*\
  !*** ./src/app/pages/inventario/inventario-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InventarioRoutingModule": () => (/* binding */ InventarioRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _finalizar_inventario_resumen_finalizar_inventario_resumen_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./finalizar-inventario-resumen/finalizar-inventario-resumen.component */ 86159);
/* harmony import */ var _edit_inventario_edit_inventario_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-inventario/edit-inventario.component */ 47936);
/* harmony import */ var _list_inventario_list_inventario_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./list-inventario/list-inventario.component */ 6850);
/* harmony import */ var _inventario_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./inventario.component */ 50751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);







const routes = [
    {
        path: '',
        component: _inventario_component__WEBPACK_IMPORTED_MODULE_3__.InventarioComponent,
    },
    {
        path: 'list',
        component: _list_inventario_list_inventario_component__WEBPACK_IMPORTED_MODULE_2__.ListInventarioComponent,
    },
    {
        path: 'list/info/:id',
        component: _edit_inventario_edit_inventario_component__WEBPACK_IMPORTED_MODULE_1__.EditInventarioComponent
    },
    {
        path: 'list/info/:id/finalizar',
        component: _finalizar_inventario_resumen_finalizar_inventario_resumen_component__WEBPACK_IMPORTED_MODULE_0__.FinalizarInventarioResumenComponent
    }
];
let InventarioRoutingModule = class InventarioRoutingModule {
};
InventarioRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
    })
], InventarioRoutingModule);



/***/ }),

/***/ 50751:
/*!**********************************************************!*\
  !*** ./src/app/pages/inventario/inventario.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InventarioComponent": () => (/* binding */ InventarioComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inventario.component.html?ngResource */ 16475);
/* harmony import */ var _inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inventario.component.scss?ngResource */ 23640);
/* harmony import */ var _nuevo_inventario_nuevo_inventario_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./nuevo-inventario/nuevo-inventario.component */ 199);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/modal.service */ 71609);
/* harmony import */ var _generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../generic/utils/qrUtils */ 83503);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _services_dialogo_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../../services/dialogo.service */ 86124);
/* harmony import */ var _inventario_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./inventario.service */ 82769);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../../services/cargando.service */ 68030);
/* harmony import */ var _components_qr_scanner_dialog_scanner_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/qr-scanner-dialog/scanner.service */ 28602);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/domains/enums/tipo-entidad.enum */ 61246);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/domains/empresarial/sucursal/sucursal.service */ 17976);
/* harmony import */ var src_app_components_generic_list_dialog_generic_list_dialog_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/components/generic-list-dialog/generic-list-dialog.component */ 99529);



















let InventarioComponent = class InventarioComponent {
    constructor(scannerService, cargandoService, inventarioService, dialog, router, route, activatedRoute, barcodeScanner, notificacionService, modalService, mainService, sucursalService) {
        this.scannerService = scannerService;
        this.cargandoService = cargandoService;
        this.inventarioService = inventarioService;
        this.dialog = dialog;
        this.router = router;
        this.route = route;
        this.activatedRoute = activatedRoute;
        this.barcodeScanner = barcodeScanner;
        this.notificacionService = notificacionService;
        this.modalService = modalService;
        this.mainService = mainService;
        this.sucursalService = sucursalService;
        this.isWeb = false;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
        });
    }
    onScanQr() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open('Abriendo camara...');
            setTimeout(() => {
                this.cargandoService.close(loading);
            }, 1000);
            this.barcodeScanner.scan().then((barcodeData) => (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
                this.notificacionService.open('Escaneado con éxito!', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__.TipoNotificacion.SUCCESS, 1);
                let codigo = barcodeData.text;
                let qrData = (0,_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_4__.descodificarQr)(codigo);
                if (qrData.tipoEntidad == src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_11__.TipoEntidad.INVENTARIO && qrData.sucursalId != null && qrData.idCentral != null) {
                    (yield this.inventarioService.onGetInventario(qrData.idCentral))
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_16__.untilDestroyed)(this))
                        .subscribe((res) => {
                        var _a, _b;
                        if (res != null && res.sucursal.id == qrData.sucursalId && ((_a = res.usuario) === null || _a === void 0 ? void 0 : _a.id) == ((_b = this.mainService.usuarioActual) === null || _b === void 0 ? void 0 : _b.id)) {
                            this.dialog.open('Atención!!', `Desea abrir el inventario de la sucursal ${res.sucursal.nombre}`, true).then(res2 => {
                                if (res2.role == 'aceptar') {
                                    this.router.navigate(['list/info', res.id], { relativeTo: this.route });
                                }
                            });
                        }
                        else {
                            this.notificacionService.openItemNoEncontrado();
                        }
                    });
                }
                else {
                    this.notificacionService.openItemNoEncontrado();
                }
            })).catch(err => {
                this.notificacionService.openAlgoSalioMal();
            });
        });
    }
    onNuevoInventario() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.sucursalService.onGetAllSucursales()).subscribe((res) => {
                if (res.length > 0) {
                    let tableData = [
                        {
                            id: 'id',
                            nombre: 'Id',
                            width: 20
                        },
                        {
                            id: 'nombre',
                            nombre: 'Nombre',
                            width: 80
                        }
                    ];
                    let data = {
                        tableData: tableData,
                        titulo: 'Seleccionar sucursal',
                        search: true,
                        inicialData: res.filter(s => s.id != 0)
                    };
                    this.modalService.openModal(src_app_components_generic_list_dialog_generic_list_dialog_component__WEBPACK_IMPORTED_MODULE_14__.GenericListDialogComponent, data).then(res2 => {
                        if (res2 != null) {
                            console.log(res2);
                            this.modalService.openModal(_nuevo_inventario_nuevo_inventario_component__WEBPACK_IMPORTED_MODULE_2__.NuevoInventarioComponent, res2).then(res => {
                                var _a, _b;
                                if (((_b = (_a = res.data) === null || _a === void 0 ? void 0 : _a.inventario) === null || _b === void 0 ? void 0 : _b.id) != null) {
                                    this.router.navigate(['list/info', res.data.inventario.id], { relativeTo: this.route });
                                }
                                else {
                                }
                            });
                        }
                    });
                }
            });
        });
    }
};
InventarioComponent.ctorParameters = () => [
    { type: _components_qr_scanner_dialog_scanner_service__WEBPACK_IMPORTED_MODULE_10__.ScannerService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_9__.CargandoService },
    { type: _inventario_service__WEBPACK_IMPORTED_MODULE_8__.InventarioService },
    { type: _services_dialogo_service__WEBPACK_IMPORTED_MODULE_7__.DialogoService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute },
    { type: _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_6__.BarcodeScanner },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_5__.NotificacionService },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_3__.ModalService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_12__.MainService },
    { type: src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_13__.SucursalService }
];
InventarioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_16__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-inventario',
        template: _inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_6__.BarcodeScanner],
        styles: [_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], InventarioComponent);



/***/ }),

/***/ 98046:
/*!******************************************************!*\
  !*** ./src/app/pages/inventario/inventario.model.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Inventario": () => (/* binding */ Inventario),
/* harmony export */   "InventarioEstado": () => (/* binding */ InventarioEstado),
/* harmony export */   "InventarioInput": () => (/* binding */ InventarioInput),
/* harmony export */   "InventarioProducto": () => (/* binding */ InventarioProducto),
/* harmony export */   "InventarioProductoEstado": () => (/* binding */ InventarioProductoEstado),
/* harmony export */   "InventarioProductoInput": () => (/* binding */ InventarioProductoInput),
/* harmony export */   "InventarioProductoItem": () => (/* binding */ InventarioProductoItem),
/* harmony export */   "InventarioProductoItemInput": () => (/* binding */ InventarioProductoItemInput),
/* harmony export */   "TipoInventario": () => (/* binding */ TipoInventario)
/* harmony export */ });
/* harmony import */ var src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/utils/dateUtils */ 8535);

class Inventario {
    constructor() {
        this.inventarioProductoList = [];
    }
    toInput() {
        var _a, _b;
        let input = new InventarioInput;
        input.id = this.id;
        input.sucursalId = (_a = this.sucursal) === null || _a === void 0 ? void 0 : _a.id;
        input.fechaInicio = this.fechaInicio;
        input.fechaFin = this.fechaFin;
        input.abierto = this.abierto;
        input.tipo = this.tipo;
        input.estado = this.estado;
        input.usuarioId = (_b = this.usuario) === null || _b === void 0 ? void 0 : _b.id;
        input.observacion = this.observacion;
        return input;
    }
}
class InventarioInput {
}
class InventarioProducto {
    constructor() {
        this.inventarioProductoItemList = [];
    }
    toInput() {
        var _a, _b, _c, _d;
        let input = new InventarioProductoInput;
        input.id = this.id;
        input.inventarioId = (_a = this.inventario) === null || _a === void 0 ? void 0 : _a.id;
        input.productoId = (_b = this.producto) === null || _b === void 0 ? void 0 : _b.id;
        input.zonaId = (_c = this.zona) === null || _c === void 0 ? void 0 : _c.id;
        input.concluido = this.concluido;
        input.usuarioId = (_d = this.usuario) === null || _d === void 0 ? void 0 : _d.id;
        input.creadoEn = this.creadoEn;
        return input;
    }
}
class InventarioProductoInput {
}
class InventarioProductoItem {
    toInput() {
        var _a, _b, _c, _d;
        let input = new InventarioProductoItemInput;
        input.id = this.id;
        input.inventarioProductoId = (_a = this.inventarioProducto) === null || _a === void 0 ? void 0 : _a.id;
        input.zonaId = (_b = this.zona) === null || _b === void 0 ? void 0 : _b.id;
        input.presentacionId = (_c = this.presentacion) === null || _c === void 0 ? void 0 : _c.id;
        input.cantidad = this.cantidad;
        input.cantidadFisica = this.cantidadFisica;
        input.vencimiento = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__.dateToString)(this.vencimiento);
        input.estado = this.estado;
        input.usuarioId = (_d = this.usuario) === null || _d === void 0 ? void 0 : _d.id;
        return input;
    }
}
class InventarioProductoItemInput {
}
var InventarioEstado;
(function (InventarioEstado) {
    InventarioEstado["ABIERTO"] = "ABIERTO";
    InventarioEstado["CANCELADO"] = "CANCELADO";
    InventarioEstado["CONCLUIDO"] = "CONCLUIDO";
})(InventarioEstado || (InventarioEstado = {}));
var InventarioProductoEstado;
(function (InventarioProductoEstado) {
    InventarioProductoEstado["BUENO"] = "BUENO";
    InventarioProductoEstado["AVERIADO"] = "AVERIADO";
    InventarioProductoEstado["VENCIDO"] = "VENCIDO";
})(InventarioProductoEstado || (InventarioProductoEstado = {}));
var TipoInventario;
(function (TipoInventario) {
    TipoInventario["ABC"] = "ABC";
    TipoInventario["ZONA"] = "ZONA";
    TipoInventario["PRODUCTO"] = "PRODUCTO";
    TipoInventario["CATEGORIA"] = "CATEGORIA";
})(TipoInventario || (TipoInventario = {}));


/***/ }),

/***/ 30723:
/*!*******************************************************!*\
  !*** ./src/app/pages/inventario/inventario.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InventarioModule": () => (/* binding */ InventarioModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _nuevo_inventario_nuevo_inventario_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nuevo-inventario/nuevo-inventario.component */ 199);
/* harmony import */ var _finalizar_inventario_resumen_finalizar_inventario_resumen_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./finalizar-inventario-resumen/finalizar-inventario-resumen.component */ 86159);
/* harmony import */ var _edit_inventario_item_dialog_edit_inventario_item_dialog_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-inventario-item-dialog/edit-inventario-item-dialog.component */ 91763);
/* harmony import */ var _select_zona_dialog_select_zona_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./select-zona-dialog/select-zona-dialog.component */ 11986);
/* harmony import */ var _list_inventario_list_inventario_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./list-inventario/list-inventario.component */ 6850);
/* harmony import */ var _edit_inventario_edit_inventario_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-inventario/edit-inventario.component */ 47936);
/* harmony import */ var _inventario_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./inventario.component */ 50751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _inventario_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./inventario-routing.module */ 78000);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 90587);













let InventarioModule = class InventarioModule {
};
InventarioModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        declarations: [_inventario_component__WEBPACK_IMPORTED_MODULE_6__.InventarioComponent, _edit_inventario_edit_inventario_component__WEBPACK_IMPORTED_MODULE_5__.EditInventarioComponent, _list_inventario_list_inventario_component__WEBPACK_IMPORTED_MODULE_4__.ListInventarioComponent, _select_zona_dialog_select_zona_dialog_component__WEBPACK_IMPORTED_MODULE_3__.SelectZonaDialogComponent, _edit_inventario_item_dialog_edit_inventario_item_dialog_component__WEBPACK_IMPORTED_MODULE_2__.EditInventarioItemDialogComponent, _finalizar_inventario_resumen_finalizar_inventario_resumen_component__WEBPACK_IMPORTED_MODULE_1__.FinalizarInventarioResumenComponent, _nuevo_inventario_nuevo_inventario_component__WEBPACK_IMPORTED_MODULE_0__.NuevoInventarioComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _inventario_routing_module__WEBPACK_IMPORTED_MODULE_7__.InventarioRoutingModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormsModule
        ]
    })
], InventarioModule);



/***/ }),

/***/ 82769:
/*!********************************************************!*\
  !*** ./src/app/pages/inventario/inventario.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InventarioService": () => (/* binding */ InventarioService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _graphql_cancelar_inventario__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/cancelar-inventario */ 62755);
/* harmony import */ var _graphql_finalizar_inventario__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./graphql/finalizar-inventario */ 7884);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../services/cargando.service */ 68030);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var _graphql_deleteInventario__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql/deleteInventario */ 89657);
/* harmony import */ var _graphql_deleteInventarioProducto__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./graphql/deleteInventarioProducto */ 87323);
/* harmony import */ var _graphql_deleteInventarioProductoItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./graphql/deleteInventarioProductoItem */ 37636);
/* harmony import */ var _graphql_getInventario__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./graphql/getInventario */ 77355);
/* harmony import */ var _graphql_getInventarioPorFecha__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./graphql/getInventarioPorFecha */ 30023);
/* harmony import */ var _graphql_saveInventario__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./graphql/saveInventario */ 32150);
/* harmony import */ var _graphql_saveInventarioProducto__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./graphql/saveInventarioProducto */ 92174);
/* harmony import */ var _graphql_saveInventarioProductoItem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./graphql/saveInventarioProductoItem */ 19557);
/* harmony import */ var _graphql_getInventarioPorUsuario__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./graphql/getInventarioPorUsuario */ 83718);
/* harmony import */ var _graphql_getInventarioAbiertoPorSucursal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./graphql/getInventarioAbiertoPorSucursal */ 60542);
/* harmony import */ var _graphql_getInventarioProductoItemPorInventarioProducto_copy__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./graphql/getInventarioProductoItemPorInventarioProducto copy */ 37031);






















let InventarioService = class InventarioService {
    constructor(genericCrudService, getInventario, saveInventario, deleteInventario, saveInventarioProducto, deleteInventarioProducto, saveInventarioProductoItem, deleteInventarioProductoItem, getInventariosPorFecha, cargandoService, notificacionService, inventarioPorUsuario, mainService, finalizarInventario, cancelarInventrio, inventarioAbiertoPorSucursal, getInventarioProItem) {
        this.genericCrudService = genericCrudService;
        this.getInventario = getInventario;
        this.saveInventario = saveInventario;
        this.deleteInventario = deleteInventario;
        this.saveInventarioProducto = saveInventarioProducto;
        this.deleteInventarioProducto = deleteInventarioProducto;
        this.saveInventarioProductoItem = saveInventarioProductoItem;
        this.deleteInventarioProductoItem = deleteInventarioProductoItem;
        this.getInventariosPorFecha = getInventariosPorFecha;
        this.cargandoService = cargandoService;
        this.notificacionService = notificacionService;
        this.inventarioPorUsuario = inventarioPorUsuario;
        this.mainService = mainService;
        this.finalizarInventario = finalizarInventario;
        this.cancelarInventrio = cancelarInventrio;
        this.inventarioAbiertoPorSucursal = inventarioAbiertoPorSucursal;
        this.getInventarioProItem = getInventarioProItem;
    }
    onGetInventarioUsuario() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onGetById(this.inventarioPorUsuario, this.mainService.usuarioActual.id);
        });
    }
    onGetTrasferenciasPorFecha(inicio, fin) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onGetByFecha(this.getInventariosPorFecha, inicio, fin);
        });
    }
    onGetInventarioAbiertoPorSucursal(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onGetById(this.inventarioAbiertoPorSucursal, id);
        });
    }
    onGetInventario(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onGetById(this.getInventario, id);
        });
    }
    onGetInventarioProItem(id, page) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onGetById(this.getInventarioProItem, id, page, 5);
        });
    }
    onSaveInventario(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onSave(this.saveInventario, input);
        });
    }
    onDeleteInventario(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return this.genericCrudService.onDelete(this.deleteInventario, id, 'Realmente  desea eliminar esta inventario?');
        });
    }
    onSaveInventarioProducto(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            if (input.usuarioId == null) {
                input.usuarioId = +localStorage.getItem("usuarioId");
            }
            return new rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable((obs) => {
                this.saveInventarioProducto
                    .mutate({ entity: input }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        this.notificacionService.open('Guardado con éxito', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.TipoNotificacion.SUCCESS, 2);
                    }
                    else {
                        console.log(res.errors);
                        obs.next();
                        if (res.errors[0].message.includes('inventario_producto_un')) {
                            this.notificacionService.open('Esta zona ya esta siendo inventariada.', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.TipoNotificacion.WARN, 2);
                        }
                        else if (res.errors[0].message.includes('Ya tenes una zona abierta')) {
                            this.notificacionService.open('Ya tenes una zona abierta. Despues de concluirla podrás iniciar el inventario de otra', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.TipoNotificacion.WARN, 3);
                        }
                    }
                });
            });
        });
    }
    onDeleteInventarioProducto(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onDelete(this.deleteInventarioProducto, id, 'Realmente  desea eliminar este item');
        });
    }
    onSaveInventarioProductoItem(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onSave(this.saveInventarioProductoItem, input);
        });
    }
    onDeleteInventarioProductoItem(id, item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onDelete(this.deleteInventarioProductoItem, id, item);
        });
    }
    onFinalizarInventario(id) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable(obs => {
            this.finalizarInventario.mutate({
                id,
            }, { errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                .subscribe(res => {
                var _a;
                if (((_a = res === null || res === void 0 ? void 0 : res.errors) === null || _a === void 0 ? void 0 : _a.length) > 0) { //si hay error
                    this.notificacionService.openAlgoSalioMal();
                }
                else { //si no
                    obs.next(res.data['data']); // data
                    this.notificacionService.openGuardadoConExito();
                }
            });
        });
    }
    onCancelarInventario(id) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable(obs => {
            this.cancelarInventrio.mutate({
                id,
            }, { errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                .subscribe(res => {
                var _a;
                if (((_a = res === null || res === void 0 ? void 0 : res.errors) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                    this.notificacionService.openAlgoSalioMal();
                    obs.next(false);
                }
                else {
                    obs.next(true);
                    this.notificacionService.openGuardadoConExito();
                }
            });
        });
    }
};
InventarioService.ctorParameters = () => [
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_5__.GenericCrudService },
    { type: _graphql_getInventario__WEBPACK_IMPORTED_MODULE_9__.GetInventarioGQL },
    { type: _graphql_saveInventario__WEBPACK_IMPORTED_MODULE_11__.SaveInventarioGQL },
    { type: _graphql_deleteInventario__WEBPACK_IMPORTED_MODULE_6__.DeleteInventarioGQL },
    { type: _graphql_saveInventarioProducto__WEBPACK_IMPORTED_MODULE_12__.SaveInventarioProductoGQL },
    { type: _graphql_deleteInventarioProducto__WEBPACK_IMPORTED_MODULE_7__.DeleteInventarioProductoGQL },
    { type: _graphql_saveInventarioProductoItem__WEBPACK_IMPORTED_MODULE_13__.SaveInventarioProductoItemGQL },
    { type: _graphql_deleteInventarioProductoItem__WEBPACK_IMPORTED_MODULE_8__.DeleteInventarioProductoItemGQL },
    { type: _graphql_getInventarioPorFecha__WEBPACK_IMPORTED_MODULE_10__.GetInventarioPorFechaGQL },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_4__.CargandoService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_3__.NotificacionService },
    { type: _graphql_getInventarioPorUsuario__WEBPACK_IMPORTED_MODULE_14__.GetInventarioPorUsuarioGQL },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_2__.MainService },
    { type: _graphql_finalizar_inventario__WEBPACK_IMPORTED_MODULE_1__.FinalizarInventarioGQL },
    { type: _graphql_cancelar_inventario__WEBPACK_IMPORTED_MODULE_0__.CancelarInventarioGQL },
    { type: _graphql_getInventarioAbiertoPorSucursal__WEBPACK_IMPORTED_MODULE_15__.GetInventarioAbiertoPorSucursalGQL },
    { type: _graphql_getInventarioProductoItemPorInventarioProducto_copy__WEBPACK_IMPORTED_MODULE_16__.GetInventarioItemPorInvetarioProductoGQL }
];
InventarioService = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.Injectable)({
        providedIn: 'root'
    })
], InventarioService);



/***/ }),

/***/ 6850:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/inventario/list-inventario/list-inventario.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListInventarioComponent": () => (/* binding */ ListInventarioComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _list_inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-inventario.component.html?ngResource */ 61079);
/* harmony import */ var _list_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-inventario.component.scss?ngResource */ 78243);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/menu-action.service */ 47257);
/* harmony import */ var _inventario_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../inventario.service */ 82769);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);











let ListInventarioComponent = class ListInventarioComponent {
    constructor(inventarioService, mainService, router, route, _location, menuActionService) {
        this.inventarioService = inventarioService;
        this.mainService = mainService;
        this.router = router;
        this.route = route;
        this._location = _location;
        this.menuActionService = menuActionService;
    }
    ngOnInit() {
        this.verificarUsuario();
    }
    onGetInventarios() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.inventarioService.onGetInventarioUsuario())
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.inventarioList = res;
                }
            });
        });
    }
    verificarUsuario() {
        var _a;
        if (((_a = this.mainService) === null || _a === void 0 ? void 0 : _a.usuarioActual) != null) {
            this.onGetInventarios();
        }
        else {
            setTimeout(() => {
                this.verificarUsuario();
            }, 1000);
        }
    }
    onItemClick(item) {
        this.router.navigate(['info', item.id], { relativeTo: this.route });
    }
    onBack() {
        this._location.back();
    }
    openFilterMenu() {
        this.menuActionService.presentActionSheet([
            { texto: 'Ordenar por fecha', role: 'fecha' },
            { texto: 'Primero inventarios abiertas', role: 'abiertas' },
            { texto: 'Primero concluidas', role: 'concluidas' },
        ]).then(res => {
            let role = res.role;
            this.onFiltrar(role);
            console.log(role);
        });
    }
    onFiltrar(role) {
        switch (role) {
            case 'fecha':
                this.inventarioList = this.inventarioList.sort((a, b) => {
                    if (a.fechaInicio > b.fechaInicio) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                });
                break;
            case 'abiertas':
                this.inventarioList = this.inventarioList.sort((a, b) => {
                    if (a.estado > b.estado) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                });
                break;
            case 'concluidas':
                this.inventarioList = this.inventarioList.sort((a, b) => {
                    if (a.estado < b.estado) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                });
                break;
        }
    }
};
ListInventarioComponent.ctorParameters = () => [
    { type: _inventario_service__WEBPACK_IMPORTED_MODULE_4__.InventarioService },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_2__.MainService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.Location },
    { type: src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_3__.MenuActionService }
];
ListInventarioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-list-inventario',
        template: _list_inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_list_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListInventarioComponent);



/***/ }),

/***/ 199:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/inventario/nuevo-inventario/nuevo-inventario.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NuevoInventarioComponent": () => (/* binding */ NuevoInventarioComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _nuevo_inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nuevo-inventario.component.html?ngResource */ 16389);
/* harmony import */ var _nuevo_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nuevo-inventario.component.scss?ngResource */ 16132);
/* harmony import */ var _services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/dialogo.service */ 86124);
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/login.service */ 54120);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _inventario_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../inventario.model */ 98046);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../../generic/utils/qrUtils */ 83503);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var _inventario_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../inventario.service */ 82769);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/domains/empresarial/sucursal/sucursal.service */ 17976);
/* harmony import */ var src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/domains/enums/tipo-entidad.enum */ 61246);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);

















let NuevoInventarioComponent = class NuevoInventarioComponent {
    constructor(inventarioService, barcodeScanner, modalService, notificacionService, router, sucursalService, loginService, dialogoService, plf) {
        this.inventarioService = inventarioService;
        this.barcodeScanner = barcodeScanner;
        this.modalService = modalService;
        this.notificacionService = notificacionService;
        this.router = router;
        this.sucursalService = sucursalService;
        this.loginService = loginService;
        this.dialogoService = dialogoService;
        this.plf = plf;
        this.isNew = true;
        this.isWeb = false;
    }
    ngOnInit() {
        this.isWeb = this.plf.platforms().includes('mobileweb');
        if (this.data != null) {
            this.selectedSucursal = this.data.data;
        }
    }
    cargarDatos(sucId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.sucursalService.onGetSucursal(sucId))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_13__.untilDestroyed)(this))
                .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
                if (res != null) {
                    this.selectedSucursal = res;
                    (yield this.inventarioService.onGetInventarioAbiertoPorSucursal(sucId))
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_13__.untilDestroyed)(this))
                        .subscribe(res2 => {
                        if (res2.length > 0) {
                            this.modalService.closeModal({ inventario: res2[0] });
                            this.notificacionService.open('Hay un inventario abierto en esta sucursal', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__.TipoNotificacion.WARN, 2);
                        }
                    });
                }
            }));
        });
    }
    onScanQr() {
        var _a;
        if (this.data != null) {
            this.cargarDatos((_a = this.data.data.data) === null || _a === void 0 ? void 0 : _a.id);
        }
        else {
            this.barcodeScanner.scan().then((barcodeData) => (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
                if (barcodeData.text != null) {
                    let qrData;
                    qrData = (0,_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_6__.descodificarQr)(barcodeData.text);
                    if (qrData.tipoEntidad == src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_11__.TipoEntidad.SUCURSAL && qrData.sucursalId != null) {
                        this.cargarDatos(qrData.sucursalId);
                    }
                }
                else {
                }
            }));
        }
    }
    onBack() {
        this.modalService.closeModal(null);
    }
    onCancel() {
        this.onBack();
    }
    onAceptar() {
        let inventario = new _inventario_model__WEBPACK_IMPORTED_MODULE_5__.Inventario;
        inventario.abierto = true;
        inventario.estado = _inventario_model__WEBPACK_IMPORTED_MODULE_5__.InventarioEstado.ABIERTO;
        inventario.sucursal = this.selectedSucursal;
        inventario.tipo = _inventario_model__WEBPACK_IMPORTED_MODULE_5__.TipoInventario.ZONA;
        inventario.usuario = this.loginService.usuarioActual;
        this.dialogoService.open('Atención!!', 'Estas iniciando un nuevo inventario. Desea continuar?').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            if (res.role = 'aceptar') {
                (yield this.inventarioService.onSaveInventario(inventario.toInput()))
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_13__.untilDestroyed)(this))
                    .subscribe(res => {
                    if (res != null) {
                        this.modalService.closeModal({ inventario: res });
                    }
                });
            }
        }));
    }
};
NuevoInventarioComponent.ctorParameters = () => [
    { type: _inventario_service__WEBPACK_IMPORTED_MODULE_9__.InventarioService },
    { type: _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__.BarcodeScanner },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_7__.ModalService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_4__.NotificacionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.Router },
    { type: src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_10__.SucursalService },
    { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_3__.LoginService },
    { type: _services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.Platform }
];
NuevoInventarioComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_16__.Input }]
};
NuevoInventarioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_13__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.Component)({
        selector: 'app-nuevo-inventario',
        template: _nuevo_inventario_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [
            _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__.BarcodeScanner
        ],
        styles: [_nuevo_inventario_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NuevoInventarioComponent);



/***/ }),

/***/ 11986:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/inventario/select-zona-dialog/select-zona-dialog.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectZonaDialogComponent": () => (/* binding */ SelectZonaDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _select_zona_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./select-zona-dialog.component.html?ngResource */ 85629);
/* harmony import */ var _select_zona_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./select-zona-dialog.component.scss?ngResource */ 46285);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _generic_utils_string_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../generic/utils/string-utils */ 44426);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);











let SelectZonaDialogComponent = class SelectZonaDialogComponent {
    constructor(_location, modalService, dialogService) {
        this._location = _location;
        this.modalService = modalService;
        this.dialogService = dialogService;
        this.buscarControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('');
        this.sectorList = [];
    }
    ngOnInit() {
        this.sectorList = this.data;
        this.buscarControl.valueChanges.pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this)).subscribe(res => {
            if (res == '' || res == null) {
                console.log('null');
                this.sectorList = this.data;
            }
            else {
                this.sectorList.forEach(e => {
                    e.zonaList = e.zonaList.filter(z => (0,_generic_utils_string_utils__WEBPACK_IMPORTED_MODULE_4__.comparatorLike)(z.descripcion, res));
                });
            }
        });
    }
    onZonaClick(zona) {
        // this.dialogService.open('Atención!', `Estas iniciando el inventario en la zona ${zona.descripcion}. Solo una persona puede inventariar una zona. Desea continuar?`).then(res => {
        //   if(res.role=='aceptar'){
        //   }
        // })
        this.modalService.closeModal(zona);
    }
    onBack() {
        this.modalService.closeModal(null);
    }
};
SelectZonaDialogComponent.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.Location },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_3__.ModalService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService }
];
SelectZonaDialogComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
SelectZonaDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-select-zona-dialog',
        template: _select_zona_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_select_zona_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SelectZonaDialogComponent);



/***/ }),

/***/ 2443:
/*!*************************************************************************!*\
  !*** ./src/app/pages/producto/edit-producto/edit-producto.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditProductoComponent": () => (/* binding */ EditProductoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_producto_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-producto.component.html?ngResource */ 86280);
/* harmony import */ var _edit_producto_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-producto.component.scss?ngResource */ 93851);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let EditProductoComponent = class EditProductoComponent {
    constructor() { }
    ngOnInit() { }
};
EditProductoComponent.ctorParameters = () => [];
EditProductoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-edit-producto',
        template: _edit_producto_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edit_producto_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditProductoComponent);



/***/ }),

/***/ 68676:
/*!********************************************************!*\
  !*** ./src/app/pages/producto/graphql/allProductos.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AllProductosGQL": () => (/* binding */ AllProductosGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let AllProductosGQL = class AllProductosGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.productosQuery;
    }
};
AllProductosGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], AllProductosGQL);



/***/ }),

/***/ 64889:
/*!*********************************************************!*\
  !*** ./src/app/pages/producto/graphql/graphql-query.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteProductoQuery": () => (/* binding */ deleteProductoQuery),
/* harmony export */   "envaseSearchPdv": () => (/* binding */ envaseSearchPdv),
/* harmony export */   "exportarReporteQuery": () => (/* binding */ exportarReporteQuery),
/* harmony export */   "findByPdvGrupoProductoQuery": () => (/* binding */ findByPdvGrupoProductoQuery),
/* harmony export */   "printProductoPorId": () => (/* binding */ printProductoPorId),
/* harmony export */   "productoExistenciaCostoPorProveedor": () => (/* binding */ productoExistenciaCostoPorProveedor),
/* harmony export */   "productoParaPedidoQuery": () => (/* binding */ productoParaPedidoQuery),
/* harmony export */   "productoPorCodigoQuery": () => (/* binding */ productoPorCodigoQuery),
/* harmony export */   "productoPorProveedor": () => (/* binding */ productoPorProveedor),
/* harmony export */   "productoQuery": () => (/* binding */ productoQuery),
/* harmony export */   "productoSearchPdv": () => (/* binding */ productoSearchPdv),
/* harmony export */   "productoStock": () => (/* binding */ productoStock),
/* harmony export */   "productoStockCostoPorProducto": () => (/* binding */ productoStockCostoPorProducto),
/* harmony export */   "productoUltimasComprasQuery": () => (/* binding */ productoUltimasComprasQuery),
/* harmony export */   "productosExistenciaCostoQuery": () => (/* binding */ productosExistenciaCostoQuery),
/* harmony export */   "productosExistenciaCostoSearch": () => (/* binding */ productosExistenciaCostoSearch),
/* harmony export */   "productosQuery": () => (/* binding */ productosQuery),
/* harmony export */   "productosSearch": () => (/* binding */ productosSearch),
/* harmony export */   "saveImagenProductoQuery": () => (/* binding */ saveImagenProductoQuery),
/* harmony export */   "saveProducto": () => (/* binding */ saveProducto)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const productosQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: productos {
      id
      descripcion
      garantia
      vencimiento
      diasVencimiento
      observacion
      cambiable
      imagenPrincipal
      subfamilia {
        id
        descripcion
        familia {
          id
          descripcion
        }
      }
      presentaciones {
        id
        principal
        codigos {
          id
          codigo
          principal
          activo
        }
        tipoPresentacion {
          id
          descripcion
        }
        cantidad
        imagenPrincipal
        precios {
          id
          precio
          tipoPrecio {
            id
            descripcion
          }
          principal
          activo
        }
      }
    }
  }
`;
const productosExistenciaCostoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: productos {
      id
      descripcion

    }
  }
`;
const productosExistenciaCostoSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: productoSearch(texto: $texto) {
      id

    }
  }
`;
const productoSearchPdv = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String, $offset: Int, $isEnvase: Boolean) {
    data: productoSearch(texto: $texto, offset: $offset, isEnvase: $isEnvase) {
      id
      descripcion
      garantia
      balanza
      vencimiento
      diasVencimiento
      observacion
      codigoPrincipal
      imagenPrincipal
      envase {
        id
        descripcion
      }
      # cambiable
      # presentaciones {
      #   id
      #   principal
      #   codigos {
      #     id
      #     codigo
      #     principal
      #     activo
      #   }
      #   tipoPresentacion {
      #     id
      #     descripcion
      #   }
      #   cantidad
      #   imagenPrincipal
      #   precios {
      #     id
      #     precio
      #     tipoPrecio {
      #       id
      #       descripcion
      #     }
      #     principal
      #     activo
      #   }
      # }
    }
  }
`;
const envaseSearchPdv = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String, $offset: Int, $isEnvase: Boolean) {
    data: productoSearch(texto: $texto, offset: $offset, isEnvase: $isEnvase) {
      id
      descripcion
      precioPrincipal
    }
  }
`;
const productosSearch = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: productoSearch(texto: $texto) {
      id
      descripcion
      descripcionFactura
      iva
      unidadPorCaja
      balanza
      garantia
      ingrediente
      combo
      cambiable
      stock
      promocion
      vencimiento
      diasVencimiento

      tipoConservacion
      subfamilia {
        id
        descripcion
        familia {
          id
          descripcion
        }
      }
    }
  }
`;
const productoStock = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($proId: ID!, $sucId: ID!) {
    data: productoPorSucursalStock(proId: $proId, sucId: $sucId)
  }
`;
const productoStockCostoPorProducto = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($proId: ID!, $sucId: ID!) {
    data: costoPorProductolLastPorProductoId(proId: $proId) {
      sucursal {
        id
        nombre
      }
      producto {
        id
        descripcion
      }
      ultimoPrecioCompra
      ultimoPrecioVenta
      costoMedio
      cantMinima
      cantMaxima
      cantMedia
      movimientoStock {
        id
        cantidad
        proveedor {
          id
          persona {
            id
            nombre
          }
        }
      }
    }
  }
`;
const productoExistenciaCostoPorProveedor = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $texto: String) {
    data: productoPorProveedorId(id: $id, texto: $texto) {
      id
      descripcion
    }
  }
`;
const productoPorCodigoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: productoPorCodigo(texto: $texto) {
      id
      descripcion
      garantia
      vencimiento
      diasVencimiento
      observacion
      cambiable
      imagenPrincipal
      isEnvase
      envase {
        id
        descripcion
      }
      subfamilia {
        id
        descripcion
        familia {
          id
          descripcion
        }
      }
      presentaciones {
        id
        principal
        codigos {
          id
          codigo
          principal
          activo
        }
        tipoPresentacion {
          id
          descripcion
        }
        cantidad
        imagenPrincipal
        precios {
          id
          precio
          tipoPrecio {
            id
            descripcion
          }
          principal
          activo
        }
      }
    }
  }
`;
const productoPorProveedor = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $texto: String) {
    data: productoPorProveedorId(id: $id, texto: $texto) {
      id
      descripcion
      descripcionFactura
      iva
      cambiable
      unidadPorCaja
      balanza
      garantia
      ingrediente
      combo
      stock
      promocion
      vencimiento
      diasVencimiento

      tipoConservacion
      subfamilia {
        id
        descripcion
        familia {
          id
          descripcion
        }
      }
    }
  }
`;
const productoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: producto(id: $id) {
      id
      descripcion
      descripcionFactura
      garantia
      balanza
      vencimiento
      diasVencimiento
      observacion
      cambiable
      imagenPrincipal
      iva
      stock
      isEnvase
      envase {
        id
        descripcion
      }
      subfamilia {
        id
        descripcion
        familia {
          id
          descripcion
        }
      }
      presentaciones {
        id
        descripcion
        principal
        cantidad
        codigos {
          id
          codigo
          principal
          activo
        }
        tipoPresentacion {
          id
          descripcion
        }
        imagenPrincipal
        precios {
          id
          precio
          tipoPrecio {
            id
            descripcion
          }
          principal
          activo
        }
        codigoPrincipal {
          codigo
        }
        precioPrincipal {
          precio
        }
      }
      costo {
        id
        ultimoPrecioCompra
        costoMedio
      }
    }
  }
`;
const productoUltimasComprasQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: producto(id: $id) {
      id
      descripcion
      productoUltimasCompras {
        cantidad
        precio
        creadoEn
        pedido {
          id
          proveedor {
            persona {
              nombre
            }
          }
        }
      }
    }
  }
`;
const saveProducto = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveProducto($entity: ProductoInput!) {
    data: saveProducto(producto: $entity) {
      id
      descripcion
      descripcionFactura
      iva
      unidadPorCaja
      unidadPorCajaSecundaria
      balanza
      garantia
      ingrediente
      combo
      cambiable
      stock
      promocion
      vencimiento
      diasVencimiento

      tipoConservacion
      subfamilia {
        id
        descripcion
        nombre
        familia {
          id
          descripcion
          nombre
        }
        subfamiliaList {
          id
          nombre
          descripcion
        }
      }
    }
  }
`;
const deleteProductoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteProducto($id: ID!) {
    deleteProducto(id: $id)
  }
`;
const saveImagenProductoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveImagenProducto($image: String!, $filename: String!) {
    saveImagenProducto(image: $image, filename: $filename)
  }
`;
const printProductoPorId = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: printProducto(id: $id) {
      id
    }
  }
`;
const productoParaPedidoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: producto(id: $id) {
      id
      descripcion
      descripcionFactura
      garantia
      balanza
      vencimiento
      diasVencimiento
      observacion
      cambiable
      imagenPrincipal
      iva
      stock
      presentaciones {
        id
        descripcion
        principal
        cantidad
        codigos {
          id
          codigo
          principal
          activo
        }
        tipoPresentacion {
          id
          descripcion
        }
        imagenPrincipal
        precios {
          id
          precio
          tipoPrecio {
            id
            descripcion
          }
          principal
          activo
        }
        codigoPrincipal {
          codigo
        }
      }
      costo {
        id
        movimientoStock {
          id
        }
        ultimoPrecioCompra
        ultimoPrecioVenta
        costoMedio
        moneda {
          id
          denominacion
          cambio
        }
        existencia
      }
    }
  }
`;
const exportarReporteQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($texto: String) {
    data: exportarReporte(texto: $texto)
  }
`;
const findByPdvGrupoProductoQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: findByPdvGrupoProductoId(id: $id) {
      id
      descripcion
      descripcionFactura
      garantia
      balanza
      vencimiento
      diasVencimiento
      observacion
      cambiable
      imagenPrincipal
      iva
      stock
      isEnvase
      envase {
        id
        descripcion
        precioPrincipal
      }
      presentaciones {
        id
        descripcion
        principal
        cantidad
        codigos {
          id
          codigo
          principal
          activo
        }
        tipoPresentacion {
          id
          descripcion
        }
        imagenPrincipal
        precios {
          id
          precio
          tipoPrecio {
            id
            descripcion
          }
          principal
          activo
        }
        codigoPrincipal {
          codigo
        }
      }
    }
  }
`;


/***/ }),

/***/ 12180:
/*!*************************************************************!*\
  !*** ./src/app/pages/producto/graphql/productoPorCodigo.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoPorCodigoGQL": () => (/* binding */ ProductoPorCodigoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let ProductoPorCodigoGQL = class ProductoPorCodigoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.productoPorCodigoQuery;
    }
};
ProductoPorCodigoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ProductoPorCodigoGQL);



/***/ }),

/***/ 61121:
/*!*********************************************************!*\
  !*** ./src/app/pages/producto/graphql/productoPorId.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoPorIdGQL": () => (/* binding */ ProductoPorIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let ProductoPorIdGQL = class ProductoPorIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.productoQuery;
    }
};
ProductoPorIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ProductoPorIdGQL);



/***/ }),

/***/ 57475:
/*!****************************************************************!*\
  !*** ./src/app/pages/producto/graphql/productoSearchForPdv.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoForPdvGQL": () => (/* binding */ ProductoForPdvGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let ProductoForPdvGQL = class ProductoForPdvGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.productoSearchPdv;
    }
};
ProductoForPdvGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ProductoForPdvGQL);



/***/ }),

/***/ 95226:
/*!**************************************************************!*\
  !*** ./src/app/pages/producto/graphql/saveImagenProducto.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveImagenProductoGQL": () => (/* binding */ SaveImagenProductoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let SaveImagenProductoGQL = class SaveImagenProductoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveImagenProductoQuery;
    }
};
SaveImagenProductoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveImagenProductoGQL);



/***/ }),

/***/ 83844:
/*!********************************************************!*\
  !*** ./src/app/pages/producto/graphql/saveProducto.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveProductoGQL": () => (/* binding */ SaveProductoGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let SaveProductoGQL = class SaveProductoGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveProducto;
    }
};
SaveProductoGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveProductoGQL);



/***/ }),

/***/ 51833:
/*!************************************************************************!*\
  !*** ./src/app/pages/producto/graphql/stockBySucursalAndProductoId.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoStockBySucursalGQL": () => (/* binding */ ProductoStockBySucursalGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 64889);




let ProductoStockBySucursalGQL = class ProductoStockBySucursalGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.productoStock;
    }
};
ProductoStockBySucursalGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ProductoStockBySucursalGQL);



/***/ }),

/***/ 64695:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/producto/producto-dashboard/producto-dashboard.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoDashboardComponent": () => (/* binding */ ProductoDashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _producto_dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./producto-dashboard.component.html?ngResource */ 79613);
/* harmony import */ var _producto_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./producto-dashboard.component.scss?ngResource */ 83324);
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/login.service */ 54120);
/* harmony import */ var _search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../search-producto-dialog/search-producto-dialog.component */ 38612);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);








let ProductoDashboardComponent = class ProductoDashboardComponent {
    constructor(router, route, modalService, loginService) {
        this.router = router;
        this.route = route;
        this.modalService = modalService;
        this.loginService = loginService;
    }
    ngOnInit() { }
    onBuscarProducto() {
        this.modalService.openModal(_search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_3__.SearchProductoDialogComponent, {
            data: {
                mostrarPrecio: true
            }
        }).then(res => {
            var _a, _b;
            if (res != null) {
                console.log(res);
                let presentacion = (_a = res === null || res === void 0 ? void 0 : res.data) === null || _a === void 0 ? void 0 : _a.presentacion;
                let producto = (_b = res === null || res === void 0 ? void 0 : res.data) === null || _b === void 0 ? void 0 : _b.producto;
            }
        });
    }
};
ProductoDashboardComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_4__.ModalService },
    { type: _services_login_service__WEBPACK_IMPORTED_MODULE_2__.LoginService }
];
ProductoDashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-producto-dashboard',
        template: _producto_dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_producto_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProductoDashboardComponent);



/***/ }),

/***/ 50166:
/*!***********************************************************!*\
  !*** ./src/app/pages/producto/producto-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoRoutingModule": () => (/* binding */ ProductoRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_producto_edit_producto_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-producto/edit-producto.component */ 2443);
/* harmony import */ var _search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search-producto-dialog/search-producto-dialog.component */ 38612);
/* harmony import */ var _producto_dashboard_producto_dashboard_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./producto-dashboard/producto-dashboard.component */ 64695);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);






const routes = [
    {
        path: '',
        component: _producto_dashboard_producto_dashboard_component__WEBPACK_IMPORTED_MODULE_2__.ProductoDashboardComponent,
    },
    {
        path: 'buscar/:mostrarPrecio',
        component: _search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_1__.SearchProductoDialogComponent,
    },
    {
        path: 'edit/:id',
        component: _edit_producto_edit_producto_component__WEBPACK_IMPORTED_MODULE_0__.EditProductoComponent,
    }
];
let ProductoRoutingModule = class ProductoRoutingModule {
};
ProductoRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
    })
], ProductoRoutingModule);



/***/ }),

/***/ 10212:
/*!***************************************************!*\
  !*** ./src/app/pages/producto/producto.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductoModule": () => (/* binding */ ProductoModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _edit_producto_edit_producto_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-producto/edit-producto.component */ 2443);
/* harmony import */ var _producto_dashboard_producto_dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./producto-dashboard/producto-dashboard.component */ 64695);
/* harmony import */ var _producto_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./producto-routing.module */ 50166);
/* harmony import */ var _search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search-producto-dialog/search-producto-dialog.component */ 38612);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/components.module */ 45642);










let ProductoModule = class ProductoModule {
};
ProductoModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [_producto_dashboard_producto_dashboard_component__WEBPACK_IMPORTED_MODULE_1__.ProductoDashboardComponent, _edit_producto_edit_producto_component__WEBPACK_IMPORTED_MODULE_0__.EditProductoComponent, _search_producto_dialog_search_producto_dialog_component__WEBPACK_IMPORTED_MODULE_3__.SearchProductoDialogComponent],
        imports: [
            _producto_routing_module__WEBPACK_IMPORTED_MODULE_2__.ProductoRoutingModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_4__.ComponentsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
        ]
    })
], ProductoModule);



/***/ }),

/***/ 73112:
/*!****************************************************!*\
  !*** ./src/app/pages/producto/producto.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomData": () => (/* binding */ CustomData),
/* harmony export */   "CustomResponse": () => (/* binding */ CustomResponse),
/* harmony export */   "ProductoService": () => (/* binding */ ProductoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/cargando.service */ 68030);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 84505);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/generic/generic-crud.service */ 18531);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var _graphql_allProductos__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./graphql/allProductos */ 68676);
/* harmony import */ var _graphql_productoPorId__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/productoPorId */ 61121);
/* harmony import */ var _graphql_productoSearchForPdv__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql/productoSearchForPdv */ 57475);
/* harmony import */ var _graphql_saveImagenProducto__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./graphql/saveImagenProducto */ 95226);
/* harmony import */ var _graphql_saveProducto__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./graphql/saveProducto */ 83844);
/* harmony import */ var _graphql_stockBySucursalAndProductoId__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./graphql/stockBySucursalAndProductoId */ 51833);
/* harmony import */ var _graphql_productoPorCodigo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./graphql/productoPorCodigo */ 12180);




class CustomResponse {
}
class CustomData {
}











let ProductoService = class ProductoService {
    constructor(mainService, saveProducto, productoPorId, saveImage, productoSearch, notificacionSnack, searchForPdv, getAllProductos, genericService, cargandoService, getStockPorSucursal, productoPorCodigo) {
        this.mainService = mainService;
        this.saveProducto = saveProducto;
        this.productoPorId = productoPorId;
        this.saveImage = saveImage;
        this.productoSearch = productoSearch;
        this.notificacionSnack = notificacionSnack;
        this.searchForPdv = searchForPdv;
        this.getAllProductos = getAllProductos;
        this.genericService = genericService;
        this.cargandoService = cargandoService;
        this.getStockPorSucursal = getStockPorSucursal;
        this.productoPorCodigo = productoPorCodigo;
        this.productosSub = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject(null);
        this.buscandoProductos = false;
        this.productosList = [];
    }
    onSearch(texto, offset) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open();
            return new rxjs__WEBPACK_IMPORTED_MODULE_13__.Observable((obs) => {
                this.productoSearch
                    .fetch({
                    texto,
                    offset,
                }, {
                    fetchPolicy: "no-cache",
                    errorPolicy: "all",
                }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        console.log(res.data.data);
                        obs.next(res.data.data);
                    }
                    else {
                    }
                });
            });
        });
    }
    onSearchLocal(texto) {
        return Promise.all(this.productosList.filter((p) => {
            let regex = new RegExp(".*" + texto.replace(" ", ".*"));
            if (regex.test(p.descripcion) ||
                p.descripcion.replace(" ", "").includes(texto.replace(" ", ""))) {
                console.log(p.descripcion);
                return p;
            }
        }));
    }
    onSearchParaPdv() { }
    onGetProductoPorId(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.productoPorId, id);
        });
    }
    onSaveProducto(input) {
        let isNew = (input === null || input === void 0 ? void 0 : input.id) == null;
        return new rxjs__WEBPACK_IMPORTED_MODULE_13__.Observable((obs) => {
            var _a, _b;
            input.usuarioId = (_b = (_a = this.mainService) === null || _a === void 0 ? void 0 : _a.usuarioActual) === null || _b === void 0 ? void 0 : _b.id;
            this.saveProducto
                .mutate({
                entity: input,
            }, { errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.untilDestroyed)(this))
                .subscribe((res) => {
                console.log(res.errors);
                if (res.errors == null) {
                    obs.next(res.data.data);
                    if (isNew) {
                        this.productosList.push(res.data.data);
                    }
                    else {
                        let index = this.productosList.findIndex((p) => (p.id = input.id));
                        if (index != -1) {
                            this.productosList[index] = res.data.data;
                        }
                    }
                    this.notificacionSnack.openGuardadoConExito();
                }
                else {
                    obs.next(null);
                    this.notificacionSnack.openAlgoSalioMal();
                }
            });
        });
    }
    getProducto(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGetById(this.productoPorId, id);
        });
    }
    onImageSave(image, filename) {
        // return new Observable((obs) => {
        console.log("saving image");
        this.saveImage
            .mutate({
            image,
            filename,
        }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.untilDestroyed)(this))
            .subscribe((res) => {
            if (res.errors == null) {
                // obs.next(res.data)
                this.notificacionSnack.openGuardadoConExito();
            }
            else {
                this.notificacionSnack.openAlgoSalioMal();
            }
        });
        // })
    }
    onGetStockPorSucursal(productoId, sucursalId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericService.onGet(this.getStockPorSucursal, { proId: productoId, sucId: sucursalId });
        });
    }
};
ProductoService.ctorParameters = () => [
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_3__.MainService },
    { type: _graphql_saveProducto__WEBPACK_IMPORTED_MODULE_8__.SaveProductoGQL },
    { type: _graphql_productoPorId__WEBPACK_IMPORTED_MODULE_5__.ProductoPorIdGQL },
    { type: _graphql_saveImagenProducto__WEBPACK_IMPORTED_MODULE_7__.SaveImagenProductoGQL },
    { type: _graphql_productoSearchForPdv__WEBPACK_IMPORTED_MODULE_6__.ProductoForPdvGQL },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.NotificacionService },
    { type: _graphql_productoSearchForPdv__WEBPACK_IMPORTED_MODULE_6__.ProductoForPdvGQL },
    { type: _graphql_allProductos__WEBPACK_IMPORTED_MODULE_4__.AllProductosGQL },
    { type: src_app_generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_2__.GenericCrudService },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_0__.CargandoService },
    { type: _graphql_stockBySucursalAndProductoId__WEBPACK_IMPORTED_MODULE_9__.ProductoStockBySucursalGQL },
    { type: _graphql_productoPorCodigo__WEBPACK_IMPORTED_MODULE_10__.ProductoPorCodigoGQL }
];
ProductoService = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_14__.UntilDestroy)({ checkProperties: true }),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Injectable)({
        providedIn: "root",
    })
], ProductoService);



/***/ }),

/***/ 38612:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/producto/search-producto-dialog/search-producto-dialog.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchProductoDialogComponent": () => (/* binding */ SearchProductoDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _search_producto_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search-producto-dialog.component.html?ngResource */ 35479);
/* harmony import */ var _search_producto_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search-producto-dialog.component.scss?ngResource */ 59788);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var _services_modal_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../services/modal.service */ 71609);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../../services/pop-over.service */ 21690);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _producto_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../producto.service */ 73112);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _codigo_codigo_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../codigo/codigo.service */ 75130);
/* harmony import */ var _awesome_cordova_plugins_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/photo-viewer/ngx */ 13972);

















let SearchProductoDialogComponent = class SearchProductoDialogComponent {
    constructor(productoService, popoverService, modalService, dialogService, barcodeScanner, route, _location, plf, codigoService, photoViewer) {
        this.productoService = productoService;
        this.popoverService = popoverService;
        this.modalService = modalService;
        this.dialogService = dialogService;
        this.barcodeScanner = barcodeScanner;
        this.route = route;
        this._location = _location;
        this.plf = plf;
        this.codigoService = codigoService;
        this.photoViewer = photoViewer;
        this.buscarControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.minLength(1)]);
        this.showCargarMas = true;
        this.mostrarPrecio = false;
        this.isSearchingList = [];
        this.isWeb = false;
        this.isWeb = plf.platforms().includes('mobileweb');
    }
    ngOnInit() {
        var _a, _b;
        if (((_b = (_a = this.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.mostrarPrecio) != null) {
            this.mostrarPrecio = this.data.data.mostrarPrecio;
        }
        this.isWeb ? null : this.onCameraClick();
        console.log(this.data);
    }
    onBuscarClick() {
        this.onSearchProducto(this.buscarControl.value, null);
    }
    onSearchProducto(text, offset) {
        let isPesable = false;
        let peso;
        let codigo;
        this.isSearching = true;
        if (this.onSearchTimer != null) {
            clearTimeout(this.onSearchTimer);
        }
        if (text == "" || text == null || text == " ") {
            console.log("text is ", text);
            this.isSearching = false;
        }
        else {
            if (text.length == 13 && text.substring(0, 2) == '20') {
                isPesable = true;
                codigo = text.substring(2, 7);
                peso = +text.substring(7, 12) / 1000;
                text = codigo;
            }
            this.onSearchTimer = setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                if (isPesable) {
                    (yield this.codigoService.onGetCodigoPorCodigo(codigo)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe(codigoRes => {
                        var _a, _b, _c;
                        console.log(codigoRes);
                        if (codigoRes.length == 1) {
                            this.onPresentacionClick((_a = codigoRes[0]) === null || _a === void 0 ? void 0 : _a.presentacion, (_c = (_b = codigoRes[0]) === null || _b === void 0 ? void 0 : _b.presentacion) === null || _c === void 0 ? void 0 : _c.producto, peso);
                        }
                    });
                }
                else {
                    (yield this.productoService.onSearch(text, offset)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe((res) => {
                        if (offset == null) {
                            this.productosList = res;
                            // this.isSearchingList = new Array(this.isSearchingList.length)
                            this.showCargarMas = true;
                        }
                        else {
                            if ((res === null || res === void 0 ? void 0 : res.length) > 0)
                                this.showCargarMas = true;
                            const arr = [...this.productosList.concat(res)];
                            this.productosList = arr;
                            // this.isSearchingList = new Array(this.isSearchingList.length)
                        }
                        this.isSearching = false;
                    });
                }
            }), 1000);
        }
    }
    onAvatarClick(image) {
        // this.popoverService.open(ImagePopoverComponent, {
        //   image
        // }, PopoverSize.MD)
        this.photoViewer.show(image, '');
    }
    onMasProductos() {
        var _a;
        this.showCargarMas = false;
        this.onSearchProducto(this.buscarControl.value, (_a = this.productosList) === null || _a === void 0 ? void 0 : _a.length);
    }
    onProductoClick(producto, index) {
        var _a, _b, _c, _d;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            if ((producto === null || producto === void 0 ? void 0 : producto.presentaciones) == null) {
                (yield this.productoService.getProducto(producto.id)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe((res) => {
                    console.log(res);
                    this.productosList[index].presentaciones = res.presentaciones;
                });
            }
            if (((_b = (_a = this.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.sucursalId) != null && (producto === null || producto === void 0 ? void 0 : producto.stockPorProducto) == null) {
                this.isSearchingList[index] = true;
                (yield this.productoService.onGetStockPorSucursal(producto.id, (_d = (_c = this.data) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.sucursalId)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this)).subscribe(res => {
                    this.isSearchingList[index] = false;
                    console.log(res);
                    if (res != null) {
                        setTimeout(() => {
                            this.productosList[index].stockPorProducto = res;
                        }, 2000);
                    }
                });
            }
        });
    }
    onPresentacionClick(presentacion, producto, peso) {
        // this.dialogService.open('Atención', `Seleccionaste el producto ${producto.descripcion} con la presentacion de ${presentacion.cantidad} unidades.`)
        //   .then(res => {
        //     if (res.role == 'aceptar') {
        //     }
        //   })
        this.modalService.closeModal({ presentacion: presentacion, producto: producto, peso: peso });
    }
    onBack() {
        var _a;
        if (((_a = this.modalService) === null || _a === void 0 ? void 0 : _a.currentModal) != null) {
            this.modalService.closeModal(null);
        }
        else {
            this._location.back();
        }
    }
    onCameraClick() {
        this.barcodeScanner.scan().then(barcodeData => {
            this.buscarControl.setValue(barcodeData.text);
            this.onSearchProducto(this.buscarControl.value, null);
        });
    }
};
SearchProductoDialogComponent.ctorParameters = () => [
    { type: _producto_service__WEBPACK_IMPORTED_MODULE_6__.ProductoService },
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_5__.PopOverService },
    { type: _services_modal_service__WEBPACK_IMPORTED_MODULE_4__.ModalService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_3__.DialogoService },
    { type: _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_13__.Location },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.Platform },
    { type: _codigo_codigo_service__WEBPACK_IMPORTED_MODULE_7__.CodigoService },
    { type: _awesome_cordova_plugins_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__.PhotoViewer }
];
SearchProductoDialogComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.Input }]
};
SearchProductoDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: 'app-search-producto-dialog',
        template: _search_producto_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner, _awesome_cordova_plugins_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__.PhotoViewer],
        styles: [_search_producto_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SearchProductoDialogComponent);



/***/ }),

/***/ 70738:
/*!************************************************!*\
  !*** ./src/app/pages/salir/salir.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalirComponent": () => (/* binding */ SalirComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _salir_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./salir.component.html?ngResource */ 39450);
/* harmony import */ var _salir_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./salir.component.scss?ngResource */ 23987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let SalirComponent = class SalirComponent {
    constructor() { }
    ngOnInit() { }
};
SalirComponent.ctorParameters = () => [];
SalirComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-salir',
        template: _salir_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_salir_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SalirComponent);



/***/ }),

/***/ 69848:
/*!*********************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/deleteTransferencia.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteTransferenciaGQL": () => (/* binding */ DeleteTransferenciaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let DeleteTransferenciaGQL = class DeleteTransferenciaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteTransferenciaQuery;
    }
};
DeleteTransferenciaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteTransferenciaGQL);



/***/ }),

/***/ 30660:
/*!*************************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/deleteTransferenciaItem.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteTransferenciaItemGQL": () => (/* binding */ DeleteTransferenciaItemGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let DeleteTransferenciaItemGQL = class DeleteTransferenciaItemGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.deleteTransferenciaItemQuery;
    }
};
DeleteTransferenciaItemGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], DeleteTransferenciaItemGQL);



/***/ }),

/***/ 9934:
/*!************************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/finalizarTransferencia.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FinalizarTransferenciaGQL": () => (/* binding */ FinalizarTransferenciaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let FinalizarTransferenciaGQL = class FinalizarTransferenciaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.finalizarTransferencia;
    }
};
FinalizarTransferenciaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], FinalizarTransferenciaGQL);



/***/ }),

/***/ 34493:
/*!******************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/getTransferencia.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetTransferenciaGQL": () => (/* binding */ GetTransferenciaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let GetTransferenciaGQL = class GetTransferenciaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.transferenciaQuery;
    }
};
GetTransferenciaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetTransferenciaGQL);



/***/ }),

/***/ 67479:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/getTransferenciaItensPorTransferenciaId.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetTransferenciaItensPorTransferenciaIdGQL": () => (/* binding */ GetTransferenciaItensPorTransferenciaIdGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let GetTransferenciaItensPorTransferenciaIdGQL = class GetTransferenciaItensPorTransferenciaIdGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.transferenciaItemPorTransferenciaIdQuery;
    }
};
GetTransferenciaItensPorTransferenciaIdGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetTransferenciaItensPorTransferenciaIdGQL);



/***/ }),

/***/ 64344:
/*!**************************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/getTransferenciaPorFecha.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetTransferenciaPorFechaGQL": () => (/* binding */ GetTransferenciaPorFechaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let GetTransferenciaPorFechaGQL = class GetTransferenciaPorFechaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.transferenciaPorFechaQuery;
    }
};
GetTransferenciaPorFechaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetTransferenciaPorFechaGQL);



/***/ }),

/***/ 1240:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/getTransferenciasPorUsuario.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetTransferenciasPorUsuarioGQL": () => (/* binding */ GetTransferenciasPorUsuarioGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let GetTransferenciasPorUsuarioGQL = class GetTransferenciasPorUsuarioGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Query {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.transferenciasPorUsuarioQuery;
    }
};
GetTransferenciasPorUsuarioGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], GetTransferenciasPorUsuarioGQL);



/***/ }),

/***/ 63302:
/*!***************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/graphql-query.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deleteTransferenciaItemDetalleQuery": () => (/* binding */ deleteTransferenciaItemDetalleQuery),
/* harmony export */   "deleteTransferenciaItemQuery": () => (/* binding */ deleteTransferenciaItemQuery),
/* harmony export */   "deleteTransferenciaQuery": () => (/* binding */ deleteTransferenciaQuery),
/* harmony export */   "finalizarTransferencia": () => (/* binding */ finalizarTransferencia),
/* harmony export */   "imprimirTransferencia": () => (/* binding */ imprimirTransferencia),
/* harmony export */   "prepararTransferencia": () => (/* binding */ prepararTransferencia),
/* harmony export */   "saveTransferencia": () => (/* binding */ saveTransferencia),
/* harmony export */   "saveTransferenciaItem": () => (/* binding */ saveTransferenciaItem),
/* harmony export */   "saveTransferenciaItemDetalle": () => (/* binding */ saveTransferenciaItemDetalle),
/* harmony export */   "transferenciaItemPorTransferenciaIdQuery": () => (/* binding */ transferenciaItemPorTransferenciaIdQuery),
/* harmony export */   "transferenciaPorFechaQuery": () => (/* binding */ transferenciaPorFechaQuery),
/* harmony export */   "transferenciaQuery": () => (/* binding */ transferenciaQuery),
/* harmony export */   "transferenciasPorUsuarioQuery": () => (/* binding */ transferenciasPorUsuarioQuery),
/* harmony export */   "transferenciasQuery": () => (/* binding */ transferenciasQuery)
/* harmony export */ });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-tag */ 16804);

const transferenciasQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  {
    data: transferencias {
      id
      sucursalOrigen {
        id
        nombre
      }
      sucursalDestino {
        id
        nombre
      }
      isOrigen
      isDestino
      tipo
      estado
      etapa
      observacion
      creadoEn
      usuarioPreTransferencia {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const transferenciaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: transferencia(id: $id) {
      id
      sucursalOrigen {
        id
        nombre
      }
      sucursalDestino {
        id
        nombre
      }
      isOrigen
      isDestino
      tipo
      estado
      etapa
      observacion
      creadoEn
      usuarioPreTransferencia {
        id
        persona {
          nombre
        }
      }
      usuarioPreparacion {
        id
        persona {
          nombre
        }
      }
      usuarioTransporte {
        id
        persona {
          nombre
        }
      }
      usuarioRecepcion {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const saveTransferencia = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveTransferencia($entity: TransferenciaInput!) {
    data: saveTransferencia(transferencia: $entity) {
      id
      sucursalOrigen {
        id
        nombre
      }
      sucursalDestino {
        id
        nombre
      }
      isOrigen
      isDestino
      tipo
      estado
      etapa
      observacion
      creadoEn
      usuarioPreTransferencia {
        id
        persona {
          nombre
        }
      }
      usuarioPreparacion {
        id
        persona {
          nombre
        }
      }
      usuarioTransporte {
        id
        persona {
          nombre
        }
      }
      usuarioRecepcion {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const deleteTransferenciaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteTransferencia($id: ID!) {
    deleteTransferencia(id: $id)
  }
`;
const transferenciaPorFechaQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($inicio: String, $fin: String) {
    data: transferenciaPorFecha(inicio: $inicio, fin: $fin) {
      id
      sucursalOrigen {
        id
        nombre
      }
      sucursalDestino {
        id
        nombre
      }
      isOrigen
      isDestino
      tipo
      estado
      etapa
      observacion
      creadoEn
      usuarioPreTransferencia {
        id
        persona {
          nombre
        }
      }
      usuarioPreparacion {
        id
        persona {
          nombre
        }
      }
      usuarioTransporte {
        id
        persona {
          nombre
        }
      }
      usuarioRecepcion {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const finalizarTransferencia = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation finalizarTransferencia($id: ID!, $usuarioId: ID!) {
    finalizarTransferencia(id: $id, usuarioId: $usuarioId)
  }
`;
const prepararTransferencia = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation avanzarEtapaTransferencia($id: ID!, $etapa: EtapaTransferencia!, $usuarioId: ID!) {
    avanzarEtapaTransferencia(id: $id, etapa: $etapa, usuarioId: $usuarioId)
  }
`;
const imprimirTransferencia = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query imprimirTransferencia($id: ID!) {
    imprimirTransferencia(id: $id)
  }
`;
const saveTransferenciaItem = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveTransferenciaItem($entity: TransferenciaItemInput!) {
    data: saveTransferenciaItem(transferenciaItem: $entity) {
      id
        transferencia {
          id
        }
        presentacionPreTransferencia {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        presentacionPreparacion {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        presentacionTransporte {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        presentacionRecepcion {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        cantidadPreTransferencia
        cantidadPreparacion
        cantidadTransporte
        cantidadRecepcion
        observacionPreTransferencia
        observacionPreparacion
        observacionTransporte
        observacionRecepcion
        vencimientoPreTransferencia
        vencimientoPreparacion
        vencimientoTransporte
        vencimientoRecepcion
        motivoModificacionPreTransferencia
        motivoModificacionPreparacion
        motivoModificacionTransporte
        motivoModificacionRecepcion
        motivoRechazoPreTransferencia
        motivoRechazoPreparacion
        motivoRechazoTransporte
        motivoRechazoRecepcion
        activo
        poseeVencimiento
        usuario {
          id
          persona {
            nombre
          }
        }
        creadoEn
    }
  }
`;
const deleteTransferenciaItemQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteTransferenciaItem($id: ID!) {
    deleteTransferenciaItem(id: $id)
  }
`;
const saveTransferenciaItemDetalle = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation saveTransferenciaItemDetalle($entity: TransferenciaItemDetalleInput!) {
    data: saveTransferenciaItemDetalle(transferenciaItemDetalle: $entity) {
      id
        transferencia {
          id
        }
        presentacionPreTransferencia {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        presentacionPreparacion {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        presentacionTransporte {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        presentacionRecepcion {
          id
          producto {
            id
            descripcion
            codigoPrincipal
            costo {
              costoMedio
              ultimoPrecioCompra
            }
          }
          cantidad
          imagenPrincipal
          precioPrincipal {
            precio
          }
        }
        cantidadPreTransferencia
        cantidadPreparacion
        cantidadTransporte
        cantidadRecepcion
        observacionPreTransferencia
        observacionPreparacion
        observacionTransporte
        observacionRecepcion
        vencimientoPreTransferencia
        vencimientoPreparacion
        vencimientoTransporte
        vencimientoRecepcion
        motivoModificacionPreTransferencia
        motivoModificacionPreparacion
        motivoModificacionTransporte
        motivoModificacionRecepcion
        motivoRechazoPreTransferencia
        motivoRechazoPreparacion
        motivoRechazoTransporte
        motivoRechazoRecepcion
        activo
        poseeVencimiento
        usuario {
          id
          persona {
            nombre
          }
        }
        creadoEn
    }
  }
`;
const deleteTransferenciaItemDetalleQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  mutation deleteTransferenciaItemDetalle($id: ID!) {
    deleteTransferenciaItemDetalle(id: $id)
  }
`;
const transferenciasPorUsuarioQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!) {
    data: transferenciasPorUsuario(id: $id) {
      id
      sucursalOrigen {
        id
        nombre
      }
      sucursalDestino {
        id
        nombre
      }
      isOrigen
      isDestino
      tipo
      estado
      etapa
      observacion
      creadoEn
      usuarioPreTransferencia {
        id
        persona {
          nombre
        }
      }
    }
  }
`;
const transferenciaItemPorTransferenciaIdQuery = graphql_tag__WEBPACK_IMPORTED_MODULE_0__["default"] `
  query ($id: ID!, $page: Int, $size: Int) {
    data: transferenciaItensPorTransferenciaId(id: $id, page: $page, size: $size) {
      id
      transferencia {
        id
      }
      presentacionPreTransferencia {
        id
        producto {
          id
          descripcion
          codigoPrincipal
          costo {
            costoMedio
            ultimoPrecioCompra
          }
        }
        cantidad
        imagenPrincipal
        precioPrincipal {
          precio
        }
      }
      presentacionPreparacion {
        id
        producto {
          id
          descripcion
          codigoPrincipal
          costo {
            costoMedio
            ultimoPrecioCompra
          }
        }
        cantidad
        imagenPrincipal
        precioPrincipal {
          precio
        }
      }
      presentacionTransporte {
        id
        producto {
          id
          descripcion
          codigoPrincipal
          costo {
            costoMedio
            ultimoPrecioCompra
          }
        }
        cantidad
        imagenPrincipal
        precioPrincipal {
          precio
        }
      }
      presentacionRecepcion {
        id
        producto {
          id
          descripcion
          codigoPrincipal
          costo {
            costoMedio
            ultimoPrecioCompra
          }
        }
        cantidad
        imagenPrincipal
        precioPrincipal {
          precio
        }
      }
      cantidadPreTransferencia
      cantidadPreparacion
      cantidadTransporte
      cantidadRecepcion
      observacionPreTransferencia
      observacionPreparacion
      observacionTransporte
      observacionRecepcion
      vencimientoPreTransferencia
      vencimientoPreparacion
      vencimientoTransporte
      vencimientoRecepcion
      motivoModificacionPreTransferencia
      motivoModificacionPreparacion
      motivoModificacionTransporte
      motivoModificacionRecepcion
      motivoRechazoPreTransferencia
      motivoRechazoPreparacion
      motivoRechazoTransporte
      motivoRechazoRecepcion
      activo
      poseeVencimiento
      creadoEn
    }
  }
`;


/***/ }),

/***/ 39830:
/*!***********************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/prepararTransferencia.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrepararTransferenciaGQL": () => (/* binding */ PrepararTransferenciaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let PrepararTransferenciaGQL = class PrepararTransferenciaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.prepararTransferencia;
    }
};
PrepararTransferenciaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], PrepararTransferenciaGQL);



/***/ }),

/***/ 49716:
/*!*******************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/saveTransferencia.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveTransferenciaGQL": () => (/* binding */ SaveTransferenciaGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let SaveTransferenciaGQL = class SaveTransferenciaGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveTransferencia;
    }
};
SaveTransferenciaGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveTransferenciaGQL);



/***/ }),

/***/ 86296:
/*!***********************************************************************!*\
  !*** ./src/app/pages/transferencias/graphql/saveTransferenciaItem.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveTransferenciaItemGQL": () => (/* binding */ SaveTransferenciaItemGQL)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-angular */ 89858);
/* harmony import */ var _graphql_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql-query */ 63302);




let SaveTransferenciaItemGQL = class SaveTransferenciaItemGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_1__.Mutation {
    constructor() {
        super(...arguments);
        this.document = _graphql_query__WEBPACK_IMPORTED_MODULE_0__.saveTransferenciaItem;
    }
};
SaveTransferenciaItemGQL = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], SaveTransferenciaItemGQL);



/***/ }),

/***/ 39242:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/transferencias/info-transferencia/info-transferencia.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InfoTransferenciaComponent": () => (/* binding */ InfoTransferenciaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _info_transferencia_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./info-transferencia.component.html?ngResource */ 13754);
/* harmony import */ var _info_transferencia_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./info-transferencia.component.scss?ngResource */ 18998);
/* harmony import */ var _components_image_popover_image_popover_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../components/image-popover/image-popover.component */ 23254);
/* harmony import */ var _modificar_item_dialog_modificar_item_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../modificar-item-dialog/modificar-item-dialog.component */ 9753);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../services/pop-over.service */ 21690);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _transferencia_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../transferencia.service */ 67240);
/* harmony import */ var _transferencia_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../transferencia.model */ 38370);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/menu-action.service */ 47257);
/* harmony import */ var src_app_generic_utils_numbersUtils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/generic/utils/numbersUtils */ 37867);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/cargando.service */ 68030);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/domains/enums/tipo-entidad.enum */ 61246);
/* harmony import */ var _codigo_codigo_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../codigo/codigo.service */ 75130);
/* harmony import */ var src_app_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/generic/utils/qrUtils */ 83503);
/* harmony import */ var src_app_components_qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/components/qr-generator/qr-generator.component */ 45713);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
























let InfoTransferenciaComponent = class InfoTransferenciaComponent {
    constructor(transferenciaService, route, _location, mainService, menuActionService, popoverService, barcodeScanner, cargandoService, plf, notificacionService, codigoService, dialogoService) {
        this.transferenciaService = transferenciaService;
        this.route = route;
        this._location = _location;
        this.mainService = mainService;
        this.menuActionService = menuActionService;
        this.popoverService = popoverService;
        this.barcodeScanner = barcodeScanner;
        this.cargandoService = cargandoService;
        this.plf = plf;
        this.notificacionService = notificacionService;
        this.codigoService = codigoService;
        this.dialogoService = dialogoService;
        this.isWeb = false;
        this.page = 0;
        this.size = 10;
        this.isLastPage = false;
        this.isPreTransferenciaCreacion = false;
        this.isPreTransferenciaOrigen = false;
        this.isPreparacionMercaderia = false;
        this.isPreparacionMercaderiaConcluida = false;
        this.isTransporteVerificacion = false;
        this.isTransporteEnCamino = false;
        this.isTransporteEnDestino = false;
        this.isRecepcionEnVerificacion = false;
        this.isRecepcionConcluida = false;
        this.isAllConfirmedPreparacion = false;
        this.isAllConfirmedTransporte = false;
        this.isAllConfirmedRecepcion = false;
        this.puedeEditar = false;
        this.isWeb = this.plf.platforms().includes('mobileweb');
    }
    ngOnInit() {
        //innicializar arrays
        this.actionMenuOptionsList = [];
        setTimeout(() => {
            this.route.paramMap.subscribe(res => {
                console.log(res);
                this.buscarTransferencia(res.get('id'));
            });
        }, 1000);
    }
    buscarTransferencia(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            console.log(id);
            if (id != null) {
                (yield this.transferenciaService.onGetTransferencia(id))
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                    .subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                    console.log(res);
                    if (res != null) {
                        this.selectedTransferencia = res;
                        this.selectedTransferencia.transferenciaItemList = [];
                        this.verificarEtapa();
                    }
                }));
            }
        });
    }
    getTransferenciaItemList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            return new Promise((resolve, rejects) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                (yield this.transferenciaService.onGetTransferenciaItensPorTransferenciaId(this.selectedTransferencia.id)).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                    .subscribe(res => {
                    if (res != null) {
                        if (res.length < this.size) {
                            this.isLastPage = true;
                        }
                        if (this.selectedTransferencia.transferenciaItemList.length == 0) {
                            this.selectedTransferencia.transferenciaItemList = res;
                        }
                        else {
                            this.selectedTransferencia.transferenciaItemList.concat(res);
                        }
                        return resolve(true);
                    }
                    else {
                        return resolve(false);
                    }
                });
            }));
        });
    }
    onBack() {
        this._location.back();
    }
    verificarEtapa() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            this.setAllEtapasFalse();
            switch ((_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.etapa) {
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PRE_TRANSFERENCIA_CREACION:
                    this.isPreTransferenciaCreacion = true;
                    this.selectedResponsable = (_b = this.selectedTransferencia) === null || _b === void 0 ? void 0 : _b.usuarioPreTransferencia;
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PRE_TRANSFERENCIA_ORIGEN:
                    this.isPreTransferenciaOrigen = true;
                    this.selectedResponsable = (_c = this.selectedTransferencia) === null || _c === void 0 ? void 0 : _c.usuarioPreTransferencia;
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA:
                    this.isPreparacionMercaderia = true;
                    this.selectedResponsable = (_d = this.selectedTransferencia) === null || _d === void 0 ? void 0 : _d.usuarioPreparacion;
                    this.actionMenuOptionsList = [
                        { texto: 'Verificar', role: 'verificar' },
                        { texto: 'Confirmar', role: 'confirmar' },
                        { texto: 'Desconfirmar', role: 'desconfirmar' },
                        { texto: 'Modif. cantidad', role: 'cantidad' },
                        { texto: 'Modif. vencimiento', role: 'vencimiento' },
                        { texto: 'Rechazar', role: 'rechazar' }
                    ];
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA_CONCLUIDA:
                    this.selectedResponsable = (_e = this.selectedTransferencia) === null || _e === void 0 ? void 0 : _e.usuarioPreparacion;
                    this.isPreparacionMercaderiaConcluida = true;
                    this.actionMenuOptionsList = [];
                    this.selectedTransferencia.transferenciaItemList = this.selectedTransferencia.transferenciaItemList.filter(i => i.motivoRechazoPreparacion == null);
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION:
                    this.isTransporteVerificacion = true;
                    this.selectedResponsable = (_f = this.selectedTransferencia) === null || _f === void 0 ? void 0 : _f.usuarioTransporte;
                    this.actionMenuOptionsList = [
                        { texto: 'Verificar', role: 'verificar' },
                        { texto: 'Confirmar', role: 'confirmar' },
                        { texto: 'Desconfirmar', role: 'desconfirmar' },
                        { texto: 'Rechazar', role: 'rechazar' },
                    ];
                    this.selectedTransferencia.transferenciaItemList = this.selectedTransferencia.transferenciaItemList.filter(i => i.motivoRechazoPreparacion == null);
                    if (((_g = this.selectedTransferencia.usuarioPreparacion) === null || _g === void 0 ? void 0 : _g.id) == ((_h = this.mainService.usuarioActual) === null || _h === void 0 ? void 0 : _h.id)) {
                        this.dialogoService.open('Atención!!', 'Desea confirmar todos los itens automaticamente?').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                            if (res.role == 'aceptar') {
                                let isLoaded = yield this.getTransferenciaItemList();
                                if (isLoaded) {
                                    let cargando = this.cargandoService.open(null, false);
                                    this.selectedTransferencia.transferenciaItemList.forEach(item => {
                                        if (item.cantidadPreparacion > 0 && item.presentacionPreparacion != null) {
                                            this.onConfirm(item);
                                        }
                                    });
                                    this.cargandoService.close(yield cargando);
                                    yield this.notificacionService.success('Itens confirmados con éxito!!');
                                }
                            }
                        }));
                    }
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_EN_CAMINO:
                    this.selectedResponsable = (_j = this.selectedTransferencia) === null || _j === void 0 ? void 0 : _j.usuarioTransporte;
                    this.isTransporteEnCamino = true;
                    this.actionMenuOptionsList = [];
                    this.selectedTransferencia.transferenciaItemList = this.selectedTransferencia.transferenciaItemList.filter(i => i.motivoRechazoPreparacion == null && i.motivoRechazoTransporte == null);
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_EN_DESTINO:
                    this.isTransporteEnDestino = true;
                    this.selectedResponsable = (_k = this.selectedTransferencia) === null || _k === void 0 ? void 0 : _k.usuarioRecepcion;
                    this.actionMenuOptionsList = [];
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION:
                    this.isRecepcionEnVerificacion = true;
                    this.selectedResponsable = (_l = this.selectedTransferencia) === null || _l === void 0 ? void 0 : _l.usuarioRecepcion;
                    this.actionMenuOptionsList = [
                        { texto: 'Verificar', role: 'verificar' },
                        { texto: 'Confirmar', role: 'confirmar' },
                        { texto: 'Desconfirmar', role: 'desconfirmar' },
                        { texto: 'Rechazar', role: 'rechazar' },
                    ];
                    this.selectedTransferencia.transferenciaItemList = this.selectedTransferencia.transferenciaItemList.filter(i => i.motivoRechazoPreparacion == null && i.motivoRechazoTransporte == null);
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_CONCLUIDA:
                    this.isRecepcionConcluida = true;
                    this.selectedResponsable = (_m = this.selectedTransferencia) === null || _m === void 0 ? void 0 : _m.usuarioRecepcion;
                    this.actionMenuOptionsList = [];
                    break;
                default:
                    break;
            }
            if (this.selectedResponsable.id == this.mainService.usuarioActual.id || this.selectedResponsable.id == null) {
                this.puedeEditar = true;
            }
            let isItemLoaded = yield this.getTransferenciaItemList();
            if (isItemLoaded) {
                this.onVerificarConfirmados();
            }
        });
    }
    setAllEtapasFalse() {
        this.isPreTransferenciaCreacion = false;
        this.isPreTransferenciaOrigen = false;
        this.isPreparacionMercaderia = false;
        this.isPreparacionMercaderiaConcluida = false;
        this.isTransporteVerificacion = false;
        this.isTransporteEnCamino = false;
        this.isTransporteEnDestino = false;
        this.isRecepcionEnVerificacion = false;
        this.isRecepcionConcluida = false;
    }
    onVerificarConfirmados() {
        var _a;
        let okPreparacion = true;
        let okTransporte = true;
        let okRecepcion = true;
        (_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.transferenciaItemList.find(i => {
            if (this.selectedTransferencia.etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA && i.cantidadPreparacion == null && i.vencimientoPreparacion == null && i.motivoRechazoPreparacion == null) {
                okPreparacion = false;
            }
            else if (this.selectedTransferencia.etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION && i.cantidadTransporte == null && i.vencimientoTransporte == null && i.motivoRechazoTransporte == null) {
                okTransporte = false;
            }
            else if (this.selectedTransferencia.etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION && i.cantidadRecepcion == null && i.vencimientoRecepcion == null && i.motivoRechazoRecepcion == null) {
                okRecepcion = false;
                console.log('es falso');
            }
        });
        this.isAllConfirmedPreparacion = okPreparacion;
        this.isAllConfirmedTransporte = okTransporte;
        this.isAllConfirmedRecepcion = okRecepcion;
    }
    onItemPress(item) {
        this.actionMenuOptionsList.length > 0 ? this.menuActionService.presentActionSheet(this.actionMenuOptionsList).then(res => {
            let role = res.role;
            switch (role) {
                case 'verificar':
                    this.onVerificarProducto(item);
                    break;
                case 'confirmar':
                    this.onConfirm(item);
                    break;
                case 'desconfirmar':
                    this.onDesconfirm(item);
                    break;
                case 'cantidad':
                    this.onModifCantidad(item);
                    break;
                case 'vencimiento':
                    this.onModifVencimiento(item);
                    break;
                case 'rechazar':
                    this.onRechazar(item);
                    break;
                default:
                    break;
            }
        }) : null;
    }
    onAvanzarEtapa(etapa) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            let ok = true;
            if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
                ok = yield this.onVerificarSucursal();
            }
            ok ? this.transferenciaService.onAvanzarEtapa(this.selectedTransferencia, etapa)
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                .subscribe(res => {
                if (res) {
                    this.selectedTransferencia.etapa = etapa;
                    if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION) {
                        this.selectedTransferencia.usuarioTransporte = this.mainService.usuarioActual;
                    }
                    else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA) {
                        this.selectedTransferencia.usuarioPreparacion = this.mainService.usuarioActual;
                    }
                    else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PRE_TRANSFERENCIA_ORIGEN) {
                        this.selectedTransferencia.estado = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaEstado.EN_ORIGEN;
                    }
                    else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_EN_CAMINO) {
                        this.selectedTransferencia.estado = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaEstado.EN_TRANSITO;
                    }
                    else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
                        this.selectedTransferencia.estado = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaEstado.EN_DESTINO;
                        this.selectedTransferencia.usuarioRecepcion = this.mainService.usuarioActual;
                    }
                    this.verificarEtapa();
                }
            })
                :
                    null;
        });
    }
    onConfirm(item) {
        var _a, _b, _c;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            let newItem = new _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItem;
            item = Object.assign(newItem, item);
            if (((_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA) {
                item.cantidadPreparacion = item.cantidadPreTransferencia;
                item.presentacionPreparacion = item.presentacionPreTransferencia;
                item.vencimientoPreparacion = item === null || item === void 0 ? void 0 : item.vencimientoPreTransferencia;
                item.motivoModificacionPreparacion = null;
                item.motivoRechazoPreparacion = null;
            }
            else if (((_b = this.selectedTransferencia) === null || _b === void 0 ? void 0 : _b.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION) {
                item.cantidadTransporte = item.cantidadPreparacion;
                item.presentacionTransporte = item.presentacionPreparacion;
                item.vencimientoTransporte = item === null || item === void 0 ? void 0 : item.vencimientoPreparacion;
                item.motivoModificacionTransporte = null;
                item.motivoRechazoTransporte = null;
            }
            else if (((_c = this.selectedTransferencia) === null || _c === void 0 ? void 0 : _c.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
                item.cantidadRecepcion = item.cantidadTransporte;
                item.presentacionRecepcion = item.presentacionTransporte;
                item.vencimientoRecepcion = item === null || item === void 0 ? void 0 : item.vencimientoTransporte;
                item.motivoModificacionRecepcion = null;
                item.motivoRechazoRecepcion = null;
            }
            (yield this.transferenciaService.onSaveTransferenciaItem(item.toInput()))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    let index = this.selectedTransferencia.transferenciaItemList.findIndex(i => i.id == res.id);
                    this.selectedTransferencia.transferenciaItemList.splice(index, 1);
                }
                this.onVerificarConfirmados();
            });
        });
    }
    onDesconfirm(item) {
        var _a, _b, _c;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            let newItem = new _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItem;
            item = Object.assign(newItem, item);
            if (((_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA) {
                item.cantidadPreparacion = null;
                item.presentacionPreparacion = null;
                item.vencimientoPreparacion = null;
                item.motivoModificacionPreparacion = null;
                item.motivoRechazoPreparacion = null;
            }
            else if (((_b = this.selectedTransferencia) === null || _b === void 0 ? void 0 : _b.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION) {
                item.cantidadTransporte = null;
                item.presentacionTransporte = null;
                item.vencimientoTransporte = null;
                item.motivoModificacionTransporte = null;
                item.motivoRechazoTransporte = null;
            }
            else if (((_c = this.selectedTransferencia) === null || _c === void 0 ? void 0 : _c.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
                item.cantidadRecepcion = null;
                item.presentacionRecepcion = null;
                item.vencimientoRecepcion = null;
                item.motivoModificacionRecepcion = null;
                item.motivoRechazoRecepcion = null;
            }
            (yield this.transferenciaService.onSaveTransferenciaItem(item.toInput()))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.selectedTransferencia.transferenciaItemList = (0,src_app_generic_utils_numbersUtils__WEBPACK_IMPORTED_MODULE_9__.updateDataSourceWithId)(this.selectedTransferencia.transferenciaItemList, item, item.id);
                }
                this.onVerificarConfirmados();
            });
        });
    }
    onRechazar(item) {
        let newItem = new _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItem;
        item = Object.assign(newItem, item);
        this.menuActionService.presentActionSheet([
            { texto: 'Falta de producto', role: _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoRechazo.FALTA_PRODUCTO },
            { texto: 'Producto averiado', role: _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoRechazo.PRODUCTO_AVERIADO },
            { texto: 'Producto equivocado', role: _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoRechazo.PRODUCTO_EQUIVOCADO },
            { texto: 'Producto vencido', role: _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoRechazo.PRODUCTO_VENCIDO },
        ]).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            switch (this.selectedTransferencia.etapa) {
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA:
                    item.cantidadPreparacion = null;
                    item.motivoModificacionPreparacion = null;
                    item.vencimientoPreparacion = null;
                    item.motivoRechazoPreparacion = res.role;
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION:
                    item.cantidadTransporte = null;
                    item.motivoModificacionTransporte = null;
                    item.vencimientoTransporte = null;
                    item.motivoRechazoTransporte = res.role;
                    break;
                case _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION:
                    item.cantidadRecepcion = null;
                    item.motivoModificacionRecepcion = null;
                    item.vencimientoRecepcion = null;
                    item.motivoRechazoRecepcion = res.role;
                    break;
                default:
                    break;
            }
            (yield this.transferenciaService.onSaveTransferenciaItem(item.toInput()))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.selectedTransferencia.transferenciaItemList = (0,src_app_generic_utils_numbersUtils__WEBPACK_IMPORTED_MODULE_9__.updateDataSourceWithId)(this.selectedTransferencia.transferenciaItemList, item, item.id);
                }
                this.onVerificarConfirmados();
            });
        }));
    }
    onModifCantidad(item) {
        this.onModificarItem(item, true, false);
    }
    onModifVencimiento(item) {
        this.onModificarItem(item, false, true);
    }
    onModificarItem(item, isCantidad, isVencimiento) {
        let newItem = new _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItem;
        item = Object.assign(newItem, item);
        this.popoverService.open(_modificar_item_dialog_modificar_item_dialog_component__WEBPACK_IMPORTED_MODULE_3__.ModificarItemDialogComponent, {
            isCantidad,
            isVencimiento,
        }, _services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopoverSize.XS).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
            if (res.data != null) {
                if (isCantidad) {
                    if (((_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA) {
                        item.presentacionPreparacion = item.presentacionPreTransferencia;
                        item.vencimientoPreparacion = item.vencimientoPreTransferencia;
                        item.cantidadPreparacion = (_b = res.data) === null || _b === void 0 ? void 0 : _b.cantidad;
                        item.motivoModificacionPreparacion = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoModificacion.CANTIDAD_INCORRECTA;
                    }
                    else if (((_c = this.selectedTransferencia) === null || _c === void 0 ? void 0 : _c.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION) {
                        item.cantidadTransporte = (_d = res.data) === null || _d === void 0 ? void 0 : _d.cantidad;
                        item.vencimientoTransporte = item.vencimientoPreparacion;
                        item.presentacionTransporte = item.presentacionPreparacion;
                        item.motivoModificacionTransporte = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoModificacion.CANTIDAD_INCORRECTA;
                    }
                    else if (((_e = this.selectedTransferencia) === null || _e === void 0 ? void 0 : _e.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
                        item.cantidadRecepcion = (_f = res.data) === null || _f === void 0 ? void 0 : _f.cantidad;
                        item.vencimientoRecepcion = item.vencimientoTransporte;
                        item.presentacionRecepcion = item.presentacionTransporte;
                        item.motivoModificacionRecepcion = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoModificacion.CANTIDAD_INCORRECTA;
                    }
                }
                else if (isVencimiento) {
                    if (((_g = this.selectedTransferencia) === null || _g === void 0 ? void 0 : _g.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.PREPARACION_MERCADERIA) {
                        item.vencimientoPreparacion = (_h = res.data) === null || _h === void 0 ? void 0 : _h.vencimiento;
                        item.presentacionPreparacion = item.presentacionPreTransferencia;
                        item.cantidadPreparacion = item.cantidadPreTransferencia;
                        item.motivoModificacionPreparacion = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoModificacion.VENCIMIENTO_INCORRECTO;
                    }
                    else if (((_j = this.selectedTransferencia) === null || _j === void 0 ? void 0 : _j.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.TRANSPORTE_VERIFICACION) {
                        item.vencimientoTransporte = (_k = res.data) === null || _k === void 0 ? void 0 : _k.vencimiento;
                        item.presentacionTransporte = item.presentacionPreparacion;
                        item.cantidadTransporte = item.cantidadPreparacion;
                        item.motivoModificacionTransporte = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoModificacion.VENCIMIENTO_INCORRECTO;
                    }
                    else if (((_l = this.selectedTransferencia) === null || _l === void 0 ? void 0 : _l.etapa) == _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
                        item.vencimientoRecepcion = (_m = res.data) === null || _m === void 0 ? void 0 : _m.vencimiento;
                        item.presentacionRecepcion = item.presentacionTransporte;
                        item.cantidadRecepcion = item.cantidadTransporte;
                        item.motivoModificacionRecepcion = _transferencia_model__WEBPACK_IMPORTED_MODULE_7__.TransferenciaItemMotivoModificacion.VENCIMIENTO_INCORRECTO;
                    }
                }
                (yield this.transferenciaService.onSaveTransferenciaItem(item.toInput()))
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.untilDestroyed)(this))
                    .subscribe(res => {
                    if (res != null) {
                        this.selectedTransferencia.transferenciaItemList = (0,src_app_generic_utils_numbersUtils__WEBPACK_IMPORTED_MODULE_9__.updateDataSourceWithId)(this.selectedTransferencia.transferenciaItemList, res, res.id);
                    }
                    this.onVerificarConfirmados();
                });
            }
        }));
    }
    onAvatarClick(image) {
        this.popoverService.open(_components_image_popover_image_popover_component__WEBPACK_IMPORTED_MODULE_2__.ImagePopoverComponent, {
            image
        }, _services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopoverSize.MD);
    }
    onVerificarSucursal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open('Abriendo camara...');
            setTimeout(() => {
                this.cargandoService.close(loading);
            }, 1000);
            return this.barcodeScanner.scan().then((barcodeData) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                var _a, _b;
                this.notificacionService.open('Escaneado con éxito!', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_12__.TipoNotificacion.SUCCESS, 1);
                let codigo = barcodeData.text;
                let arr = codigo.split('-');
                let prefix = arr[2];
                let sucId = +arr[1];
                if (prefix == src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_13__.TipoEntidad.SUCURSAL && sucId != null) {
                    if (((_b = (_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.sucursalDestino) === null || _b === void 0 ? void 0 : _b.id) == sucId) {
                        return true;
                    }
                }
                else {
                    this.notificacionService.openItemNoEncontrado();
                    return false;
                }
            })).catch(err => {
                this.notificacionService.openAlgoSalioMal();
                return false;
            });
        });
    }
    onVerificarProducto(item) {
        var _a;
        let producto = (_a = item === null || item === void 0 ? void 0 : item.presentacionPreTransferencia) === null || _a === void 0 ? void 0 : _a.producto;
        if ((producto === null || producto === void 0 ? void 0 : producto.id) != null) {
            this.barcodeScanner.scan().then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__awaiter)(this, void 0, void 0, function* () {
                if (res.text != null) {
                    (yield this.codigoService.onGetCodigoPorCodigo(res.text)).subscribe(codigoRes => {
                        if (codigoRes.length > 0) {
                            if (codigoRes.find(c => { var _a, _b; return ((_b = (_a = c.presentacion) === null || _a === void 0 ? void 0 : _a.producto) === null || _b === void 0 ? void 0 : _b.id) == (producto === null || producto === void 0 ? void 0 : producto.id); }) != null) {
                                this.notificacionService.success("Producto correcto!!");
                            }
                            else {
                                this.notificacionService.danger("Producto no corresponde");
                            }
                        }
                        else {
                            this.notificacionService.danger("Código no encontrado");
                        }
                    });
                }
                else {
                    this.notificacionService.danger("Error en leer código");
                }
            }));
        }
    }
    onCargarMenos() {
        var _a, _b, _c, _d;
        let tam = (_b = (_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.transferenciaItemList) === null || _b === void 0 ? void 0 : _b.length;
        let diff = tam - this.size;
        (_d = (_c = this.selectedTransferencia) === null || _c === void 0 ? void 0 : _c.transferenciaItemList) === null || _d === void 0 ? void 0 : _d.splice(this.size - 1, diff);
    }
    onCargarMas() {
        this.page++;
        this.getTransferenciaItemList();
    }
    onShare() {
        var _a, _b;
        let codigo = new src_app_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_15__.QrData;
        codigo.tipoEntidad = src_app_domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_13__.TipoEntidad.TRANSFERENCIA;
        codigo.idCentral = (_a = this.selectedTransferencia) === null || _a === void 0 ? void 0 : _a.id;
        codigo.idOrigen = (_b = this.selectedTransferencia) === null || _b === void 0 ? void 0 : _b.id;
        this.popoverService.open(src_app_components_qr_generator_qr_generator_component__WEBPACK_IMPORTED_MODULE_16__.QrGeneratorComponent, (0,src_app_generic_utils_qrUtils__WEBPACK_IMPORTED_MODULE_15__.codificarQr)(codigo), _services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopoverSize.XS);
    }
};
InfoTransferenciaComponent.ctorParameters = () => [
    { type: _transferencia_service__WEBPACK_IMPORTED_MODULE_6__.TransferenciaService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_20__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_21__.Location },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_5__.MainService },
    { type: src_app_services_menu_action_service__WEBPACK_IMPORTED_MODULE_8__.MenuActionService },
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopOverService },
    { type: _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__.BarcodeScanner },
    { type: src_app_services_cargando_service__WEBPACK_IMPORTED_MODULE_11__.CargandoService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.Platform },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_12__.NotificacionService },
    { type: _codigo_codigo_service__WEBPACK_IMPORTED_MODULE_14__.CodigoService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_17__.DialogoService }
];
InfoTransferenciaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_19__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_23__.Component)({
        selector: 'app-info-transferencia',
        template: _info_transferencia_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__.BarcodeScanner],
        styles: [_info_transferencia_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], InfoTransferenciaComponent);



/***/ }),

/***/ 83369:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/transferencias/ingresar-codigo-pop/ingresar-codigo-pop.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IngresarCodigoPopComponent": () => (/* binding */ IngresarCodigoPopComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ingresar_codigo_pop_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ingresar-codigo-pop.component.html?ngResource */ 59279);
/* harmony import */ var _ingresar_codigo_pop_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ingresar-codigo-pop.component.scss?ngResource */ 52809);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/pop-over.service */ 21690);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 90587);






let IngresarCodigoPopComponent = class IngresarCodigoPopComponent {
    constructor(popoverService) {
        this.popoverService = popoverService;
        this.codigoControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(6)]);
    }
    ngOnInit() {
    }
    onCancel() {
        this.popoverService.close(null);
    }
    onAceptar() {
        let value = this.codigoControl.value;
        this.popoverService.close(value.toUpperCase());
    }
};
IngresarCodigoPopComponent.ctorParameters = () => [
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_2__.PopOverService }
];
IngresarCodigoPopComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-ingresar-codigo-pop',
        template: _ingresar_codigo_pop_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ingresar_codigo_pop_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], IngresarCodigoPopComponent);



/***/ }),

/***/ 82402:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/transferencias/list-transferencias/list-transferencias.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListTransferenciasComponent": () => (/* binding */ ListTransferenciasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _list_transferencias_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-transferencias.component.html?ngResource */ 25676);
/* harmony import */ var _list_transferencias_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-transferencias.component.scss?ngResource */ 76905);
/* harmony import */ var _services_menu_action_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/menu-action.service */ 47257);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _services_main_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../services/main.service */ 91557);
/* harmony import */ var _transferencia_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../transferencia.service */ 67240);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);










let ListTransferenciasComponent = class ListTransferenciasComponent {
    constructor(transferenciaService, mainService, router, route, _location, menuActionService) {
        this.transferenciaService = transferenciaService;
        this.mainService = mainService;
        this.router = router;
        this.route = route;
        this._location = _location;
        this.menuActionService = menuActionService;
    }
    ngOnInit() {
        this.verificarUsuario();
    }
    onGetTransferencias() {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.transferenciaService.onGetTrasnferenciasPorUsuario((_b = (_a = this.mainService) === null || _a === void 0 ? void 0 : _a.usuarioActual) === null || _b === void 0 ? void 0 : _b.id))
                .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.untilDestroyed)(this))
                .subscribe(res => {
                if (res != null) {
                    this.transferenciaList = res;
                }
            });
        });
    }
    verificarUsuario() {
        var _a;
        if (((_a = this.mainService) === null || _a === void 0 ? void 0 : _a.usuarioActual) != null) {
            this.onGetTransferencias();
        }
        else {
            setTimeout(() => {
                this.verificarUsuario();
            }, 1000);
        }
    }
    onItemClick(item) {
        this.router.navigate(['info', item.id], { relativeTo: this.route });
    }
    onBack() {
        this._location.back();
    }
    openFilterMenu() {
        this.menuActionService.presentActionSheet([
            { texto: 'Ordenar por fecha', role: 'fecha' },
            { texto: 'Primero transferencias abiertas', role: 'abiertas' },
            { texto: 'Primero concluidas', role: 'concluidas' },
        ]).then(res => {
            let role = res.role;
            this.onFiltrar(role);
            console.log(role);
        });
    }
    onFiltrar(role) {
        switch (role) {
            case 'fecha':
                this.transferenciaList = this.transferenciaList.sort((a, b) => {
                    if (a.creadoEn > b.creadoEn) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                });
                break;
            case 'abiertas':
                this.transferenciaList = this.transferenciaList.sort((a, b) => {
                    if (a.etapa > b.etapa) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                });
                break;
            case 'concluidas':
                this.transferenciaList = this.transferenciaList.sort((a, b) => {
                    if (a.etapa < b.etapa) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                });
                break;
        }
    }
};
ListTransferenciasComponent.ctorParameters = () => [
    { type: _transferencia_service__WEBPACK_IMPORTED_MODULE_4__.TransferenciaService },
    { type: _services_main_service__WEBPACK_IMPORTED_MODULE_3__.MainService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.Location },
    { type: _services_menu_action_service__WEBPACK_IMPORTED_MODULE_2__.MenuActionService }
];
ListTransferenciasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_6__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-list-transferencias',
        template: _list_transferencias_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_list_transferencias_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListTransferenciasComponent);



/***/ }),

/***/ 9753:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/transferencias/modificar-item-dialog/modificar-item-dialog.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModificarItemDialogComponent": () => (/* binding */ ModificarItemDialogComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _modificar_item_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modificar-item-dialog.component.html?ngResource */ 77800);
/* harmony import */ var _modificar_item_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modificar-item-dialog.component.scss?ngResource */ 71625);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/pop-over.service */ 21690);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);






let ModificarItemDialogComponent = class ModificarItemDialogComponent {
    constructor(popoverService) {
        this.popoverService = popoverService;
        this.isCantidad = false;
        this.isVencimiento = false;
    }
    ngOnInit() {
        this.cantidadControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.min(1)]);
        this.vencimientoControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]);
        if (this.data.isCantidad) {
            this.isCantidad = true;
        }
        else if (this.data.isVencimiento) {
            this.isVencimiento = true;
        }
    }
    onAceptar() {
        this.popoverService.close({ cantidad: this.cantidadControl.value, vencimiento: this.vencimientoControl.value });
    }
    onCancel() {
        this.popoverService.close(null);
    }
};
ModificarItemDialogComponent.ctorParameters = () => [
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_2__.PopOverService }
];
ModificarItemDialogComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
ModificarItemDialogComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-modificar-item-dialog',
        template: _modificar_item_dialog_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_modificar_item_dialog_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModificarItemDialogComponent);



/***/ }),

/***/ 38370:
/*!*************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencia.model.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtapaTransferencia": () => (/* binding */ EtapaTransferencia),
/* harmony export */   "TipoTransferencia": () => (/* binding */ TipoTransferencia),
/* harmony export */   "Transferencia": () => (/* binding */ Transferencia),
/* harmony export */   "TransferenciaEstado": () => (/* binding */ TransferenciaEstado),
/* harmony export */   "TransferenciaInput": () => (/* binding */ TransferenciaInput),
/* harmony export */   "TransferenciaItem": () => (/* binding */ TransferenciaItem),
/* harmony export */   "TransferenciaItemInput": () => (/* binding */ TransferenciaItemInput),
/* harmony export */   "TransferenciaItemMotivoModificacion": () => (/* binding */ TransferenciaItemMotivoModificacion),
/* harmony export */   "TransferenciaItemMotivoRechazo": () => (/* binding */ TransferenciaItemMotivoRechazo)
/* harmony export */ });
/* harmony import */ var src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/generic/utils/dateUtils */ 8535);

var TransferenciaEstado;
(function (TransferenciaEstado) {
    TransferenciaEstado["ABIERTA"] = "ABIERTA";
    TransferenciaEstado["EN_ORIGEN"] = "EN_ORIGEN";
    TransferenciaEstado["EN_TRANSITO"] = "EN_TRANSITO";
    TransferenciaEstado["EN_DESTINO"] = "EN_DESTINO";
    TransferenciaEstado["FALTA_REVISION_EN_ORIGEN"] = "FALTA_REVISION_EN_ORIGEN";
    TransferenciaEstado["FALTA_REVISION_EN_DESTINO"] = "FALTA_REVISION_EN_DESTINO";
    TransferenciaEstado["CONLCUIDA"] = "CONLCUIDA";
    TransferenciaEstado["CANCELADA"] = "CANCELADA";
})(TransferenciaEstado || (TransferenciaEstado = {}));
var TipoTransferencia;
(function (TipoTransferencia) {
    TipoTransferencia["MANUAL"] = "MANUAL";
    TipoTransferencia["AUTOMATICA"] = "AUTOMATICA";
    TipoTransferencia["MIXTA"] = "MIXTA"; //hecha por el sistema pero modificada por un usuario
})(TipoTransferencia || (TipoTransferencia = {}));
var TransferenciaItemMotivoRechazo;
(function (TransferenciaItemMotivoRechazo) {
    TransferenciaItemMotivoRechazo["FALTA_PRODUCTO"] = "FALTA_PRODUCTO";
    TransferenciaItemMotivoRechazo["PRODUCTO_AVERIADO"] = "PRODUCTO_AVERIADO";
    TransferenciaItemMotivoRechazo["PRODUCTO_VENCIDO"] = "PRODUCTO_VENCIDO";
    TransferenciaItemMotivoRechazo["PRODUCTO_EQUIVOCADO"] = "PRODUCTO_EQUIVOCADO";
})(TransferenciaItemMotivoRechazo || (TransferenciaItemMotivoRechazo = {}));
var TransferenciaItemMotivoModificacion;
(function (TransferenciaItemMotivoModificacion) {
    TransferenciaItemMotivoModificacion["CANTIDAD_INCORRECTA"] = "CANTIDAD_INCORRECTA";
    TransferenciaItemMotivoModificacion["VENCIMIENTO_INCORRECTO"] = "VENCIMIENTO_INCORRECTO";
    TransferenciaItemMotivoModificacion["PRESENTACION_INCORRECTA"] = "PRESENTACION_INCORRECTA";
})(TransferenciaItemMotivoModificacion || (TransferenciaItemMotivoModificacion = {}));
var EtapaTransferencia;
(function (EtapaTransferencia) {
    EtapaTransferencia["PRE_TRANSFERENCIA_CREACION"] = "PRE_TRANSFERENCIA_CREACION";
    EtapaTransferencia["PRE_TRANSFERENCIA_ORIGEN"] = "PRE_TRANSFERENCIA_ORIGEN";
    EtapaTransferencia["PREPARACION_MERCADERIA"] = "PREPARACION_MERCADERIA";
    EtapaTransferencia["PREPARACION_MERCADERIA_CONCLUIDA"] = "PREPARACION_MERCADERIA_CONCLUIDA";
    EtapaTransferencia["TRANSPORTE_VERIFICACION"] = "TRANSPORTE_VERIFICACION";
    EtapaTransferencia["TRANSPORTE_EN_CAMINO"] = "TRANSPORTE_EN_CAMINO";
    EtapaTransferencia["TRANSPORTE_EN_DESTINO"] = "TRANSPORTE_EN_DESTINO";
    EtapaTransferencia["RECEPCION_EN_VERIFICACION"] = "RECEPCION_EN_VERIFICACION";
    EtapaTransferencia["RECEPCION_CONCLUIDA"] = "RECEPCION_CONCLUIDA";
})(EtapaTransferencia || (EtapaTransferencia = {}));
class Transferencia {
    constructor() {
        this.transferenciaItemList = [];
    }
    toInput() {
        var _a, _b, _c, _d, _e, _f;
        let input = new TransferenciaInput;
        input.id = this.id;
        input.creadoEn = this.creadoEn;
        input.estado = this.estado;
        input.tipo = this.tipo;
        input.observacion = this.observacion;
        input.sucursalDestinoId = (_a = this.sucursalDestino) === null || _a === void 0 ? void 0 : _a.id;
        input.sucursalOrigenId = (_b = this.sucursalOrigen) === null || _b === void 0 ? void 0 : _b.id;
        input.usuarioPreTransferenciaId = (_c = this.usuarioPreTransferencia) === null || _c === void 0 ? void 0 : _c.id;
        input.usuarioPreparacionId = (_d = this.usuarioPreparacion) === null || _d === void 0 ? void 0 : _d.id;
        input.usuarioTransporteId = (_e = this.usuarioTransporte) === null || _e === void 0 ? void 0 : _e.id;
        input.usuarioRecepcionId = (_f = this.usuarioRecepcion) === null || _f === void 0 ? void 0 : _f.id;
        input.etapa = this.etapa;
        return input;
    }
}
class TransferenciaInput {
}
class TransferenciaItem {
    toInput() {
        var _a, _b, _c, _d, _e, _f;
        let input = new TransferenciaItemInput;
        input.id = this.id;
        input.transferenciaId = (_a = this.transferencia) === null || _a === void 0 ? void 0 : _a.id;
        input.presentacionPreTransferenciaId = (_b = this.presentacionPreTransferencia) === null || _b === void 0 ? void 0 : _b.id;
        input.presentacionPreparacionId = (_c = this.presentacionPreparacion) === null || _c === void 0 ? void 0 : _c.id;
        input.presentacionTransporteId = (_d = this.presentacionTransporte) === null || _d === void 0 ? void 0 : _d.id;
        input.presentacionRecepcionId = (_e = this.presentacionRecepcion) === null || _e === void 0 ? void 0 : _e.id;
        input.cantidadPreTransferencia = this.cantidadPreTransferencia;
        input.cantidadPreparacion = this.cantidadPreparacion;
        input.cantidadTransporte = this.cantidadTransporte;
        input.cantidadRecepcion = this.cantidadRecepcion;
        input.observacionPreTransferencia = this.observacionPreTransferencia;
        input.observacionPreparacion = this.observacionPreparacion;
        input.observacionTransporte = this.observacionTransporte;
        input.observacionRecepcion = this.observacionRecepcion;
        input.vencimientoPreTransferencia = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__.dateToString)(this.vencimientoPreTransferencia);
        input.vencimientoPreparacion = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__.dateToString)(this.vencimientoPreparacion);
        input.vencimientoTransporte = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__.dateToString)(this.vencimientoTransporte);
        input.vencimientoRecepcion = (0,src_app_generic_utils_dateUtils__WEBPACK_IMPORTED_MODULE_0__.dateToString)(this.vencimientoRecepcion);
        input.motivoModificacionPreTransferencia = this.motivoModificacionPreTransferencia;
        input.motivoModificacionPreparacion = this.motivoModificacionPreparacion;
        input.motivoModificacionTransporte = this.motivoModificacionTransporte;
        input.motivoModificacionRecepcion = this.motivoModificacionRecepcion;
        input.motivoRechazoPreTransferencia = this.motivoRechazoPreTransferencia;
        input.motivoRechazoPreparacion = this.motivoRechazoPreparacion;
        input.motivoRechazoTransporte = this.motivoRechazoTransporte;
        input.motivoRechazoRecepcion = this.motivoRechazoRecepcion;
        input.activo = this.activo;
        input.poseeVencimiento = this.poseeVencimiento;
        input.usuarioId = (_f = this.usuario) === null || _f === void 0 ? void 0 : _f.id;
        return input;
    }
}
class TransferenciaItemInput {
}


/***/ }),

/***/ 67240:
/*!***************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencia.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferenciaService": () => (/* binding */ TransferenciaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _graphql_getTransferenciasPorUsuario__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./graphql/getTransferenciasPorUsuario */ 1240);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dialogo.service */ 86124);
/* harmony import */ var _generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../generic/generic-crud.service */ 18531);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_services_main_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/main.service */ 91557);
/* harmony import */ var _graphql_deleteTransferencia__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./graphql/deleteTransferencia */ 69848);
/* harmony import */ var _graphql_deleteTransferenciaItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql/deleteTransferenciaItem */ 30660);
/* harmony import */ var _graphql_finalizarTransferencia__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./graphql/finalizarTransferencia */ 9934);
/* harmony import */ var _graphql_getTransferencia__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./graphql/getTransferencia */ 34493);
/* harmony import */ var _graphql_getTransferenciaPorFecha__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./graphql/getTransferenciaPorFecha */ 64344);
/* harmony import */ var _graphql_prepararTransferencia__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./graphql/prepararTransferencia */ 39830);
/* harmony import */ var _graphql_saveTransferencia__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./graphql/saveTransferencia */ 49716);
/* harmony import */ var _graphql_saveTransferenciaItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./graphql/saveTransferenciaItem */ 86296);
/* harmony import */ var _transferencia_model__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./transferencia.model */ 38370);
/* harmony import */ var _graphql_getTransferenciaItensPorTransferenciaId__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./graphql/getTransferenciaItensPorTransferenciaId */ 67479);



















let TransferenciaService = class TransferenciaService {
    constructor(genericCrudService, getTransferencia, saveTransferencia, deleteTransfencia, saveTransferenciaItem, deleteTransferenciaItem, finalizarTransferencia, prepararTransferencia, getTransferenciasPorFecha, mainService, dialogoService, notificacionService, transferenciasPorUsuario, transferenciaItemPorTransferenciaId) {
        this.genericCrudService = genericCrudService;
        this.getTransferencia = getTransferencia;
        this.saveTransferencia = saveTransferencia;
        this.deleteTransfencia = deleteTransfencia;
        this.saveTransferenciaItem = saveTransferenciaItem;
        this.deleteTransferenciaItem = deleteTransferenciaItem;
        this.finalizarTransferencia = finalizarTransferencia;
        this.prepararTransferencia = prepararTransferencia;
        this.getTransferenciasPorFecha = getTransferenciasPorFecha;
        this.mainService = mainService;
        this.dialogoService = dialogoService;
        this.notificacionService = notificacionService;
        this.transferenciasPorUsuario = transferenciasPorUsuario;
        this.transferenciaItemPorTransferenciaId = transferenciaItemPorTransferenciaId;
    }
    onGetTrasferenciasPorFecha(inicio, fin) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onGetByFecha(this.getTransferenciasPorFecha, inicio, fin);
        });
    }
    onGetTransferencia(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onGetById(this.getTransferencia, id);
        });
    }
    onSaveTransferencia(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            input.usuarioPreTransferenciaId = this.mainService.usuarioActual.id;
            return yield this.genericCrudService.onSave(this.saveTransferencia, input);
        });
    }
    onDeleteTransferencia(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onDelete(this.deleteTransfencia, id, 'Realmente  desea eliminar esta transferencia?');
        });
    }
    onGetTransferenciaItensPorTransferenciaId(id, page, size) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onGetById(this.transferenciaItemPorTransferenciaId, id, page, size);
        });
    }
    onSaveTransferenciaItem(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onSave(this.saveTransferenciaItem, input);
        });
    }
    onDeleteTransferenciaItem(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onDelete(this.deleteTransferenciaItem, id, 'Realmente desea eliminar este item');
        });
    }
    onGetTrasnferenciasPorUsuario(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.genericCrudService.onGetById(this.transferenciasPorUsuario, id);
        });
    }
    onFinalizar(transferencia) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_16__.Observable(obs => {
            if (transferencia.estado == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.TransferenciaEstado.ABIERTA) {
                this.dialogoService.open('Realmente desea finalizar esta transferencia?', 'Una vez finalizada, la transferencia estara disponible para ser preparada', true).then(res => {
                    if (res) {
                        this.finalizarTransferencia.mutate({
                            id: transferencia.id,
                            usuarioId: this.mainService.usuarioActual.id
                        }, { fetchPolicy: 'no-cache', errorPolicy: 'all' })
                            .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__.untilDestroyed)(this))
                            .subscribe(res => {
                            if (res.errors == null) {
                                obs.next(true);
                                this.notificacionService.openGuardadoConExito();
                            }
                            else {
                                obs.next(false);
                                this.notificacionService.openAlgoSalioMal();
                            }
                        });
                    }
                });
            }
        });
    }
    onAvanzarEtapa(transferencia, etapa) {
        let texto = '';
        if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.PRE_TRANSFERENCIA_ORIGEN) {
            texto = 'Estas iniciando la etapa de preparación de productos, verifique con cuidado cada item';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.PREPARACION_MERCADERIA) {
            texto = 'Estas iniciando la etapa de preparación de productos, verifique con cuidado cada item';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.PREPARACION_MERCADERIA_CONCLUIDA) {
            texto = 'Estas culminando la etapa de preparación de productos, aguardando transporte';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.TRANSPORTE_VERIFICACION) {
            texto = 'Estas iniciando la etapa de verificación de productos para su transporte';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.TRANSPORTE_EN_CAMINO) {
            texto = 'Estas iniciando la etapa de transporte de la sucursal de origen a sucursal de destino, al aceptar, se dara de baja en stock';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.TRANSPORTE_EN_DESTINO) {
            texto = 'Estas culminando la entrega de productos a la sucursal de destino, aguarde su verificación';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.RECEPCION_EN_VERIFICACION) {
            texto = 'Estas iniciando la etapa de recepción de productos, verifique con cuidado cada item';
        }
        else if (etapa == _transferencia_model__WEBPACK_IMPORTED_MODULE_13__.EtapaTransferencia.RECEPCION_CONCLUIDA) {
            texto = 'Estas culminando la etapa de recepción, al aceptar, las mercaderias van a ser cargadas en stock';
        }
        return new rxjs__WEBPACK_IMPORTED_MODULE_16__.Observable(obs => {
            this.dialogoService.open('Atención, revise los datos antes de proceder.', texto).then(res => {
                if (res.role == 'aceptar') {
                    this.prepararTransferencia.mutate({
                        id: transferencia.id,
                        etapa,
                        usuarioId: this.mainService.usuarioActual.id
                    }, { fetchPolicy: 'no-cache', errorPolicy: 'all' })
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__.untilDestroyed)(this))
                        .subscribe(res => {
                        if (res.errors == null) {
                            obs.next(true);
                            this.notificacionService.openGuardadoConExito();
                        }
                        else {
                            obs.next(false);
                            this.notificacionService.openAlgoSalioMal();
                        }
                    });
                }
            });
        });
    }
};
TransferenciaService.ctorParameters = () => [
    { type: _generic_generic_crud_service__WEBPACK_IMPORTED_MODULE_3__.GenericCrudService },
    { type: _graphql_getTransferencia__WEBPACK_IMPORTED_MODULE_8__.GetTransferenciaGQL },
    { type: _graphql_saveTransferencia__WEBPACK_IMPORTED_MODULE_11__.SaveTransferenciaGQL },
    { type: _graphql_deleteTransferencia__WEBPACK_IMPORTED_MODULE_5__.DeleteTransferenciaGQL },
    { type: _graphql_saveTransferenciaItem__WEBPACK_IMPORTED_MODULE_12__.SaveTransferenciaItemGQL },
    { type: _graphql_deleteTransferenciaItem__WEBPACK_IMPORTED_MODULE_6__.DeleteTransferenciaItemGQL },
    { type: _graphql_finalizarTransferencia__WEBPACK_IMPORTED_MODULE_7__.FinalizarTransferenciaGQL },
    { type: _graphql_prepararTransferencia__WEBPACK_IMPORTED_MODULE_10__.PrepararTransferenciaGQL },
    { type: _graphql_getTransferenciaPorFecha__WEBPACK_IMPORTED_MODULE_9__.GetTransferenciaPorFechaGQL },
    { type: src_app_services_main_service__WEBPACK_IMPORTED_MODULE_4__.MainService },
    { type: src_app_services_dialogo_service__WEBPACK_IMPORTED_MODULE_2__.DialogoService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_1__.NotificacionService },
    { type: _graphql_getTransferenciasPorUsuario__WEBPACK_IMPORTED_MODULE_0__.GetTransferenciasPorUsuarioGQL },
    { type: _graphql_getTransferenciaItensPorTransferenciaId__WEBPACK_IMPORTED_MODULE_14__.GetTransferenciaItensPorTransferenciaIdGQL }
];
TransferenciaService = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_17__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Injectable)({
        providedIn: 'root'
    })
], TransferenciaService);



/***/ }),

/***/ 91704:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencia/transferencia.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferenciaComponent": () => (/* binding */ TransferenciaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _transferencia_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transferencia.component.html?ngResource */ 39925);
/* harmony import */ var _transferencia_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transferencia.component.scss?ngResource */ 19862);
/* harmony import */ var _services_cargando_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/cargando.service */ 68030);
/* harmony import */ var _domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../domains/enums/tipo-entidad.enum */ 61246);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _transferencia_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../transferencia.service */ 67240);
/* harmony import */ var _ingresar_codigo_pop_ingresar_codigo_pop_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../ingresar-codigo-pop/ingresar-codigo-pop.component */ 83369);
/* harmony import */ var _services_pop_over_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../../services/pop-over.service */ 21690);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/barcode-scanner/ngx */ 38283);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/domains/empresarial/sucursal/sucursal.service */ 17976);















let TransferenciaComponent = class TransferenciaComponent {
    constructor(router, route, notificacionService, popoverService, transferenciaService, barcodeScanner, cargandoService, plf, sucursalService) {
        this.router = router;
        this.route = route;
        this.notificacionService = notificacionService;
        this.popoverService = popoverService;
        this.transferenciaService = transferenciaService;
        this.barcodeScanner = barcodeScanner;
        this.cargandoService = cargandoService;
        this.plf = plf;
        this.sucursalService = sucursalService;
        this.hideContent = false;
        this.showScanner = true;
        this.isWeb = false;
        this.isWeb = this.plf.platforms().includes('mobileweb');
    }
    ngOnInit() { }
    goTo(link) {
        this.router.navigate([link], { relativeTo: this.route });
    }
    onScanQr() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open('Abriendo camara...');
            setTimeout(() => {
                this.cargandoService.close(loading);
            }, 1000);
            this.barcodeScanner.scan().then((barcodeData) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                this.notificacionService.open('Escaneado con éxito!', src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_7__.TipoNotificacion.SUCCESS, 1);
                let codigo = barcodeData.text;
                let arr = codigo.split('-');
                let prefix = arr[2];
                let sucId = +arr[1];
                let transferenciaId = arr[3];
                if (prefix == _domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_3__.TipoEntidad.TRANSFERENCIA && transferenciaId != null) {
                    (yield this.transferenciaService.onGetTransferencia(+transferenciaId))
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this))
                        .subscribe(res => {
                        if (res != null) {
                            this.router.navigate(['list/info', res.id], { relativeTo: this.route });
                        }
                        else {
                            this.notificacionService.openItemNoEncontrado();
                        }
                    });
                }
                else {
                    this.notificacionService.openItemNoEncontrado();
                }
            })).catch(err => {
                this.notificacionService.openAlgoSalioMal();
            });
        });
    }
    ingresarCodigo() {
        this.popoverService.open(_ingresar_codigo_pop_ingresar_codigo_pop_component__WEBPACK_IMPORTED_MODULE_5__.IngresarCodigoPopComponent).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            if (res != null) {
                let codigo = res.data;
                let arr = codigo.split('-');
                let prefix = arr[0];
                let sucId = +arr[1];
                let transferenciaId = arr[2];
                if (prefix == _domains_enums_tipo_entidad_enum__WEBPACK_IMPORTED_MODULE_3__.TipoEntidad.TRANSFERENCIA && sucId != null && transferenciaId != null) {
                    (yield this.transferenciaService.onGetTransferencia(+transferenciaId))
                        .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.untilDestroyed)(this))
                        .subscribe(res => {
                        if (res != null && (res.sucursalOrigen.id == sucId || res.sucursalDestino.id == sucId)) {
                            this.router.navigate(['list/info', res.id], { relativeTo: this.route });
                        }
                        else {
                            this.notificacionService.openItemNoEncontrado();
                        }
                    });
                }
                else {
                    this.notificacionService.openItemNoEncontrado();
                }
            }
        }));
    }
};
TransferenciaComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_7__.NotificacionService },
    { type: _services_pop_over_service__WEBPACK_IMPORTED_MODULE_6__.PopOverService },
    { type: _transferencia_service__WEBPACK_IMPORTED_MODULE_4__.TransferenciaService },
    { type: _awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__.BarcodeScanner },
    { type: _services_cargando_service__WEBPACK_IMPORTED_MODULE_2__.CargandoService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.Platform },
    { type: src_app_domains_empresarial_sucursal_sucursal_service__WEBPACK_IMPORTED_MODULE_9__.SucursalService }
];
TransferenciaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_11__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-transferencia',
        template: _transferencia_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        providers: [_awesome_cordova_plugins_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_8__.BarcodeScanner],
        styles: [_transferencia_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TransferenciaComponent);



/***/ }),

/***/ 95221:
/*!***********************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencias-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferenciasRoutingModule": () => (/* binding */ TransferenciasRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _info_transferencia_info_transferencia_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./info-transferencia/info-transferencia.component */ 39242);
/* harmony import */ var _transferencia_transferencia_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transferencia/transferencia.component */ 91704);
/* harmony import */ var _list_transferencias_list_transferencias_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./list-transferencias/list-transferencias.component */ 82402);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);






const routes = [
    {
        path: '',
        component: _transferencia_transferencia_component__WEBPACK_IMPORTED_MODULE_1__.TransferenciaComponent,
    },
    {
        path: 'list',
        component: _list_transferencias_list_transferencias_component__WEBPACK_IMPORTED_MODULE_2__.ListTransferenciasComponent,
    },
    {
        path: 'list/info/:id',
        component: _info_transferencia_info_transferencia_component__WEBPACK_IMPORTED_MODULE_0__.InfoTransferenciaComponent
    }
];
let TransferenciasRoutingModule = class TransferenciasRoutingModule {
};
TransferenciasRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
    })
], TransferenciasRoutingModule);



/***/ }),

/***/ 1225:
/*!***************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencias.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferenciasModule": () => (/* binding */ TransferenciasModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _modificar_item_dialog_modificar_item_dialog_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modificar-item-dialog/modificar-item-dialog.component */ 9753);
/* harmony import */ var _ingresar_codigo_pop_ingresar_codigo_pop_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ingresar-codigo-pop/ingresar-codigo-pop.component */ 83369);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../components/components.module */ 45642);
/* harmony import */ var _info_transferencia_info_transferencia_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./info-transferencia/info-transferencia.component */ 39242);
/* harmony import */ var _transferencia_transferencia_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./transferencia/transferencia.component */ 91704);
/* harmony import */ var _list_transferencias_list_transferencias_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./list-transferencias/list-transferencias.component */ 82402);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _transferencias_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./transferencias-routing.module */ 95221);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);












let TransferenciasModule = class TransferenciasModule {
};
TransferenciasModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [_list_transferencias_list_transferencias_component__WEBPACK_IMPORTED_MODULE_5__.ListTransferenciasComponent, _transferencia_transferencia_component__WEBPACK_IMPORTED_MODULE_4__.TransferenciaComponent, _info_transferencia_info_transferencia_component__WEBPACK_IMPORTED_MODULE_3__.InfoTransferenciaComponent, _ingresar_codigo_pop_ingresar_codigo_pop_component__WEBPACK_IMPORTED_MODULE_1__.IngresarCodigoPopComponent, _modificar_item_dialog_modificar_item_dialog_component__WEBPACK_IMPORTED_MODULE_0__.ModificarItemDialogComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _transferencias_routing_module__WEBPACK_IMPORTED_MODULE_6__.TransferenciasRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
        ],
        exports: [_list_transferencias_list_transferencias_component__WEBPACK_IMPORTED_MODULE_5__.ListTransferenciasComponent, _transferencia_transferencia_component__WEBPACK_IMPORTED_MODULE_4__.TransferenciaComponent],
    })
], TransferenciasModule);



/***/ }),

/***/ 68030:
/*!**********************************************!*\
  !*** ./src/app/services/cargando.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CargandoService": () => (/* binding */ CargandoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);



let CargandoService = class CargandoService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.counter = 0;
    }
    open(texto, disable) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.loadingController.create({
                id: new Date().getTime() + '',
                message: texto,
                backdropDismiss: true,
            });
            yield loading.present();
            return loading;
        });
    }
    close(loading) {
        setTimeout(() => {
            loading.dismiss();
        }, 500);
    }
};
CargandoService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.LoadingController }
];
CargandoService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], CargandoService);



/***/ }),

/***/ 86124:
/*!*********************************************!*\
  !*** ./src/app/services/dialogo.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DialogoService": () => (/* binding */ DialogoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);



let DialogoService = class DialogoService {
    constructor(alertController) {
        this.alertController = alertController;
    }
    open(titulo, texto, siNo) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            let res = false;
            const alert = yield this.alertController.create({
                header: titulo,
                message: texto,
                buttons: siNo == false ? [
                    {
                        text: 'Aceptar',
                        role: 'aceptar',
                        id: 'aceptar-button',
                        handler: () => {
                            return true;
                        }
                    }
                ] : [
                    {
                        text: 'No',
                        role: 'cancelar',
                        id: 'cancelar-button',
                        handler: () => {
                            return true;
                        }
                    },
                    {
                        text: 'Si',
                        role: 'aceptar',
                        id: 'aceptar-button',
                        handler: () => {
                            return true;
                        }
                    }
                ]
            });
            yield alert.present();
            return alert.onDidDismiss();
        });
    }
};
DialogoService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController }
];
DialogoService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], DialogoService);



/***/ }),

/***/ 68133:
/*!******************************************************!*\
  !*** ./src/app/services/fingerprint-auth.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FingerprintAuthService": () => (/* binding */ FingerprintAuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/fingerprint-aio/ngx */ 63427);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);




let FingerprintAuthService = class FingerprintAuthService {
    constructor(faio, plf) {
        this.faio = faio;
        this.plf = plf;
    }
    showFingerprintDialog() {
        this.faio.isAvailable().then(() => {
            this.faio.show({}).then((res) => {
                alert(JSON.stringify(res));
            }, (error) => {
                alert(JSON.stringify(error));
            });
        }, (error) => {
            alert(JSON.stringify(error));
        });
    }
};
FingerprintAuthService.ctorParameters = () => [
    { type: _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_0__.FingerprintAIO },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.Platform }
];
FingerprintAuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], FingerprintAuthService);



/***/ }),

/***/ 54120:
/*!*******************************************!*\
  !*** ./src/app/services/login.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginService": () => (/* binding */ LoginService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/notificacion.service */ 11818);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _main_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main.service */ 91557);
/* harmony import */ var _usuario_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usuario.service */ 65763);
/* harmony import */ var _dialog_login_cambiar_contrasenha_dialog_cambiar_contrasenha_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../dialog/login/cambiar-contrasenha-dialog/cambiar-contrasenha-dialog.component */ 17050);
/* harmony import */ var _pop_over_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pop-over.service */ 21690);
/* harmony import */ var _cargando_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cargando.service */ 68030);












let LoginService = class LoginService {
    constructor(http, usuarioService, mainService, notificacionService, router, popverService, cargandoService) {
        this.http = http;
        this.usuarioService = usuarioService;
        this.mainService = mainService;
        this.notificacionService = notificacionService;
        this.router = router;
        this.popverService = popverService;
        this.cargandoService = cargandoService;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders({
                Accept: 'application/json',
                'Content-Type': 'application/json',
            }),
        };
    }
    isAuthenticated() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_7__.Observable((obs) => {
            let isToken = localStorage.getItem('token');
            let id = localStorage.getItem('usuarioId');
            if (id != null) {
                this.usuarioService
                    .onGetUsuario(+id)
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__.untilDestroyed)(this))
                    .subscribe((res) => {
                    if (res) {
                        this.usuarioActual = res;
                        this.mainService.usuarioActual = this.usuarioActual;
                        obs.next(res);
                    }
                    else {
                        obs.next(null);
                    }
                });
            }
            else {
                obs.next(null);
            }
        });
    }
    login(nickname, password) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open("Entrando al sistema....");
            return new rxjs__WEBPACK_IMPORTED_MODULE_7__.Observable((obs) => {
                let httpBody = {
                    nickname: nickname,
                    password: password,
                };
                let httpResponse = this.http
                    .post(`http://${localStorage.getItem('serverIp')}:${localStorage.getItem('serverPort')}/login`, httpBody, this.httpOptions)
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res['token'] != null) {
                        localStorage.setItem('token', res['token']);
                        setTimeout(() => {
                            if (res['usuarioId'] != null) {
                                localStorage.setItem('usuarioId', res['usuarioId']);
                                this.usuarioService
                                    .onGetUsuario(res['usuarioId'])
                                    .subscribe((res) => {
                                    if ((res === null || res === void 0 ? void 0 : res.id) != null) {
                                        let response = {
                                            usuario: res,
                                            error: null,
                                        };
                                        this.usuarioActual = res;
                                        this.mainService.usuarioActual = this.usuarioActual;
                                        if (password == '123') {
                                            this.popverService.open(_dialog_login_cambiar_contrasenha_dialog_cambiar_contrasenha_dialog_component__WEBPACK_IMPORTED_MODULE_3__.CambiarContrasenhaDialogComponent, this.usuarioActual, _pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopoverSize.XS).then(res2 => {
                                                if (res2 != null) {
                                                    response.usuario = res2;
                                                    this.usuarioActual = res2;
                                                    window.location.reload();
                                                }
                                            });
                                        }
                                        else {
                                            obs.next(response);
                                        }
                                    }
                                    else {
                                    }
                                });
                            }
                        }, 500);
                    }
                }, (error) => {
                    this.cargandoService.close(loading);
                    let response = {
                        usuario: null,
                        error: error,
                    };
                    obs.next(error);
                });
            });
        });
    }
    logOut() {
        localStorage.setItem('token', null);
        localStorage.setItem('usuarioId', null);
        this.usuarioActual = null;
        this.router.navigate(['']);
    }
};
LoginService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _usuario_service__WEBPACK_IMPORTED_MODULE_2__.UsuarioService },
    { type: _main_service__WEBPACK_IMPORTED_MODULE_1__.MainService },
    { type: src_app_services_notificacion_service__WEBPACK_IMPORTED_MODULE_0__.NotificacionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _pop_over_service__WEBPACK_IMPORTED_MODULE_4__.PopOverService },
    { type: _cargando_service__WEBPACK_IMPORTED_MODULE_5__.CargandoService }
];
LoginService = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_8__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Injectable)({
        providedIn: 'root',
    })
], LoginService);



/***/ }),

/***/ 91557:
/*!******************************************!*\
  !*** ./src/app/services/main.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainService": () => (/* binding */ MainService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 84505);




let MainService = class MainService {
    constructor() {
        this.authenticationSub = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(null);
    }
    load() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
        });
    }
};
MainService.ctorParameters = () => [];
MainService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_2__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], MainService);



/***/ }),

/***/ 47257:
/*!*************************************************!*\
  !*** ./src/app/services/menu-action.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuActionService": () => (/* binding */ MenuActionService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);



let MenuActionService = class MenuActionService {
    constructor(actionControler) {
        this.actionControler = actionControler;
    }
    presentActionSheet(opciones) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            let actionButtons = [];
            opciones.forEach(e => {
                let btn = {
                    text: e.texto,
                    role: e.role
                };
                if (e.enabled != false) {
                    actionButtons.push(btn);
                }
            });
            actionButtons.push({ text: 'Cancelar', role: null });
            const actionSheet = yield this.actionControler.create({
                header: 'Opciones',
                cssClass: 'action-menu',
                buttons: actionButtons,
                backdropDismiss: true,
                mode: "ios"
            });
            yield actionSheet.present();
            return actionSheet.onDidDismiss();
        });
    }
};
MenuActionService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ActionSheetController }
];
MenuActionService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], MenuActionService);



/***/ }),

/***/ 71609:
/*!*******************************************!*\
  !*** ./src/app/services/modal.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalService": () => (/* binding */ ModalService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);



let ModalService = class ModalService {
    constructor(modalController) {
        this.modalController = modalController;
    }
    openModal(component, data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: component,
                cssClass: 'my-custom-class',
                componentProps: {
                    data
                }
            });
            yield modal.present();
            this.currentModal = modal;
            return yield modal.onWillDismiss();
        });
    }
    closeModal(data) {
        this.modalController.dismiss(data);
    }
};
ModalService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController }
];
ModalService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ModalService);



/***/ }),

/***/ 11818:
/*!**************************************************!*\
  !*** ./src/app/services/notificacion.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificacionService": () => (/* binding */ NotificacionService),
/* harmony export */   "TipoNotificacion": () => (/* binding */ TipoNotificacion)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);



var TipoNotificacion;
(function (TipoNotificacion) {
    TipoNotificacion["SUCCESS"] = "success";
    TipoNotificacion["WARN"] = "warning";
    TipoNotificacion["DANGER"] = "danger";
    TipoNotificacion["NEUTRAL"] = "light";
})(TipoNotificacion || (TipoNotificacion = {}));
let NotificacionService = class NotificacionService {
    constructor(toastController) {
        this.toastController = toastController;
    }
    open(msg, tipoNotificacion, duracion) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: duracion != null ? duracion * 1000 : 2000,
                color: tipoNotificacion != null ? tipoNotificacion : TipoNotificacion.NEUTRAL
            });
            toast.present();
        });
    }
    openGuardadoConExito() {
        this.open('Guardado con éxito', TipoNotificacion.SUCCESS, 1);
    }
    openAlgoSalioMal(err) {
        this.open('Ups!! Algo salió mal: ' + err, TipoNotificacion.DANGER, 2);
    }
    openItemNoEncontrado() {
        this.open('Item no encontrado', TipoNotificacion.WARN, 2);
    }
    openEliminadoConExito() {
        this.open('Eliminado con éxito', TipoNotificacion.SUCCESS, 2);
    }
    toast(text) {
        this.open(text, TipoNotificacion.NEUTRAL, 2);
    }
    success(text) {
        this.open(text, TipoNotificacion.SUCCESS, 2);
    }
    danger(text) {
        this.open(text, TipoNotificacion.DANGER, 3);
    }
    warn(text) {
        this.open(text, TipoNotificacion.WARN, 3);
    }
};
NotificacionService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController }
];
NotificacionService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], NotificacionService);



/***/ }),

/***/ 21690:
/*!**********************************************!*\
  !*** ./src/app/services/pop-over.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PopOverService": () => (/* binding */ PopOverService),
/* harmony export */   "PopoverSize": () => (/* binding */ PopoverSize)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



var PopoverSize;
(function (PopoverSize) {
    PopoverSize["SM"] = "popover-sm";
    PopoverSize["MD"] = "popover-md";
    PopoverSize["XS"] = "popover-xs";
})(PopoverSize || (PopoverSize = {}));
let PopOverService = class PopOverService {
    constructor(popoverController) {
        this.popoverController = popoverController;
    }
    open(component, data, size, extraStyle) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: component,
                cssClass: size,
                translucent: true,
                componentProps: {
                    data
                }
            });
            yield popover.present();
            this.currentPopover = popover;
            return yield popover.onDidDismiss();
        });
    }
    close(data) {
        this.currentPopover.dismiss(data);
    }
};
PopOverService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.PopoverController }
];
PopOverService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], PopOverService);



/***/ }),

/***/ 65763:
/*!*********************************************!*\
  !*** ./src/app/services/usuario.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsuarioService": () => (/* binding */ UsuarioService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _graphql_personas_usuario_graphql_saveUsuario__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../graphql/personas/usuario/graphql/saveUsuario */ 55354);
/* harmony import */ var _graphql_personas_usuario_graphql_usuarioPorId__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../graphql/personas/usuario/graphql/usuarioPorId */ 25301);
/* harmony import */ var _graphql_personas_usuario_graphql_usuarioPorPersonaId__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../graphql/personas/usuario/graphql/usuarioPorPersonaId */ 85747);
/* harmony import */ var _graphql_personas_usuario_graphql_usuarioSearch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../graphql/personas/usuario/graphql/usuarioSearch */ 74003);
/* harmony import */ var _ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngneat/until-destroy */ 1082);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _cargando_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cargando.service */ 68030);
/* harmony import */ var _notificacion_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notificacion.service */ 11818);










let UsuarioService = class UsuarioService {
    constructor(getUsuario, getUsuarioPorPersonaId, saveUsuario, searchUsuario, cargandoService, notificacionService) {
        this.getUsuario = getUsuario;
        this.getUsuarioPorPersonaId = getUsuarioPorPersonaId;
        this.saveUsuario = saveUsuario;
        this.searchUsuario = searchUsuario;
        this.cargandoService = cargandoService;
        this.notificacionService = notificacionService;
    }
    onGetUsuario(id) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((obs) => {
            this.getUsuario
                .fetch({
                id,
            }, {
                fetchPolicy: 'no-cache',
                errorPolicy: 'all',
            }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.untilDestroyed)(this))
                .subscribe((res) => {
                if ((res === null || res === void 0 ? void 0 : res.errors) == null) {
                    obs.next(res === null || res === void 0 ? void 0 : res.data.data);
                }
                else {
                    obs.next(res.errors);
                }
            });
        });
    }
    onGetUsuarioPorPersonaId(id) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((obs) => {
            this.getUsuarioPorPersonaId
                .fetch({
                id,
            }, {
                fetchPolicy: 'no-cache',
                errorPolicy: 'all',
            }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.untilDestroyed)(this))
                .subscribe((res) => {
                if ((res === null || res === void 0 ? void 0 : res.errors) == null) {
                    obs.next(res === null || res === void 0 ? void 0 : res.data.data);
                }
                else {
                    obs.next(res.errors);
                }
            });
        });
    }
    onSeachUsuario(texto) {
        if (texto != null || texto != '') {
            return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((obs) => {
                this.searchUsuario
                    .fetch({
                    texto: texto.toUpperCase(),
                }, {
                    fetchPolicy: 'no-cache',
                    errorPolicy: 'all',
                })
                    .pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.untilDestroyed)(this))
                    .subscribe((res) => {
                    if (res.errors == null) {
                        obs.next(res.data);
                    }
                });
            });
        }
    }
    onSaveUsuario(input) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let loading = yield this.cargandoService.open(null, false);
            return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((obs) => {
                this.saveUsuario
                    .mutate({ entity: input }, { fetchPolicy: "no-cache", errorPolicy: "all" }).pipe((0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.untilDestroyed)(this))
                    .subscribe((res) => {
                    this.cargandoService.close(loading);
                    if (res.errors == null) {
                        obs.next(res.data["data"]);
                        this.notificacionService.open('Guardado con éxito', _notificacion_service__WEBPACK_IMPORTED_MODULE_5__.TipoNotificacion.SUCCESS, 2);
                    }
                    else {
                        console.log(res.errors);
                        this.notificacionService.open('Ups!! Algo salió mal', _notificacion_service__WEBPACK_IMPORTED_MODULE_5__.TipoNotificacion.DANGER, 2);
                    }
                });
            });
        });
    }
};
UsuarioService.ctorParameters = () => [
    { type: _graphql_personas_usuario_graphql_usuarioPorId__WEBPACK_IMPORTED_MODULE_1__.UsuarioPorIdGQL },
    { type: _graphql_personas_usuario_graphql_usuarioPorPersonaId__WEBPACK_IMPORTED_MODULE_2__.UsuarioPorPersonaIdGQL },
    { type: _graphql_personas_usuario_graphql_saveUsuario__WEBPACK_IMPORTED_MODULE_0__.SaveUsuarioGQL },
    { type: _graphql_personas_usuario_graphql_usuarioSearch__WEBPACK_IMPORTED_MODULE_3__.UsuarioSearchGQL },
    { type: _cargando_service__WEBPACK_IMPORTED_MODULE_4__.CargandoService },
    { type: _notificacion_service__WEBPACK_IMPORTED_MODULE_5__.NotificacionService }
];
UsuarioService = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_ngneat_until_destroy__WEBPACK_IMPORTED_MODULE_7__.UntilDestroy)(),
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Injectable)({
        providedIn: 'root',
    })
], UsuarioService);



/***/ }),

/***/ 89534:
/*!*********************************************!*\
  !*** ./src/environments/conectionConfig.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ipAddress": () => (/* binding */ ipAddress),
/* harmony export */   "port": () => (/* binding */ port)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);

const ipAddress = 'localhost';
// export const ipAddress = '192.168.1.33'
const isDev = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.isDevMode)();
const port = '8081';
// export const ipAddress = '150.136.137.98'//servidor central
// export const ipAddress = '158.101.114.87' //servidor farmacia


/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "APP_CONFIG": () => (/* binding */ APP_CONFIG),
/* harmony export */   "environment": () => (/* binding */ environment),
/* harmony export */   "serverAdress": () => (/* binding */ serverAdress)
/* harmony export */ });
/* harmony import */ var _conectionConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./conectionConfig */ 89534);

const APP_CONFIG = {
    production: false,
    environment: 'LOCAL'
};
const environment = {
    production: false,
    usuario: 1,
    sucursalId: 1,
    firebaseConfig: {
        apiKey: "AIzaSyDAPq38fcPq-8qtSbQ_YyTc0Vc0pqlqWV4",
        authDomain: "franco-system.firebaseapp.com",
        projectId: "franco-system",
        storageBucket: "franco-system.appspot.com",
        messagingSenderId: "389460380308",
        appId: "1:389460380308:web:53701896405855d9f64281"
    },
};
const serverAdress = {
    serverIp: localStorage.getItem('serverIpAddress') != null ? localStorage.getItem('serverIpAddress') : _conectionConfig__WEBPACK_IMPORTED_MODULE_0__.ipAddress,
    serverPort: _conectionConfig__WEBPACK_IMPORTED_MODULE_0__.port
};


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 68150);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ 15977);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./environments/environment */ 92340);





if (_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_4__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_1__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		70079,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		25593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		13225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		86655,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		44856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		13059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		58648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		98308,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		44690,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		64090,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		36214,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		69447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		79689,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		18840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		40749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		69667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		83288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		35473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		53634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		22855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		58737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		99632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		54446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		32275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		48050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		18994,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		23592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		35454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		92666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		64816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45534,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		94902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		91938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		78179,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		90668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		61624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		19989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		28902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		70199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		48395,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		96357,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		38268,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		15269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		32875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 79259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = ".new-background-color {\n  --background: #f44336 !important;\n}\n\n.contact-popover .popover-content {\n  width: 320px;\n}\n\n.online {\n  --background: #43a047;\n}\n\n.offline {\n  --background: #f44336;\n}\n\n.title {\n  text-align: start;\n  color: #f57c00;\n}\n\n.item {\n  text-align: start;\n}\n\nion-menu {\n  --width: 100vw;\n}\n\nion-accordion {\n  background-color: #1e1e1e;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdDQUFBO0FBQ0Y7O0FBRUE7RUFBbUMsWUFBQTtBQUVuQzs7QUFBQTtFQUNFLHFCQUFBO0FBR0Y7O0FBQUE7RUFDRSxxQkFBQTtBQUdGOztBQUFBO0VBQ0UsaUJBQUE7RUFDQSxjQUFBO0FBR0Y7O0FBQUE7RUFDRSxpQkFBQTtBQUdGOztBQUFBO0VBQ0UsY0FBQTtBQUdGOztBQUFBO0VBQ0UseUJBQUE7QUFHRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubmV3LWJhY2tncm91bmQtY29sb3J7XG4gIC0tYmFja2dyb3VuZDogI2Y0NDMzNiAhaW1wb3J0YW50O1xufVxuXG4uY29udGFjdC1wb3BvdmVyIC5wb3BvdmVyLWNvbnRlbnR7IHdpZHRoOiAzMjBweDsgfVxuXG4ub25saW5lIHtcbiAgLS1iYWNrZ3JvdW5kOiAjNDNhMDQ3O1xufVxuXG4ub2ZmbGluZSB7XG4gIC0tYmFja2dyb3VuZDogI2Y0NDMzNjtcbn1cblxuLnRpdGxlIHtcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gIGNvbG9yOiAjZjU3YzAwO1xufVxuXG4uaXRlbSB7XG4gIHRleHQtYWxpZ246IHN0YXJ0O1xufVxuXG5pb24tbWVudSB7XG4gIC0td2lkdGg6IDEwMHZ3O1xufVxuXG5pb24tYWNjb3JkaW9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDMwLCAzMCwgMzApO1xufVxuIl19 */";

/***/ }),

/***/ 93404:
/*!******************************************************************************************************!*\
  !*** ./src/app/components/change-server-ip-dialog/change-server-ip-dialog.component.scss?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGFuZ2Utc2VydmVyLWlwLWRpYWxvZy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 33603:
/*!**********************************************************************************************!*\
  !*** ./src/app/components/generic-list-dialog/generic-list-dialog.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJnZW5lcmljLWxpc3QtZGlhbG9nLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 20451:
/*!**********************************************************************************!*\
  !*** ./src/app/components/image-popover/image-popover.component.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbWFnZS1wb3BvdmVyLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 76899:
/*!********************************************************************************!*\
  !*** ./src/app/components/qr-generator/qr-generator.component.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJxci1nZW5lcmF0b3IuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 30326:
/*!******************************************************************************************!*\
  !*** ./src/app/components/qr-scanner-dialog/qr-scanner-dialog.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJxci1zY2FubmVyLWRpYWxvZy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 40001:
/*!**************************************************************************************************************!*\
  !*** ./src/app/dialog/login/cambiar-contrasenha-dialog/cambiar-contrasenha-dialog.component.scss?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYW1iaWFyLWNvbnRyYXNlbmhhLWRpYWxvZy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 99196:
/*!**************************************************************!*\
  !*** ./src/app/dialog/login/login.component.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-input {\n  text-transform: uppercase;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kseUJBQUE7QUFDSiIsImZpbGUiOiJsb2dpbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pbnB1dCB7XG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbn0iXX0= */";

/***/ }),

/***/ 33713:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/funcionario/pre-registro-funcionario/pre-registro-funcionario.component.scss?ngResource ***!
  \***************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-input {\n  text-transform: uppercase;\n}\n\n.email {\n  text-transform: lowercase !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByZS1yZWdpc3Ryby1mdW5jaW9uYXJpby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQ0FBQTtBQUNGIiwiZmlsZSI6InByZS1yZWdpc3Ryby1mdW5jaW9uYXJpby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pbnB1dCB7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG59XG5cbi5lbWFpbCB7XG4gIHRleHQtdHJhbnNmb3JtOiBsb3dlcmNhc2UgIWltcG9ydGFudDtcbn1cblxuIl19 */";

/***/ }),

/***/ 85236:
/*!****************************************************************!*\
  !*** ./src/app/pages/home/home/home.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob21lLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 22917:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/inventario/edit-inventario-item-dialog/edit-inventario-item-dialog.component.scss?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LWludmVudGFyaW8taXRlbS1kaWFsb2cuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 65385:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/inventario/edit-inventario/edit-inventario.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-accordion-group ion-accordion .ion-accordion-toggle-icon {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVkaXQtaW52ZW50YXJpby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFTTtFQUNJLFlBQUE7QUFEViIsImZpbGUiOiJlZGl0LWludmVudGFyaW8uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYWNjb3JkaW9uLWdyb3Vwe1xuICBpb24tYWNjb3JkaW9uIHtcbiAgICAgIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uIHtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICB9XG4gIH1cbn1cbiJdfQ== */";

/***/ }),

/***/ 6653:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/inventario/finalizar-inventario-resumen/finalizar-inventario-resumen.component.scss?ngResource ***!
  \**********************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmaW5hbGl6YXItaW52ZW50YXJpby1yZXN1bWVuLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 23640:
/*!***********************************************************************!*\
  !*** ./src/app/pages/inventario/inventario.component.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  background-color: #f44336 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImludmVudGFyaW8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQ0FBQTtBQUNGIiwiZmlsZSI6ImludmVudGFyaW8uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNDQzMzYgIWltcG9ydGFudDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 78243:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/inventario/list-inventario/list-inventario.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".abierto {\n  background-color: #43a047;\n}\n\n.concluido {\n  background-color: none !important;\n}\n\n.cancelado {\n  background-color: #f44336;\n}\n\nion-col {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3QtaW52ZW50YXJpby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxpQ0FBQTtBQUVGOztBQUFBO0VBQ0UseUJBQUE7QUFHRjs7QUFEQTtFQUNFLFlBQUE7QUFJRiIsImZpbGUiOiJsaXN0LWludmVudGFyaW8uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYWJpZXJ0b3tcbiAgYmFja2dyb3VuZC1jb2xvcjogIzQzYTA0Nztcbn1cbi5jb25jbHVpZG97XG4gIGJhY2tncm91bmQtY29sb3I6IG5vbmUgIWltcG9ydGFudDtcbn1cbi5jYW5jZWxhZG97XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNDQzMzY7XG59XG5pb24tY29se1xuICBjb2xvcjogd2hpdGU7XG59XG5cblxuIl19 */";

/***/ }),

/***/ 16132:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/inventario/nuevo-inventario/nuevo-inventario.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".row {\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51ZXZvLWludmVudGFyaW8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBQTtBQUNGIiwiZmlsZSI6Im51ZXZvLWludmVudGFyaW8uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucm93e1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuIl19 */";

/***/ }),

/***/ 46285:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/inventario/select-zona-dialog/select-zona-dialog.component.scss?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZWxlY3Qtem9uYS1kaWFsb2cuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 93851:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/producto/edit-producto/edit-producto.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LXByb2R1Y3RvLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 83324:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/producto/producto-dashboard/producto-dashboard.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  background-color: #f44336 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3RvLWRhc2hib2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9DQUFBO0FBQ0YiLCJmaWxlIjoicHJvZHVjdG8tZGFzaGJvYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjQ0MzM2ICFpbXBvcnRhbnQ7XG59XG4iXX0= */";

/***/ }),

/***/ 59788:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/producto/search-producto-dialog/search-producto-dialog.component.scss?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".ion-input {\n  text-transform: uppercase !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC1wcm9kdWN0by1kaWFsb2cuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQ0FBQTtBQUNGIiwiZmlsZSI6InNlYXJjaC1wcm9kdWN0by1kaWFsb2cuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW9uLWlucHV0IHtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZSAhaW1wb3J0YW50O1xufVxuIl19 */";

/***/ }),

/***/ 23987:
/*!*************************************************************!*\
  !*** ./src/app/pages/salir/salir.component.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzYWxpci5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 18998:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/info-transferencia/info-transferencia.component.scss?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".text {\n  font-size: 1em;\n}\n\n.sin-cambios {\n  color: #43a047 !important;\n}\n\n.con-cambios {\n  color: #f57c00 !important;\n}\n\n.rechazado {\n  color: #f44336 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZm8tdHJhbnNmZXJlbmNpYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRiIsImZpbGUiOiJpbmZvLXRyYW5zZmVyZW5jaWEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dCB7XG4gIGZvbnQtc2l6ZTogMWVtO1xufVxuXG4uc2luLWNhbWJpb3Mge1xuICBjb2xvcjogIzQzYTA0NyAhaW1wb3J0YW50O1xufVxuXG4uY29uLWNhbWJpb3Mge1xuICBjb2xvcjogI2Y1N2MwMCAhaW1wb3J0YW50O1xufVxuXG4ucmVjaGF6YWRvIHtcbiAgY29sb3I6ICNmNDQzMzYgIWltcG9ydGFudDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 52809:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/ingresar-codigo-pop/ingresar-codigo-pop.component.scss?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-input {\n  text-transform: uppercase;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZ3Jlc2FyLWNvZGlnby1wb3AuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5QkFBQTtBQUNGIiwiZmlsZSI6ImluZ3Jlc2FyLWNvZGlnby1wb3AuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW5wdXQge1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4iXX0= */";

/***/ }),

/***/ 76905:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/list-transferencias/list-transferencias.component.scss?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".en-origen-preparacion {\n  background-color: #54c5f8 !important;\n}\n\n.en-origen-transito {\n  background-color: #f57c00 !important;\n}\n\n.en-destino-recepcion {\n  background-color: #a0435a !important;\n}\n\n.en-destino-recepcion-concluida {\n  background-color: none !important;\n}\n\n.en-origen {\n  background-color: #43a047 !important;\n}\n\n.item {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3QtdHJhbnNmZXJlbmNpYXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQ0FBQTtBQUNGOztBQUVBO0VBQ0Usb0NBQUE7QUFDRjs7QUFFQTtFQUNFLG9DQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQ0FBQTtBQUNGOztBQUVBO0VBQ0Usb0NBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7QUFDRiIsImZpbGUiOiJsaXN0LXRyYW5zZmVyZW5jaWFzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVuLW9yaWdlbi1wcmVwYXJhY2lvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM1NGM1ZjggIWltcG9ydGFudDtcbn1cblxuLmVuLW9yaWdlbi10cmFuc2l0byB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNTdjMDAgIWltcG9ydGFudDtcbn1cblxuLmVuLWRlc3Rpbm8tcmVjZXBjaW9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwNDM1YSAhaW1wb3J0YW50O1xufVxuXG4uZW4tZGVzdGluby1yZWNlcGNpb24tY29uY2x1aWRhIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4uZW4tb3JpZ2VuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzQzYTA0NyAhaW1wb3J0YW50O1xufVxuXG4uaXRlbSB7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuXG4iXX0= */";

/***/ }),

/***/ 71625:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/modificar-item-dialog/modificar-item-dialog.component.scss?ngResource ***!
  \************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RpZmljYXItaXRlbS1kaWFsb2cuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 19862:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencia/transferencia.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  background-color: #f44336 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zZmVyZW5jaWEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQ0FBQTtBQUNGIiwiZmlsZSI6InRyYW5zZmVyZW5jaWEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNDQzMzYgIWltcG9ydGFudDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 33383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <ion-menu side=\"start\" content-id=\"main-content\">\n    <ion-header>\n      <ion-toolbar\n        translucent\n        [class.online]=\"online\"\n        [class.offline]=\"!online\"\n      >\n        <ion-row class=\"ion-align-items-center\">\n          <ion-col size=\"6\">\n            <ion-title>Menu</ion-title>\n          </ion-col>\n          <ion-col size=\"6\" [class.online]=\"online\" [class.offline]=\"!online\">\n            {{ online ? 'Online' : 'Offline' }}\n          </ion-col>\n        </ion-row>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content\n      *ngIf=\"loginService?.usuarioActual?.id !== null\"\n      style=\"background-color: rgb(32, 32, 32)\"\n    >\n      <ion-list>\n        <ion-item\n          (click)=\"onAvatarClick()\"\n          [hidden]=\"loginService.usuarioActual === null\"\n          style=\"text-align: center\"\n        >\n          <ion-avatar>\n            <img alt=\"\" [src]=\"'/assets/avatar.svg'\" />\n          </ion-avatar>\n          <ion-label\n            >{{ loginService.usuarioActual?.persona?.id }} -\n            {{\n              loginService.usuarioActual?.persona?.nombre | titlecase\n            }}</ion-label\n          >\n        </ion-item>\n        <ion-accordion-group>\n          <ion-accordion value=\"first\">\n            <ion-item slot=\"header\">\n              <ion-icon name=\"person-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Mi cuenta</ion-label>\n            </ion-item>\n            <ion-item\n              slot=\"content\"\n              (click)=\"openInfoPersonales(); closeMenu()\"\n              style=\"padding-left: 10%\"\n            >\n              <ion-icon name=\"id-card-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Informaciones personales</ion-label>\n            </ion-item>\n            <ion-item\n              slot=\"content\"\n              [routerLink]=\"['/mis-finanzas']\"\n              (click)=\"closeMenu()\"\n              style=\"padding-left: 10%\"\n            >\n              <ion-icon name=\"wallet-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Mis finanzas</ion-label>\n            </ion-item>\n          </ion-accordion>\n        </ion-accordion-group>\n        <ion-item [routerLink]=\"['/producto']\" (click)=\"closeMenu()\">\n          <ion-icon name=\"beer-outline\" slot=\"start\"></ion-icon>\n          <ion-label>Producto</ion-label>\n        </ion-item>\n        <ion-item\n          *ngIf=\"loginService.usuarioActual?.roles?.includes('VER INVENTARIO')\"\n          [routerLink]=\"['/inventario']\"\n          (click)=\"closeMenu()\"\n        >\n          <ion-icon name=\"newspaper-outline\" slot=\"start\"></ion-icon>\n          <ion-label>Inventario</ion-label>\n        </ion-item>\n        <!--<ion-item [routerLink]=\"['/scanner']\" (click)=\"closeMenu()\">\n          <ion-icon name=\"clipboard\" slot=\"start\"></ion-icon>\n          <ion-label>Scanner</ion-label>\n        </ion-item> -->\n        <ion-item\n          *ngIf=\"\n            loginService.usuarioActual?.roles?.includes('VER TRANSFERENCIA')\n          \"\n          [routerLink]=\"['/transferencias']\"\n          (click)=\"closeMenu()\"\n        >\n          <ion-icon name=\"git-compare-outline\" slot=\"start\"></ion-icon>\n          <ion-label>Transferencia</ion-label>\n        </ion-item>\n\n        <ion-accordion-group>\n          <ion-accordion value=\"first\">\n            <ion-item slot=\"header\">\n              <ion-icon name=\"barbell-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Operaciones</ion-label>\n            </ion-item>\n            <ion-item\n              slot=\"content\"\n              [routerLink]=\"['/operaciones/caja']\"\n              (click)=\"closeMenu()\"\n              style=\"padding-left: 10%\"\n            >\n              <ion-icon name=\"cash-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Caja</ion-label>\n            </ion-item>\n          </ion-accordion>\n        </ion-accordion-group>\n\n        <ion-accordion-group>\n          <ion-accordion value=\"first\">\n            <ion-item slot=\"header\">\n              <ion-icon name=\"settings-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Configuración</ion-label>\n            </ion-item>\n            <ion-item\n              slot=\"content\"\n              (click)=\"onIpChange(); closeMenu()\"\n              style=\"padding-left: 10%\"\n            >\n              <ion-icon name=\"globe-outline\" slot=\"start\"></ion-icon>\n              <ion-label>Configuración del servidor</ion-label>\n            </ion-item>\n          </ion-accordion>\n        </ion-accordion-group>\n\n        <ion-item (click)=\"onSalir()\">\n          <ion-icon name=\"exit\" slot=\"start\"></ion-icon>\n          <ion-label>Salir</ion-label>\n        </ion-item>\n        <!-- <ion-item>\n          <ion-icon name=\"heart\" slot=\"start\"></ion-icon>\n          <ion-label>Favorites</ion-label>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"archive\" slot=\"start\"></ion-icon>\n          <ion-label>Archived</ion-label>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n          <ion-label>Trash</ion-label>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"warning\" slot=\"start\"></ion-icon>\n          <ion-label>Spam</ion-label>\n        </ion-item> -->\n      </ion-list>\n    </ion-content>\n    <div style=\"width: 100%; text-align: center\">\n      Versión actual: {{ currentVersion }}\n    </div>\n    <br />\n  </ion-menu>\n\n  <div class=\"ion-page\" id=\"main-content\" style=\"height: 100%\">\n    <ion-header>\n      <!-- <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n          <ion-icon name=\"refresh\" slot=\"start\"></ion-icon>\n        </ion-buttons>\n        <ion-title>BODEGA FRANCO</ion-title>\n      </ion-toolbar> -->\n      <ion-toolbar class=\"new-background-color\">\n        <ion-buttons slot=\"start\">\n          <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n        </ion-buttons>\n        <ion-buttons slot=\"primary\">\n          <ion-button>\n            <ion-icon\n              [hidden]=\"true\"\n              slot=\"icon-only\"\n              ios=\"ellipsis-horizontal\"\n              md=\"ellipsis-vertical\"\n            ></ion-icon>\n          </ion-button>\n        </ion-buttons>\n\n        <!-- <ion-title style=\"text-align: center\">BODEGA FRANCO</ion-title> -->\n        <ion-row>\n          <ion-col size=\"12\" class=\"center\">\n            <img\n              [src]=\"isFarma ? '/assets/logof.png' : '/assets/logo.png'\"\n              alt=\"\"\n              style=\"width: auto; max-height: 45px; object-fit: contain\"\n            />\n          </ion-col>\n        </ion-row>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content class=\"ion-padding\">\n      <ion-router-outlet></ion-router-outlet>\n    </ion-content>\n  </div>\n</ion-app>\n";

/***/ }),

/***/ 12666:
/*!******************************************************************************************************!*\
  !*** ./src/app/components/change-server-ip-dialog/change-server-ip-dialog.component.html?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"12\">\n      <h3>Configuración del servidor</h3>\n    </ion-col>\n  </ion-row>\n  <ion-card (click)=\"onBodegaClick()\">\n    <h3>Bodega Franco</h3>\n    <p>Ip: 150.136.137.98</p>\n    <p>Port: 8081</p>\n  </ion-card>\n  <ion-card (click)=\"onFarmaciaClick()\">\n    <h3>Farmacia Franco</h3>\n    <p>Ip: 158.101.114.87</p>\n    <p>Port: 8081</p>\n  </ion-card>\n  <ion-item class=\"ion-text-right\">\n    <ion-label>Custom IP</ion-label>\n    <ion-input type=\"text\" [formControl]=\"serverIpControl\"> </ion-input>\n  </ion-item>\n  <ion-item class=\"ion-text-right\">\n    <ion-label>Custom Port</ion-label>\n    <ion-input type=\"text\" [formControl]=\"serverPortControl\"> </ion-input>\n  </ion-item>\n  <ion-row>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\"\n        >Cancelar</ion-button\n      >\n    </ion-col>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button fill=\"clear\" class=\"btn-success-flat\" (click)=\"onGuardar()\"\n        >Aceptar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 75624:
/*!**********************************************************************************************!*\
  !*** ./src/app/components/generic-list-dialog/generic-list-dialog.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content fullscreen>\n  <ion-col size=\"2\">\n    <ion-icon\n      name=\"arrow-back\"\n      style=\"font-size: 1.5em\"\n      (click)=\"onBack()\"\n    ></ion-icon>\n  </ion-col>\n  <ion-col size=\"12\">\n    <ion-label>{{data?.titulo | titlecase}}</ion-label>\n  </ion-col>\n  <ion-row *ngIf=\"data?.search\">\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Buscar</ion-label>\n        <ion-input\n          #buscarInput\n          [formControl]=\"buscarControl\"\n          autocapitalize=\"on\"\n          (keyup.enter)=\"onBuscarClick()\"\n        ></ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row *ngIf=\"buscarControl.valid\">\n    <ion-col size=\"12\" style=\"text-align: center\">\n      <ion-button\n        class=\"btn-success-flat\"\n        fill=\"clear\"\n        (click)=\"onBuscarClick()\"\n        >Buscar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n  <ion-list>\n    <ng-container *ngFor=\"let item of itemList\">\n      <ion-card (click)=\"onItemClick(item)\">\n        <ion-grid>\n          <ion-row *ngFor=\"let info of data.tableData\" wrap>\n            <ng-container *ngIf=\"!info.nested\">\n              <ion-col [size]=\"info.width\"\n                >{{ info.nombre }}: {{ item[info?.id] }}</ion-col\n              >\n            </ng-container>\n            <ng-container *ngIf=\"info.nested\">\n              <ion-col [size]=\"info.width\"\n                >{{ info.nombre }}:\n                {{ item[info?.id][info?.nestedId] }}</ion-col\n              >\n            </ng-container>\n          </ion-row>\n        </ion-grid>\n      </ion-card>\n    </ng-container>\n  </ion-list>\n</ion-content>\n";

/***/ }),

/***/ 81361:
/*!**********************************************************************************!*\
  !*** ./src/app/components/image-popover/image-popover.component.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row class=\"ion-align-items-center\">\n    <ion-col size=\"12\" class=\"ion-align-items-center\">\n      <img [src]=\"data?.image!==null ? data?.image : '/assets/no-image.png'\" alt=\"img\">\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 95828:
/*!********************************************************************************!*\
  !*** ./src/app/components/qr-generator/qr-generator.component.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <div style=\"text-align: center\">\n    <ngx-qrcode [value]=\"value\" [scale]=\"6\"> </ngx-qrcode>\n    <br />\n    <div>Utilice la camara del smartphone</div>\n    <div>para capturar imagenes</div>\n    <!-- <a [href]=\"value\">\n      <button mat-flat-button > Ir a página</button>\n    </a> -->\n    <!-- <button mat-raised-button color=\"accent\" matTooltip=\"Una vez cargada la imagen, pulse aquí para que la busquemos =)\" (click)=\"onRefresh()\">Refrescar</button> -->\n  </div>\n  <!-- <div style=\"text-align: center;\">\n    <div><h3>Código alfanumerico</h3></div>\n    <div><h1>{{codigoAlfanumerico | uppercase}}</h1></div>\n  </div> -->\n\n  <div style=\"text-align: center;\">\n    <ion-button (click)=\"onSalir()\" expand=\"block\" fill=\"clear\">\n      Salir\n    </ion-button>\n  </div>\n\n  <div fxLayout=\"column\" fxLayoutAlign=\"space-between center\" *ngIf=\"isWaiting\">\n    <h2 fxFlex=\"20\">Aguardando...</h2>\n    <mat-spinner fxFlex style=\"width: 100px; height: 100px\"></mat-spinner>\n  </div>\n</ion-content>\n";

/***/ }),

/***/ 83777:
/*!******************************************************************************************!*\
  !*** ./src/app/components/qr-scanner-dialog/qr-scanner-dialog.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-modal [isOpen]=\"true\">\n  <ion-grid fixed>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onExit()\"\n      ></ion-icon>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ng-template>\n          <ngx-scanner-qrcode #action=\"scanner\" (data)=\"onSuccess($event)\" (error)=\"onError($event)\"></ngx-scanner-qrcode>\n        </ng-template>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-modal>\n";

/***/ }),

/***/ 20347:
/*!**************************************************************************************************************!*\
  !*** ./src/app/dialog/login/cambiar-contrasenha-dialog/cambiar-contrasenha-dialog.component.html?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"12\" class=\"title\"> Cambiar contraseña </ion-col>\n    <ion-col size=\"12\">\n      <p>Cree una contraseña cómoda y segura que sea diferente a 123</p>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Nueva contraseña</ion-label>\n        <ion-input\n          [formControl]=\"password1Control\"\n          [type]=\"showPassword1 ? 'text' : 'password'\"\n          (keyup.enter)=\"onLogin()\"\n        ></ion-input>\n        <ion-icon\n          style=\"padding-top: 5px\"\n          (click)=\"showPassword1 = !showPassword1\"\n          [name]=\"showPassword1 ? 'eye-off' : 'eye'\"\n          slot=\"end\"\n        ></ion-icon>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Nueva contraseña</ion-label>\n        <ion-input\n          [formControl]=\"password2Control\"\n          [type]=\"showPassword2 ? 'text' : 'password'\"\n        ></ion-input>\n        <ion-icon\n          style=\"padding-top: 5px\"\n          (click)=\"showPassword2 = !showPassword2\"\n          [name]=\"showPassword2 ? 'eye-off' : 'eye'\"\n          slot=\"end\"\n        ></ion-icon>\n      </ion-item>\n      <div style=\"color: red; padding-top: 0.2rem\" *ngIf=\"isError\">\n        Las contraseñas no coinciden\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-item-divider></ion-item-divider>\n  <ion-row>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\"\n        >Cancelar</ion-button\n      >\n    </ion-col>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button\n        fill=\"clear\"\n        class=\"btn-success-flat\"\n        (click)=\"onAceptar()\"\n        [disabled]=\"formGroup.invalid || isError\"\n        >Aceptar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 11073:
/*!**************************************************************!*\
  !*** ./src/app/dialog/login/login.component.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content style=\"top: 20%\">\n  <ion-row *ngIf=\"selectedUsuario === null\">\n    <ion-col size=\"12\" class=\"center\">\n      <img src=\"/assets/logo.png\" alt=\"\" style=\"width: 200px\" (click)=\"onDev()\"/>\n      <p style=\"margin-top: 2px\">POWERED BY FRC</p>\n    </ion-col>\n  </ion-row>\n\n  <ion-row *ngIf=\"selectedUsuario === null\">\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Usuario</ion-label>\n        <ion-input [formControl]=\"usuarioControl\"></ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row *ngIf=\"selectedUsuario === null\">\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Contraseña</ion-label>\n        <ion-input\n          [formControl]=\"passwordControl\"\n          [type]=\"showPassword ? 'text' : 'password'\"\n          (keyup.enter)=\"onLogin()\"\n        ></ion-input>\n        <ion-icon\n          style=\"padding-top: 5px\"\n          (click)=\"showPassword = !showPassword\"\n          [name]=\"showPassword ? 'eye-off' : 'eye'\"\n          slot=\"end\"\n        ></ion-icon>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-row *ngIf=\"selectedUsuario === null\">\n    <ion-col size=\"12\">\n      <ion-button\n        type=\"submit\"\n        color=\"primary\"\n        expand=\"block\"\n        [disabled]=\"formGroup.invalid\"\n        (click)=\"onLogin()\"\n        >Entrar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item [hidden]=\"error === null\">\n        <div\n          style=\"color: red; font-size: 0.8em; width: 100%; text-align: center\"\n        >\n          {{ error }}\n        </div>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-row [hidden]=\"selectedUsuario === null\" style=\"text-align: center\">\n    <ion-col size=\"12\">\n      {{ msg | uppercase }}\n      <p>\n        {{ selectedUsuario?.persona?.nombre | uppercase }}\n      </p>\n    </ion-col>\n  </ion-row>\n\n  <ion-row>\n    <ion-col size=\"12\" style=\"height: 30px\"></ion-col>\n  </ion-row>\n\n  <ion-row\n    *ngIf=\"selectedUsuario === null\"\n    style=\"width: 100%\"\n    style=\"bottom: 10px\"\n  >\n    <ion-col size=\"12\">\n      <ion-button\n        type=\"button\"\n        class=\"btn-success-flat\"\n        (click)=\"onSolicitarNuevoUsuario()\"\n        expand=\"block\"\n        fill=\"clear\"\n      >\n        Solicitar usuario\n      </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 73118:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/funcionario/pre-registro-funcionario/pre-registro-funcionario.component.html?ngResource ***!
  \***************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"12\" class=\"center\">\n      <img\n        src=\"/assets/logo.png\"\n        alt=\"\"\n        style=\"width: auto; max-height: 50px; object-fit: contain\"\n      />\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\" class=\"center\">\n      <p>\n        Complete este formulario y en breve recibirá las credenciales para\n        acceso al sistema\n      </p>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\" class=\"center\"> Formulario de pre registro </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Nombre completo</ion-label>\n        <ion-input type=\"text\" [formControl]=\"nombreCompleto\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Apodo</ion-label>\n        <ion-input type=\"text\" [formControl]=\"apodo\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Documento (C.I.)</ion-label>\n        <ion-input type=\"text\" [formControl]=\"documento\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Teléfono personal</ion-label>\n        <ion-input type=\"text\" [formControl]=\"telefonoPersonal\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Teléfono de emergencia</ion-label>\n        <ion-input type=\"text\" [formControl]=\"telefonoEmergencia\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\"\n          >Nombre de contacto de emergencia</ion-label\n        >\n        <ion-input type=\"text\" [formControl]=\"nombreContactoEmergencia\">\n        </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Email</ion-label>\n        <ion-input class=\"email\" type=\"email\" [formControl]=\"email\">\n        </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Ciudad</ion-label>\n        <ion-input type=\"text\" [formControl]=\"ciudad\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Dirección</ion-label>\n        <ion-input type=\"text\" [formControl]=\"direccion\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Sucursal en donde trabajas</ion-label>\n        <ion-select\n          cancelText=\"Cancelar\"\n          okText=\"Aceptar\"\n          [formControl]=\"sucursal\"\n        >\n          <ion-select-option *ngFor=\"let sucursal of sucursalList\" [value]=\"sucursal?.nombre\">{{sucursal?.nombre | titlecase}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Fecha de nacimiento</ion-label>\n        <ion-input type=\"date\" [formControl]=\"fechaNacimiento\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Fecha de ingreso</ion-label>\n        <ion-input type=\"date\" [formControl]=\"fechaIngreso\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Posee registro de conducir?</ion-label>\n        <ion-toggle\n          class=\"button\"\n          [formControl]=\"registroConducir\"\n        ></ion-toggle>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-item-divider></ion-item-divider>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-label>Que sabes hacer?</ion-label>\n      <p>\n        A continuación, puedes seleccionar las aptitudes que consideras tener ya\n        sea en nivel básico, intermedio o avanzado.\n      </p>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Informática</ion-label>\n        <ion-select\n          multiple=\"true\"\n          cancelText=\"Cancelar\"\n          okText=\"Aceptar\"\n          [formControl]=\"habilidadesInformaticas\"\n        >\n          <ion-select-option value=\"Excel\">Excel</ion-select-option>\n          <ion-select-option value=\"Word\">Word</ion-select-option>\n          <ion-select-option value=\"Power Point\">Power Point</ion-select-option>\n          <ion-select-option value=\"Photoshop\">Photoshop</ion-select-option>\n          <ion-select-option value=\"Social network\"\n            >Social network</ion-select-option\n          >\n          <ion-select-option value=\"Programación\"\n            >Programación</ion-select-option\n          >\n          <ion-select-option value=\"Redes\">Redes</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Generales</ion-label>\n        <ion-select\n          multiple=\"true\"\n          cancelText=\"Cancelar\"\n          okText=\"Aceptar\"\n          [formControl]=\"habilidadesGenerales\"\n        >\n          <ion-select-option value=\"Albañileria\">Albañileria</ion-select-option>\n          <ion-select-option value=\"Plomería\">Plomería</ion-select-option>\n          <ion-select-option value=\"Carpintería\">Carpintería</ion-select-option>\n          <ion-select-option value=\"Carpintería\">Panadería</ion-select-option>\n          <ion-select-option value=\"Carpintería\">Carnicería</ion-select-option>\n          <ion-select-option value=\"Mecánica automotiva\"\n            >Mecánica automotiva</ion-select-option\n          >\n          <ion-select-option value=\"Instalación de cámaras\"\n            >Instalación de cámaras</ion-select-option\n          >\n          <ion-select-option value=\"Eléctrica\">Eléctrica</ion-select-option>\n          <ion-select-option value=\"Electrónica\">Electrónica</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-item-divider></ion-item-divider>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Nivel académico</ion-label>\n        <ion-select\n          cancelText=\"Cancelar\"\n          okText=\"Aceptar\"\n          [formControl]=\"nivelEducacion\"\n        >\n          <ion-select-option value=\"Primaria\">Primaria</ion-select-option>\n          <ion-select-option value=\"Secundaria\">Secundaria</ion-select-option>\n          <ion-select-option value=\"Bachillerato\"\n            >Bachillerato</ion-select-option\n          >\n          <ion-select-option value=\"Educ. Superior\"\n            >Educ. Superior</ion-select-option\n          >\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-item-divider></ion-item-divider>\n  <!-- <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Orientación sexual</ion-label>\n        <ion-select cancelText=\"Cancelar\" okText=\"Aceptar\">\n          <ion-select-option value=\"Hétero\">Hétero</ion-select-option>\n          <ion-select-option value=\"Semi hétero\">Semi hétero</ion-select-option>\n          <ion-select-option value=\"Casi casi hétero\"\n            >Casi casi hétero</ion-select-option\n          >\n          <ion-select-option value=\"Homosexual\">Homosexual</ion-select-option>\n          <ion-select-option value=\"Ambo lo dó\">Ambo lo dó</ion-select-option>\n          <ion-select-option value=\"Ninguno\">Nambopúi</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row> -->\n  <ion-item-divider></ion-item-divider>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\"\n          >Algún mensaje para la empresa? =)</ion-label\n        >\n        <ion-textarea [formControl]=\"observacion\"></ion-textarea>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-item-divider></ion-item-divider>\n  <ion-row>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\"\n        >Cancelar</ion-button\n      >\n    </ion-col>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button fill=\"clear\" class=\"btn-success-flat\" (click)=\"onAceptar()\" [disabled]=\"formGroup.invalid && false\"\n        >Aceptar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n  <br>\n  <br>\n</ion-content>\n";

/***/ }),

/***/ 98132:
/*!****************************************************************!*\
  !*** ./src/app/pages/home/home/home.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "";

/***/ }),

/***/ 9301:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/inventario/edit-inventario-item-dialog/edit-inventario-item-dialog.component.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"12\" class=\"center\">\n      <h3>{{ data?.producto?.descripcion | titlecase }}</h3>\n      <p>Presentación: {{ data?.presentacion?.cantidad | number: '1.0-2' }}</p>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item class=\"ion-text-right\">\n        <ion-label>Cantidad</ion-label>\n        <!-- <ion-input [type]=\"producto?.isPesable ? 'decimal' : 'numeric'\" [formControl]=\"cantidadControl\"> </ion-input> -->\n        <ion-input type=\"number\" [formControl]=\"cantidadControl\" autofocus=\"false\"> </ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Vencimiento</ion-label>\n        <ion-input\n          type=\"date\"\n          [formControl]=\"vencimientoControl\"\n          value=\"{{ vencimientoControl.value | date: 'yyyy-MM-dd' }}\"\n        ></ion-input>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label>Estado</ion-label>\n        <ion-select interface=\"popover\" [formControl]=\"estadoControl\">\n          <ion-select-option *ngFor=\"let estado of estadosList\" [value]=\"estado\"\n            >{{ estado }}\n          </ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\"\n        >Cancelar</ion-button\n      >\n    </ion-col>\n    <ion-col size=\"6\" class=\"center\">\n      <ion-button\n        fill=\"clear\"\n        class=\"btn-success-flat\"\n        (click)=\"onAceptar()\"\n        [disabled]=\"formGroup.invalid\"\n        >Aceptar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 50633:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/inventario/edit-inventario/edit-inventario.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-card>\n    <ion-row>\n      <ion-col size=\"2\">\n        <ion-icon\n          name=\"arrow-back\"\n          style=\"font-size: 1.5em\"\n          (click)=\"onBack()\"\n        ></ion-icon>\n      </ion-col>\n      <ion-col size=\"8\" style=\"text-align: center\"\n        >Detalles de inventario</ion-col\n      >\n    </ion-row>\n    <!-- primera linea -->\n    <ion-row>\n      <ion-col size=\"3\">\n        <div class=\"title\" fxFlex=\"50\">Id</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.id }}\n        </div>\n      </ion-col>\n      <ion-col size=\"5\">\n        <div class=\"title\" fxFlex=\"50\">Sucursal</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.sucursal?.nombre | titlecase }}\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n        <div class=\"title\" fxFlex=\"50\">Estado</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.estado }}\n        </div>\n      </ion-col>\n    </ion-row>\n    <!-- segunda linea -->\n    <ion-row>\n      <ion-col size=\"3\">\n        <div class=\"title\" fxFlex=\"50\">Tipo</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.tipo }}\n        </div>\n      </ion-col>\n      <ion-col size=\"5\">\n        <div class=\"title\" fxFlex=\"50\">Inicio</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.fechaInicio | date: 'short' }}\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n        <div class=\"title\" fxFlex=\"50\">Fin</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.fechaFin | date: 'short' }}\n        </div>\n      </ion-col>\n    </ion-row>\n    <!-- tercera linea -->\n    <ion-row>\n      <ion-col size=\"8\">\n        <div class=\"title\" fxFlex=\"50\">Responsable</div>\n        <div class=\"item\" fxFlex=\"50\">\n          {{ selectedInventario?.usuario?.persona?.nombre | titlecase }}\n        </div>\n      </ion-col>\n      <ion-col size=\"4\" style=\"text-align: center\">\n        <ion-button\n          class=\"btn-success-flat\"\n          fill=\"clear\"\n          (click)=\"onMenuClick()\"\n          >MENU</ion-button\n        >\n      </ion-col>\n    </ion-row>\n    <!-- <ion-row>\n      <ion-col size=\"12\" style=\"text-align: center\">\n        <ion-button class=\"btn-success-flat\" fill=\"clear\" (click)=\"onRefresh()\"\n          >Actualizar</ion-button\n        >\n      </ion-col>\n    </ion-row> -->\n  </ion-card>\n\n  <ion-row>\n    <ion-col size=\"2\"> </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\">Zonas</ion-col>\n    <ion-col size=\"2\" style=\"text-align: center\">\n      <ion-icon\n        name=\"funnel\"\n        style=\"font-size: 1.5em\"\n        (click)=\"openFilterMenu()\"\n      ></ion-icon>\n    </ion-col>\n  </ion-row>\n\n  <ion-accordion-group>\n    <ion-accordion\n      *ngFor=\"\n        let invPro of selectedInventario?.inventarioProductoList;\n        let i = index\n      \"\n      [value]=\"invPro.id\"\n      (click)=\"onGetProductosItemList(invPro, i)\"\n    >\n      <ion-item\n        slot=\"header\"\n        [class.estado-abierto]=\"invPro?.concluido === false\"\n        [hidden]=\"\n          !(\n            (mostrarControl.value === 'MIOS' &&\n              invPro?.usuario?.id === mainService?.usuarioActual?.id) ||\n            mostrarControl.value === 'TODOS'\n          )\n        \"\n      >\n        <ion-label>\n          Zona: {{ invPro?.zona?.descripcion | titlecase }}\n          <p class=\"white\">\n            Sector: {{ invPro?.zona?.sector.descripcion | titlecase }}\n          </p>\n          <p class=\"white\">\n            {{ invPro?.usuario?.persona?.nombre | titlecase }}\n          </p>\n          <p class=\"white\">\n            {{\n              invPro?.concluido === true\n                ? 'Concluido'\n                : invPro?.concluido === false\n                ? 'En proceso'\n                : null\n            }}\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-list slot=\"content\">\n        <ion-row class=\"dark2\">\n          <ion-col size=\"12\" class=\"center\">\n            <ion-button\n              class=\"btn-success-flat\"\n              fill=\"clear\"\n              (click)=\"onAddProducto(invPro, i2)\"\n              expand=\"block\"\n              *ngIf=\"\n                invPro?.concluido !== true &&\n                mainService?.usuarioActual?.id === invPro?.usuario?.id &&\n                selectedInventario?.estado === 'ABIERTO'\n              \"\n            >\n              + Producto\n            </ion-button>\n          </ion-col>\n        </ion-row>\n        <ng-container\n          *ngFor=\"\n            let invProItem of invPro?.inventarioProductoItemList;\n            let i2 = index\n          \"\n        >\n          <ion-item class=\"dark2\">\n            <ion-label>\n              <ion-row>\n                <ion-col size=\"10\">\n                  <h3>\n                    {{\n                      invProItem?.presentacion?.producto?.descripcion\n                        | titlecase\n                    }}\n                  </h3>\n                  <h5>\n                    Presentación:\n                    {{ invProItem?.presentacion?.cantidad | number: '1.0-2' }}\n                  </h5>\n                </ion-col>\n                <ion-col size=\"2\" class=\"ion-text-end\">\n                  {{ invProItem.cantidad | number: '1.0-3' }}</ion-col\n                >\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"4\">\n                  <p class=\"title\">Vencimiento:</p>\n                  <p>\n                    {{ invProItem.vencimiento | date: 'shortDate' }}\n                  </p>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <p class=\"title\">Estado:</p>\n                  <p>{{ invProItem.estado }}</p>\n                </ion-col>\n                <ion-col size=\"2\">\n                  <ion-icon\n                    class=\"btn-success-flat\"\n                    (click)=\"onEditProducto(invProItem, i2, invPro)\"\n                    name=\"create-outline\"\n                    size=\"large\"\n                    *ngIf=\"\n                      invPro?.concluido !== true &&\n                      selectedInventario?.estado === 'ABIERTO'\n                    \"\n                  >\n                  </ion-icon>\n                </ion-col>\n                <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n                <ion-col size=\"2\">\n                  <ion-icon\n                    class=\"btn-danger-flat\"\n                    (click)=\"onDeleteProducto(invProItem, i2, invPro)\"\n                    name=\"trash-outline\"\n                    size=\"large\"\n                    *ngIf=\"\n                      invPro?.concluido !== true &&\n                      selectedInventario?.estado === 'ABIERTO'\n                    \"\n                  >\n                  </ion-icon>\n                </ion-col>\n              </ion-row>\n            </ion-label>\n          </ion-item>\n        </ng-container>\n\n        <ion-row class=\"dark2\">\n          <ion-col class=\"center\">\n            <ion-button\n              class=\"btn-success-flat\"\n              fill=\"clear\"\n              (click)=\"onCargarMenos(invPro, i)\"\n              expand=\"block\"\n              *ngIf=\"invPro?.inventarioProductoItemList?.length > 0\"\n              [disabled]=\"invPro?.inventarioProductoItemList?.length < 6\"\n            >\n              Menos\n            </ion-button>\n          </ion-col>\n          <ion-col class=\"center\">\n            <ion-button\n              class=\"btn-success-flat\"\n              fill=\"clear\"\n              (click)=\"onCargarMas(invPro, i)\"\n              expand=\"block\"\n              *ngIf=\"invPro?.inventarioProductoItemList?.length > 0\"\n              [disabled]=\"invPro?.inventarioProductoItemList?.length < 4\"\n            >\n              Cargar más\n            </ion-button>\n          </ion-col>\n        </ion-row>\n\n        <ion-row class=\"dark2\">\n          <ion-col size=\"12\" class=\"center\">\n            <ion-button\n              class=\"btn-success-flat\"\n              fill=\"clear\"\n              (click)=\"\n                invPro?.concluido === true\n                  ? onReabrirZona(invPro, i)\n                  : onFinalizarZona(invPro, i)\n              \"\n              expand=\"block\"\n              [disabled]=\"\n                mainService?.usuarioActual?.id !== invPro?.usuario?.id\n              \"\n              *ngIf=\"selectedInventario?.estado === 'ABIERTO'\"\n            >\n              {{\n                invPro?.concluido === true ? 'Reabrir Zona' : 'Finalizar Zona'\n              }}\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-list>\n    </ion-accordion>\n    <ion-row>\n      <ion-col size=\"12\" style=\"text-align: center\">\n        <ion-button\n          *ngIf=\"selectedInventario?.estado === 'ABIERTO'\"\n          class=\"btn-success-flat\"\n          fill=\"clear\"\n          (click)=\"onAddZona()\"\n          >+ Zona</ion-button\n        >\n      </ion-col>\n    </ion-row>\n  </ion-accordion-group>\n  <!-- <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button class=\"btn-success\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab> -->\n</ion-content>\n";

/***/ }),

/***/ 14479:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/inventario/finalizar-inventario-resumen/finalizar-inventario-resumen.component.html?ngResource ***!
  \**********************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\"\n      >Resumen del Inventario</ion-col\n    >\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"4\" class=\"title\"> Sucursal: </ion-col>\n    <ion-col size=\"8\">\n      {{ selectedInventario?.sucursal?.nombre | titlecase }}\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"4\" class=\"title\"> Cant. sectores: </ion-col>\n    <ion-col size=\"2\">\n      {{ sectorList?.length }}\n    </ion-col>\n    <ion-col size=\"4\" class=\"title\"> Cant. zonas: </ion-col>\n    <ion-col size=\"2\">\n      {{ cantidadZonas }}\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"4\">\n      <ion-row class=\"title\"> Inicio </ion-row>\n      <ion-row>\n        {{ selectedInventario?.fechaInicio | date: 'short' }}\n      </ion-row>\n    </ion-col>\n    <ion-col size=\"4\">\n      <ion-row class=\"title\"> Fin </ion-row>\n      <ion-row>\n        {{ selectedInventario?.fechaFin | date: 'short' }}\n      </ion-row>\n    </ion-col>\n    <ion-col size=\"4\">\n      <ion-row class=\"title\"> Duración </ion-row>\n      <ion-row>\n        {{ duracion }}\n      </ion-row>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"5\" class=\"title\">Colaboradores: </ion-col>\n    <ion-col size=\"4\">\n      {{ colaboradores.length }}\n    </ion-col>\n  </ion-row>\n  <ion-row\n    *ngIf=\"\n      selectedInventario?.estado === 'ABIERTO' &&\n      mainService?.usuarioActual?.id === selectedInventario?.usuario?.id\n    \"\n  >\n    <ion-col size=\"12\" style=\"text-align: center\">\n      <ion-button class=\"btn-success-flat\" fill=\"clear\" (click)=\"onFinalizar()\"\n        >Finalizar Inventario</ion-button\n      >\n    </ion-col>\n  </ion-row>\n  <ion-row\n    *ngIf=\"\n      selectedInventario?.estado === 'CONCLUIDO' &&\n      mainService?.usuarioActual?.id === selectedInventario?.usuario?.id\n    \"\n  >\n    <ion-col size=\"12\" style=\"text-align: center\">\n      <ion-button class=\"btn-danger-flat\" fill=\"clear\" (click)=\"onCancelar()\"\n        >Cancelar Invetario</ion-button\n      >\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-card style=\"color: white\">\n        <ion-card-header>\n          Progreso actual:\n          {{ (terminadas * 100) / cantidadZonas | number: '1.0-0' }} %\n        </ion-card-header>\n        <ion-card-content>\n          <canvas\n            #doughnutCanvas\n            style=\"position: relative; height: 20vh; width: 40vw; color: white\"\n          ></canvas>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ }),

/***/ 16475:
/*!***********************************************************************!*\
  !*** ./src/app/pages/inventario/inventario.component.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-card class=\"card\" [routerLink]=\"['list']\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Histórico de Inventarios</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Inventarios en los cuales estas vinculado\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"onNuevoInventario()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Nuevo inventario</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Comenzar un nuevo Inventario\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"onScanQr()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Unirme a inventario</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Solicite al encargado el código QR del inventario para unirte\n    </ion-card-content>\n  </ion-card>\n\n  <!-- <ion-card class=\"card\" (click)=\"ingresarCodigo()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Ingresar código</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Solicite al encargado el código del inventario\n    </ion-card-content>\n  </ion-card> -->\n</ion-content>\n";

/***/ }),

/***/ 61079:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/inventario/list-inventario/list-inventario.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content style=\"width: 100%\">\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\">Lista de Inventarios</ion-col>\n    <ion-col size=\"2\" style=\"text-align: center\">\n      <ion-icon\n        name=\"funnel\"\n        style=\"font-size: 1.5em\"\n        (click)=\"openFilterMenu()\"\n      ></ion-icon>\n    </ion-col>\n  </ion-row>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card\n          class=\"item\"\n          *ngFor=\"let inventario of inventarioList\"\n          (click)=\"onItemClick(inventario)\"\n        >\n          <div\n            [class.abierto]=\"inventario.estado === 'ABIERTO'\"\n            [class.concluido]=\"inventario.estado === 'CONCLUIDO'\"\n            [class.cancelado]=\"inventario.estado === 'CANCELADO'\"\n          >\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"2\"> Id: {{ inventario?.id }} </ion-col>\n                <ion-col size=\"5\">\n                  Inicio: {{ inventario?.fechaInicio | date: 'shortDate' }}\n                </ion-col>\n                <ion-col size=\"5\">\n                  Fin: {{ inventario?.fechaFin | date: 'shortDate' }}\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"6\">\n                  {{ inventario?.sucursal?.nombre | titlecase }}\n                </ion-col>\n                <ion-col size=\"6\">\n                  Estado: {{inventario.estado}}\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\"> Responsable: {{ inventario?.usuario?.persona?.nombre | titlecase}} </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ }),

/***/ 16389:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/inventario/nuevo-inventario/nuevo-inventario.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n  </ion-row>\n  <div [hidden]=\"isNew\">\n    <div style=\"height: 100%; top: 35%\">\n      <ion-row style=\"width: 100%\">\n        <ion-col size=\"1\"> </ion-col>\n        <ion-col size=\"10\" class=\"ion-align-self-center\">\n          <h3 style=\"text-align: center\">\n            Escanee el código QR de la sucursal\n          </h3>\n        </ion-col>\n        <ion-col size=\"1\"> </ion-col>\n      </ion-row>\n    </div>\n    <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n      <ion-fab-button class=\"icon-danger\" (click)=\"onScanQr()\">\n        <ion-icon name=\"camera-outline\"></ion-icon>\n      </ion-fab-button>\n    </ion-fab>\n  </div>\n  <div *ngIf=\"isNew\" style=\"padding: 5px\">\n    <ion-row>\n      <ion-col size=\"12\">\n        <h3 class=\"center title\">Crear nuevo inventario</h3>\n        <ion-row>\n          <ion-col size=\"5\">\n            <h5 class=\"title\">Sucursal:</h5>\n          </ion-col>\n          <ion-col size=\"7\">\n            <h5>{{ selectedSucursal?.nombre | titlecase }}</h5>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"5\">\n            <div class=\"title\">Responsable:</div>\n          </ion-col>\n          <ion-col size=\"7\">\n            {{ loginService?.usuarioActual?.persona?.nombre | titlecase }}\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"5\">\n            <div class=\"title\">Tipo:</div>\n          </ion-col>\n          <ion-col size=\"7\">\n            Zona\n          </ion-col>\n        </ion-row>\n      </ion-col>\n    </ion-row>\n    <ion-item-divider></ion-item-divider>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-list>\n          <ion-list-header>\n            <ion-label>Recomendaciones:</ion-label>\n          </ion-list-header>\n          <ion-item>\n            <p>Verifique que todas los sectores y zonas esten debidamente identificados. </p>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n\n    <ion-fab vertical=\"bottom\" horizontal=\"start\" slot=\"fixed\">\n      <ion-row style=\"width: 100%;\">\n        <ion-col size=\"12\" class=\"center\">\n          <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\"\n            >Cancelar</ion-button\n          >\n        </ion-col>\n      </ion-row>\n    </ion-fab>\n    <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n      <ion-row style=\"width: 100%;\">\n        <ion-col size=\"12\" class=\"center\">\n          <ion-button\n            fill=\"clear\"\n            class=\"btn-success-flat\"\n            (click)=\"onAceptar()\"\n            >Iniciar</ion-button\n          >\n        </ion-col>\n      </ion-row>\n    </ion-fab>\n  </div>\n</ion-content>\n";

/***/ }),

/***/ 85629:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/inventario/select-zona-dialog/select-zona-dialog.component.html?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\"\n      >Detalles de inventario</ion-col\n    >\n  </ion-row>\n  <ion-row>\n    <ion-col size=\"12\" class=\"center\"> Lista de sectores </ion-col>\n  </ion-row>\n  <ion-accordion-group [multiple]=\"true\">\n    <ion-accordion *ngFor=\"let sector of sectorList\" [value]=\"sector.id\">\n      <ion-item slot=\"header\">\n        <ion-label>\n          <p>{{ sector.descripcion | titlecase }} ({{ sector?.zonaList.length }})</p>\n        </ion-label>\n      </ion-item>\n\n      <ion-list slot=\"content\">\n        <ng-container *ngFor=\"let zona of sector?.zonaList\">\n          <ion-item class=\"dark2\" (click)=\"onZonaClick(zona)\">\n            <ion-label>\n              <h2>\n                {{ zona.descripcion | titlecase }}\n              </h2>\n            </ion-label>\n          </ion-item>\n        </ng-container>\n      </ion-list>\n    </ion-accordion>\n  </ion-accordion-group>\n</ion-content>\n";

/***/ }),

/***/ 86280:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/producto/edit-producto/edit-producto.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<p>\n  edit-producto works!\n</p>\n";

/***/ }),

/***/ 79613:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/producto/producto-dashboard/producto-dashboard.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-card class=\"card\" (click)=\"onBuscarProducto()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Buscar producto</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Buscar producto por nombre e código de barra\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card *ngIf=\"loginService.usuarioActual?.roles?.includes('NUEVO-PRODUCTO')\"  class=\"card\" [routerLink]=\"['new']\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Nuevo producto</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Comenzar un nuevo Inventario\n    </ion-card-content>\n  </ion-card>\n\n  <!-- <ion-card class=\"card\" (click)=\"onScanQr()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Escanear QR</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Solicite al encargado el código QR del inventario para unirte\n    </ion-card-content>\n  </ion-card> -->\n\n  <!-- <ion-card class=\"card\" (click)=\"ingresarCodigo()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Ingresar código</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Solicite al encargado el código del inventario\n    </ion-card-content>\n  </ion-card> -->\n</ion-content>\n";

/***/ }),

/***/ 35479:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/producto/search-producto-dialog/search-producto-dialog.component.html?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content fullscreen>\n  <ion-col size=\"2\">\n    <ion-icon\n      name=\"arrow-back\"\n      style=\"font-size: 1.5em\"\n      (click)=\"onBack()\"\n    ></ion-icon>\n  </ion-col>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-item>\n        <ion-label position=\"floating\">Nombre o Código de Barra</ion-label>\n        <ion-input\n          #buscarInput\n          [formControl]=\"buscarControl\"\n          autocapitalize=\"on\"\n          (keyup.enter)=\"onBuscarClick()\"\n        ></ion-input>\n        <ion-icon\n          style=\"font-size: 2em; padding-top: 5px\"\n          name=\"camera-outline\"\n          slot=\"end\"\n          (click)=\"onCameraClick()\"\n        ></ion-icon>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row *ngIf=\"buscarControl.valid\">\n    <ion-col size=\"12\" style=\"text-align: center\">\n      <ion-button\n        class=\"btn-success-flat\"\n        fill=\"clear\"\n        (click)=\"onBuscarClick()\"\n        >Buscar</ion-button\n      >\n    </ion-col>\n  </ion-row>\n  <ion-accordion-group>\n    <ion-accordion\n      *ngFor=\"let producto of productosList; let i = index\"\n      [value]=\"producto.id\"\n      (click)=\"onProductoClick(producto, i)\"\n    >\n      <ion-item slot=\"header\">\n        <ion-label>\n          <h3>{{ producto?.descripcion | titlecase }}</h3>\n        </ion-label>\n      </ion-item>\n\n      <ion-list slot=\"content\">\n        <ion-item\n          *ngFor=\"let presentacion of producto?.presentaciones\"\n          (click)=\"onPresentacionClick(presentacion, producto)\"\n          class=\"dark1\"\n        >\n          <ion-avatar\n            slot=\"start\"\n            (click)=\"\n              onAvatarClick(presentacion?.imagenPrincipal);\n              $event.stopPropagation()\n            \"\n          >\n            <img\n              [src]=\"\n                presentacion?.imagenPrincipal !== null\n                  ? presentacion?.imagenPrincipal\n                  : '/assets/no-image.png'\n              \"\n            />\n          </ion-avatar>\n          <ion-label>\n            <h4>\n              Presentación: {{ presentacion?.cantidad | number: '1.0-2' }}\n            </h4>\n            <p>\n              Cod. barra:\n              {{ presentacion?.codigoPrincipal?.codigo | uppercase }}\n            </p>\n            <p *ngIf=\"mostrarPrecio\">\n              Precio:\n              {{ presentacion?.precioPrincipal?.precio | number: '1.0-2' }}\n            </p>\n            <p *ngIf=\"data?.data?.sucursalId\">\n              <ng-container\n                *ngIf=\"\n                  producto?.stockPorProducto === undefined;\n                  else elseTemplate\n                \"\n              >\n                <ion-spinner></ion-spinner>\n              </ng-container>\n              <ng-template #elseTemplate>\n                Stock: {{ producto?.stockPorProducto / presentacion?.cantidad | number: '1.0-2' }}\n              </ng-template>\n            </p>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </ion-accordion>\n  </ion-accordion-group>\n  <ion-row *ngIf=\"productosList?.length > 0 && showCargarMas\">\n    <ion-col size=\"12\" style=\"text-align: center\">\n      <ion-button\n        class=\"btn-success-flat\"\n        fill=\"clear\"\n        (click)=\"onMasProductos()\"\n        >Cargar más</ion-button\n      >\n    </ion-col>\n  </ion-row>\n\n  <!-- <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button class=\"btn-success\" (click)=\"onMasProductos()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab> -->\n</ion-content>\n";

/***/ }),

/***/ 39450:
/*!*************************************************************!*\
  !*** ./src/app/pages/salir/salir.component.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<p>\n  salir works!\n</p>\n";

/***/ }),

/***/ 13754:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/info-transferencia/info-transferencia.component.html?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\"\n      >Detalles de transferencia</ion-col\n    >\n  </ion-row>\n  <ion-card *ngIf=\"selectedTransferencia !== null\" style=\"margin-top: 10px\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"6\"> Id: {{ selectedTransferencia?.id }} </ion-col>\n        <ion-col size=\"6\">\n          Fecha: {{ selectedTransferencia?.creadoEn | date: 'short' }}\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"5\">\n          {{ selectedTransferencia?.sucursalOrigen?.nombre | titlecase }}\n        </ion-col>\n        <ion-col size=\"2\">\n          <ion-icon name=\"arrow-forward\"></ion-icon>\n        </ion-col>\n        <ion-col size=\"5\">\n          {{ selectedTransferencia?.sucursalDestino?.nombre | titlecase }}\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"10\">\n          Estado: {{ selectedTransferencia?.estado }}\n        </ion-col>\n        <ion-col size=\"2\">\n          <ion-icon name=\"share-social-outline\" style=\"font-size: 2em;\" (click)=\"onShare()\"></ion-icon>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\"> Etapa: {{ selectedTransferencia?.etapa }} </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\">\n          Responsable: {{ selectedResponsable?.persona?.nombre | titlecase }}\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <!-- <ion-col size=\"2\"></ion-col> -->\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-button\n            *ngIf=\"\n              isPreTransferenciaOrigen &&\n              selectedTransferencia?.usuarioPreparacion === null\n            \"\n            class=\"btn-success\"\n            (click)=\"onAvanzarEtapa('PREPARACION_MERCADERIA')\"\n            expand=\"block\"\n          >\n            Preparar productos\n          </ion-button>\n          <ion-button\n            *ngIf=\"isPreparacionMercaderia && puedeEditar\"\n            class=\"btn-success\"\n            (click)=\"onAvanzarEtapa('PREPARACION_MERCADERIA_CONCLUIDA')\"\n            expand=\"block\"\n            [disabled]=\"!isAllConfirmedPreparacion\"\n          >\n            Concluir\n          </ion-button>\n          <ion-button\n            *ngIf=\"isPreparacionMercaderiaConcluida\"\n            class=\"btn-success\"\n            (click)=\"onAvanzarEtapa('TRANSPORTE_VERIFICACION')\"\n            expand=\"block\"\n          >\n            Verificar para transporte\n          </ion-button>\n          <ion-button\n            *ngIf=\"isTransporteVerificacion && puedeEditar\"\n            class=\"btn-success\"\n            (click)=\"onAvanzarEtapa('TRANSPORTE_EN_CAMINO')\"\n            expand=\"block\"\n            [disabled]=\"!isAllConfirmedTransporte\"\n          >\n            Concluir\n          </ion-button>\n          <ion-button\n            *ngIf=\"isTransporteEnCamino || isTransporteEnDestino\"\n            class=\"btn-success\"\n            (click)=\"onAvanzarEtapa('RECEPCION_EN_VERIFICACION')\"\n            expand=\"block\"\n          >\n            Iniciar recepción\n          </ion-button>\n          <ion-button\n            *ngIf=\"isRecepcionEnVerificacion && puedeEditar\"\n            class=\"btn-success\"\n            (click)=\"onAvanzarEtapa('RECEPCION_CONCLUIDA')\"\n            expand=\"block\"\n            [disabled]=\"!isAllConfirmedRecepcion\"\n          >\n            Concluir\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n  <ion-list\n    *ngIf=\"\n      selectedTransferencia?.etapa === 'PRE_TRANSFERENCIA_ORIGEN' ||\n      selectedTransferencia?.etapa === 'PREPARACION_MERCADERIA'\n    \"\n  >\n    <ion-list-header> Lista de productos </ion-list-header>\n\n    <ion-item\n      *ngFor=\"let item of selectedTransferencia?.transferenciaItemList\"\n      (press)=\"puedeEditar ? onItemPress(item) : null\"\n    >\n      <ion-avatar\n        slot=\"start\"\n        (click)=\"\n          onAvatarClick(item?.presentacionPreTransferencia?.imagenPrincipal)\n        \"\n      >\n        <img [src]=\"item?.presentacionPreTransferencia?.imagenPrincipal\" />\n      </ion-avatar>\n      <ion-label>\n        <h2>\n          {{\n            item?.presentacionPreTransferencia?.producto?.descripcion\n              | titlecase\n          }}\n        </h2>\n        <ion-row>\n          <ion-col size=\"10\">\n            <h3>\n              Presentacion:\n              {{\n                item?.presentacionPreTransferencia?.cantidad | number: '1.0-2'\n              }}\n            </h3>\n            <h3>\n              Cantidad: {{ item.cantidadPreTransferencia | number: '1.0-2' }}\n              {{\n                item?.motivoModificacionPreparacion === 'CANTIDAD_INCORRECTA'\n                  ? ' / ' + item?.cantidadPreparacion\n                  : null\n              }}\n            </h3>\n            <h3>\n              Vencimiento:\n              {{ item.vencimientoPreTransferencia | date: 'shortDate' }}\n              {{\n                item?.motivoModificacionPreparacion === 'VENCIMIENTO_INCORRECTO'\n                  ? ' - ' + (item?.vencimientoPreparacion | date: 'shortDate')\n                  : null\n              }}\n            </h3>\n            <h3 *ngIf=\"item.motivoModificacionPreparacion !== null\">\n              Motivo: {{ item.motivoModificacionPreparacion }}\n            </h3>\n            <h3 *ngIf=\"item.motivoRechazoPreparacion !== null\">\n              Motivo: {{ item.motivoRechazoPreparacion }}\n            </h3>\n          </ion-col>\n          <ion-col size=\"2\">\n            <ion-icon\n              (click)=\"puedeEditar ? onItemPress(item) : null\"\n              [name]=\"\n                item.motivoRechazoPreparacion === null\n                  ? 'checkmark-circle'\n                  : 'close'\n              \"\n              style=\"font-size: 2em\"\n              [class.sin-cambios]=\"\n                item.cantidadPreparacion !== null &&\n                item.motivoModificacionPreparacion === null &&\n                item.motivoRechazoPreparacion === null &&\n                !isPreparacionEnCamino\n              \"\n              [class.con-cambios]=\"\n                item.motivoModificacionPreparacion !== null &&\n                !isPreparacionEnCamino\n              \"\n              [class.rechazado]=\"\n                item.motivoRechazoPreparacion !== null && !isPreparacionEnCamino\n              \"\n            ></ion-icon>\n          </ion-col>\n        </ion-row>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list\n    *ngIf=\"\n      isPreparacionMercaderiaConcluida ||\n      isTransporteVerificacion ||\n      isTransporteEnCamino\n    \"\n  >\n    <ion-list-header> Lista de productos </ion-list-header>\n\n    <ion-item\n      *ngFor=\"let item of selectedTransferencia?.transferenciaItemList\"\n      (press)=\"puedeEditar ? onItemPress(item) : null\"\n    >\n      <ion-avatar\n        slot=\"start\"\n        (click)=\"\n          onAvatarClick(item?.presentacionPreTransferencia?.imagenPrincipal)\n        \"\n      >\n        <img [src]=\"item?.presentacionPreTransferencia?.imagenPrincipal\" />\n      </ion-avatar>\n      <ion-label>\n        <h2>\n          {{ item?.presentacionPreparacion?.producto?.descripcion | titlecase }}\n        </h2>\n        <ion-row>\n          <ion-col size=\"10\">\n            <h3>\n              Presentacion:\n              {{ item?.presentacionPreparacion?.cantidad | number: '1.0-2' }}\n            </h3>\n            <h3>Cantidad: {{ item.cantidadPreparacion | number: '1.0-2' }}</h3>\n            <h3>\n              Vencimiento:\n              {{ item.vencimientoPreparacion | date: 'shortDate' }}\n            </h3>\n            <!-- <h3 *ngIf=\"item.motivoModificacionPreparacion !== null\">\n              Motivo: {{ item.motivoModificacionPreparacion }}\n            </h3>\n            <h3 *ngIf=\"item.motivoRechazoPreparacion !== null\">\n              Motivo: {{ item.motivoRechazoPreparacion }}\n            </h3> -->\n          </ion-col>\n          <ion-col size=\"2\">\n            <ion-icon\n              (click)=\"puedeEditar ? onItemPress(item) : null\"\n              [name]=\"\n                item.motivoRechazoTransporte === null\n                  ? 'checkmark-circle'\n                  : 'close'\n              \"\n              style=\"font-size: 2em\"\n              [class.sin-cambios]=\"\n                item.cantidadTransporte !== null &&\n                item.motivoModificacionTransporte === null &&\n                item.motivoRechazoTransporte === null &&\n                !isTransporteEnCamino\n              \"\n              [class.con-cambios]=\"\n                item.motivoModificacionTransporte !== null &&\n                !isTransporteEnCamino\n              \"\n              [class.rechazado]=\"\n                item.motivoRechazoTransporte !== null && !isTransporteEnCamino\n              \"\n            ></ion-icon>\n          </ion-col>\n        </ion-row>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list\n    *ngIf=\"\n      selectedTransferencia?.etapa === 'RECEPCION_EN_VERIFICACION' ||\n      selectedTransferencia?.etapa === 'RECEPCION_CONCLUIDA'\n    \"\n  >\n    <ion-list-header> Lista de productos </ion-list-header>\n\n    <ion-item\n      *ngFor=\"let item of selectedTransferencia?.transferenciaItemList\"\n      (press)=\"puedeEditar ? onItemPress(item) : null\"\n    >\n      <ion-avatar\n        slot=\"start\"\n        (click)=\"\n          onAvatarClick(item?.presentacionPreTransferencia?.imagenPrincipal)\n        \"\n      >\n        <img [src]=\"item?.presentacionTransporte?.imagenPrincipal\" />\n      </ion-avatar>\n      <ion-label>\n        <h2>\n          {{ item?.presentacionTransporte?.producto?.descripcion | titlecase }}\n        </h2>\n        <ion-row>\n          <ion-col size=\"10\">\n            <h3>\n              Presentacion:\n              {{ item?.presentacionTransporte?.cantidad | number: '1.0-2' }}\n            </h3>\n            <h3>Cantidad: {{ item.cantidadTransporte | number: '1.0-2' }}</h3>\n            <h3>\n              Vencimiento:\n              {{ item.vencimientoTransporte | date: 'shortDate' }}\n            </h3>\n            <h3 *ngIf=\"item.motivoModificacionRecepcion !== null\">\n              Motivo: {{ item.motivoModificacionRecepcion }}\n            </h3>\n            <h3 *ngIf=\"item.motivoRechazoRecepcion !== null\">\n              Motivo: {{ item.motivoRechazoRecepcion }}\n            </h3>\n          </ion-col>\n          <ion-col size=\"2\">\n            <ion-icon\n              (click)=\"puedeEditar ? onItemPress(item) : null\"\n              [name]=\"\n                item.motivoRechazoRecepcion === null\n                  ? 'checkmark-circle'\n                  : 'close'\n              \"\n              style=\"font-size: 2em\"\n              [class.sin-cambios]=\"\n                item.cantidadRecepcion !== null &&\n                item.motivoModificacionRecepcion === null &&\n                item.motivoRechazoRecepcion === null &&\n                !isRecepcionEnCamino\n              \"\n              [class.con-cambios]=\"\n                item.motivoModificacionRecepcion !== null &&\n                !isRecepcionEnCamino\n              \"\n              [class.rechazado]=\"\n                item.motivoRechazoRecepcion !== null && !isRecepcionEnCamino\n              \"\n            ></ion-icon>\n          </ion-col>\n        </ion-row>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n  <!-- <ion-item>\n    <ion-row class=\"dark2\">\n      <ion-col class=\"center\">\n        <ion-button\n          class=\"btn-success-flat\"\n          fill=\"clear\"\n          (click)=\"onCargarMenos()\"\n          expand=\"block\"\n          *ngIf=\"selectedTransferencia?.transferenciaItemList?.length > 0\"\n          [disabled]=\"\n            selectedTransferencia?.transferenciaItemList.length > size\n          \"\n        >\n          Menos\n        </ion-button>\n      </ion-col>\n      <ion-col class=\"center\">\n        <ion-button\n          class=\"btn-success-flat\"\n          fill=\"clear\"\n          (click)=\"onCargarMas()\"\n          expand=\"block\"\n          *ngIf=\"selectedTransferencia?.transferenciaItemList?.length > 0\"\n        >\n          Cargar más\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-item> -->\n</ion-content>\n";

/***/ }),

/***/ 59279:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/ingresar-codigo-pop/ingresar-codigo-pop.component.html?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content style=\"width: 100%;\">\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-item>\n          <ion-label position=\"floating\">Ingrese el código</ion-label>\n          <ion-input type=\"text\" class=\"ion-margin-top\" [formControl]=\"codigoControl\"> </ion-input>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\">\n        <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\">Cancelar</ion-button>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-button fill=\"clear\" class=\"btn-success-flat\" (click)=\"onAceptar()\" [disabled]=\"codigoControl.invalid\">Aceptar</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ }),

/***/ 25676:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/list-transferencias/list-transferencias.component.html?ngResource ***!
  \********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content style=\"width: 100%\">\n  <ion-row>\n    <ion-col size=\"2\">\n      <ion-icon\n        name=\"arrow-back\"\n        style=\"font-size: 1.5em\"\n        (click)=\"onBack()\"\n      ></ion-icon>\n    </ion-col>\n    <ion-col size=\"8\" style=\"text-align: center\"\n      >Lista de transferencias</ion-col\n    >\n    <ion-col size=\"2\" style=\"text-align: center;\">\n      <ion-icon\n        name=\"funnel\"\n        style=\"font-size: 1.5em\"\n        (click)=\"openFilterMenu()\"\n      ></ion-icon>\n    </ion-col>\n  </ion-row>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card\n          class=\"item\"\n          *ngFor=\"let transferencia of transferenciaList\"\n          [class.test]=\"transferencia.etapa === 'RECEPCION_CONCLUIDA'\"\n          (click)=\"onItemClick(transferencia)\"\n        >\n          <div\n            [class.en-origen]=\"\n              transferencia.etapa === 'PRE_TRANSFERENCIA_CREACION' ||\n              transferencia.etapa === 'PRE_TRANSFERENCIA_ORIGEN'\n            \"\n            [class.en-origen-preparacion]=\"\n              transferencia.etapa === 'PREPARACION_MERCADERIA' ||\n              transferencia.etapa === 'PREPARACION_MERCADERIA_CONCLUIDA'\n            \"\n            [class.en-origen-transito]=\"\n              transferencia.etapa === 'TRANSPORTE_VERIFICACION' ||\n              transferencia.etapa === 'TRANSPORTE_EN_CAMINO' ||\n              transferencia.etapa === 'TRANSPORTE_EN_DESTINO'\n            \"\n            [class.en-destino-recepcion]=\"\n              transferencia.etapa === 'RECEPCION_EN_VERIFICACION'\n            \"\n            [class.en-destino-recepcion-concluida]=\"\n              transferencia.etapa === 'RECEPCION_CONCLUIDA'\n            \"\n          >\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"4\"> Id: {{ transferencia?.id }} </ion-col>\n                <ion-col size=\"8\">\n                  Fecha: {{ transferencia?.creadoEn | date: 'short' }}\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"5\">\n                  {{ transferencia?.sucursalOrigen?.nombre | titlecase }}\n                </ion-col>\n                <ion-col size=\"2\">\n                  <ion-icon name=\"arrow-forward\"></ion-icon>\n                </ion-col>\n                <ion-col size=\"5\">\n                  {{ transferencia?.sucursalDestino?.nombre | titlecase }}\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\"> Etapa: {{ transferencia.etapa }} </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ }),

/***/ 77800:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/transferencias/modificar-item-dialog/modificar-item-dialog.component.html?ngResource ***!
  \************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content style=\"width: 100%;\">\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" *ngIf=\"isCantidad\">\n        <ion-item>\n          <ion-label position=\"floating\">Nueva cantidad</ion-label>\n          <ion-input type=\"text\" class=\"ion-margin-top\" [formControl]=\"cantidadControl\"> </ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"12\" *ngIf=\"isVencimiento\">\n        <ion-item>\n          <ion-datetime locale=\"es-PY\" [formControl]=\"vencimientoControl\">\n            <div slot=\"title\">Nuevo vencimiento</div>\n          </ion-datetime>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\">\n        <ion-button fill=\"clear\" class=\"btn-danger-flat\" (click)=\"onCancel()\">Cancelar</ion-button>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-button fill=\"clear\" class=\"btn-success-flat\" (click)=\"onAceptar()\" [disabled]=\"cantidadControl.invalid && vencimientoControl.invalid\">Aceptar</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ }),

/***/ 39925:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/transferencias/transferencia/transferencia.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<!-- <ion-content style=\"top: 40%; bottom: 60%;\">\n  <ion-button expand=\"block\">Scanear QR</ion-button>\n  <ion-button expand=\"block\">Scanear QR</ion-button>\n  <ion-button expand=\"block\">Scanear QR</ion-button>\n</ion-content> -->\n<ion-content>\n  <ion-card class=\"card\" [routerLink]=\"['list']\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Lista de tranferencias</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Lista de transferencias en las cuales estas participando\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"onScanQr()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Scanear QR</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Solicite al encargado el código QR de la transferencia\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"card\" (click)=\"ingresarCodigo()\">\n    <ion-card-header style=\"color: white\">\n      <ion-card-title>Ingresar código</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content style=\"color: white\">\n      Solicite al encargado el código de la transferencia\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map